import pandas as pd


PRICE_FILE = (
    r"data\SBIN_5min_"
    r"2026-06-22_to_2026-09-18_clean.csv"
)

BACKTEST_FILE = (
    r"results\SBIN_strategy_v1_backtest_gross.csv"
)


# ---------------------------------------------------------
# Load data
# ---------------------------------------------------------

prices = pd.read_csv(PRICE_FILE)
trades = pd.read_csv(BACKTEST_FILE)

prices["timestamp"] = pd.to_datetime(prices["timestamp"])
trades["entry_timestamp"] = pd.to_datetime(trades["entry_timestamp"])
trades["exit_timestamp"] = pd.to_datetime(trades["exit_timestamp"])

prices["trade_date"] = prices["timestamp"].dt.date
trades["trade_date"] = pd.to_datetime(
    trades["trade_date"]
).dt.date


diagnostics = []


# ---------------------------------------------------------
# Analyse each trade
# ---------------------------------------------------------

for _, trade in trades.iterrows():

    entry = float(trade["entry_price"])
    stop = float(trade["stop_price"])

    risk_per_share = entry - stop

    entry_time = trade["entry_timestamp"]
    exit_time = trade["exit_timestamp"]


    # -----------------------------------------------------
    # Use candles BEFORE the exit candle.
    #
    # This avoids assuming whether the high or low happened
    # before or after the actual stop/target inside the
    # exit candle.
    # -----------------------------------------------------

    path = prices[
        (prices["trade_date"] == trade["trade_date"])
        & (prices["timestamp"] >= entry_time)
        & (prices["timestamp"] < exit_time)
    ].copy()


    if len(path) > 0:

        max_high_before_exit = path["high"].max()
        min_low_before_exit = path["low"].min()

        pre_exit_mfe = (
            max_high_before_exit - entry
        )

        pre_exit_mae = (
            entry - min_low_before_exit
        )

        pre_exit_mfe_r = (
            pre_exit_mfe / risk_per_share
        )

        pre_exit_mae_r = (
            pre_exit_mae / risk_per_share
        )

    else:

        pre_exit_mfe_r = 0.0
        pre_exit_mae_r = 0.0


    holding_minutes = (
        (
            exit_time - entry_time
        ).total_seconds()
        / 60
    )


    # -----------------------------------------------------
    # Entry-time bucket
    # -----------------------------------------------------

    hour = entry_time.hour
    minute = entry_time.minute

    minutes_from_midnight = (
        hour * 60 + minute
    )

    if minutes_from_midnight < 10 * 60 + 30:
        entry_bucket = "09:30-10:29"

    elif minutes_from_midnight < 11 * 60 + 30:
        entry_bucket = "10:30-11:29"

    elif minutes_from_midnight < 12 * 60 + 30:
        entry_bucket = "11:30-12:29"

    elif minutes_from_midnight < 13 * 60 + 30:
        entry_bucket = "12:30-13:29"

    else:
        entry_bucket = "13:30-14:45"


    diagnostics.append(
        {
            "trade_date": trade["trade_date"],
            "entry_timestamp": entry_time,
            "exit_timestamp": exit_time,
            "exit_reason": trade["exit_reason"],
            "gross_pnl": trade["gross_pnl"],
            "r_multiple": trade["r_multiple"],
            "holding_minutes": holding_minutes,
            "entry_bucket": entry_bucket,
            "pre_exit_mfe_r": pre_exit_mfe_r,
            "pre_exit_mae_r": pre_exit_mae_r,
        }
    )


df = pd.DataFrame(diagnostics)


# ---------------------------------------------------------
# Overall diagnostics
# ---------------------------------------------------------

print("=" * 70)
print("SBIN STRATEGY V1 DIAGNOSTIC REPORT")
print("=" * 70)

print("Trades:", len(df))

print()

print("Holding time:")
print(
    df["holding_minutes"]
    .describe()
    .round(2)
)

print()


# ---------------------------------------------------------
# Stop timing
# ---------------------------------------------------------

stops = df[
    df["exit_reason"] == "STOP"
].copy()

print("STOP diagnostics:")
print("Total stopped trades:", len(stops))

print(
    "Stopped within 5 minutes:",
    int(
        (
            stops["holding_minutes"] <= 5
        ).sum()
    )
)

print(
    "Stopped within 15 minutes:",
    int(
        (
            stops["holding_minutes"] <= 15
        ).sum()
    )
)

print(
    "Stopped within 30 minutes:",
    int(
        (
            stops["holding_minutes"] <= 30
        ).sum()
    )
)

print()


# ---------------------------------------------------------
# Did stopped trades first move in our favour?
# ---------------------------------------------------------

print("Stopped trades that first achieved:")

for threshold in [
    0.25,
    0.50,
    1.00,
    1.50,
]:

    count = int(
        (
            stops["pre_exit_mfe_r"]
            >= threshold
        ).sum()
    )

    print(
        f"  +{threshold:.2f}R before stop: {count}"
    )


# ---------------------------------------------------------
# Entry-time performance
# ---------------------------------------------------------

print()
print("Performance by entry time:")

time_summary = (
    df.groupby("entry_bucket")
    .agg(
        trades=("gross_pnl", "size"),
        wins=(
            "gross_pnl",
            lambda x: (x > 0).sum()
        ),
        total_pnl=("gross_pnl", "sum"),
        average_pnl=("gross_pnl", "mean"),
        average_r=("r_multiple", "mean"),
    )
)

time_summary["win_rate"] = (
    time_summary["wins"]
    / time_summary["trades"]
    * 100
)

print(
    time_summary.round(3).to_string()
)


# ---------------------------------------------------------
# Exit-type behaviour
# ---------------------------------------------------------

print()
print("Performance by exit reason:")

exit_summary = (
    df.groupby("exit_reason")
    .agg(
        trades=("gross_pnl", "size"),
        total_pnl=("gross_pnl", "sum"),
        avg_pnl=("gross_pnl", "mean"),
        avg_r=("r_multiple", "mean"),
        avg_holding_minutes=(
            "holding_minutes",
            "mean"
        ),
    )
)

print(
    exit_summary.round(3).to_string()
)


# ---------------------------------------------------------
# Save diagnostic data
# ---------------------------------------------------------

OUTPUT_FILE = (
    r"results\SBIN_strategy_v1_diagnostics.csv"
)

df.to_csv(
    OUTPUT_FILE,
    index=False
)

print()
print(
    "Diagnostic data saved to:",
    OUTPUT_FILE
)

print()
print("DIAGNOSTIC ANALYSIS COMPLETE")