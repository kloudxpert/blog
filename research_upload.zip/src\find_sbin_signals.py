from datetime import time

import pandas as pd


# ---------------------------------------------------------
# Files
# ---------------------------------------------------------

INPUT_FILE = (
    r"data\SBIN_5min_"
    r"2026-06-22_to_2026-09-18_indicators.csv"
)

OUTPUT_FILE = (
    r"results\SBIN_strategy_v1_signals.csv"
)


# ---------------------------------------------------------
# Load indicator data
# ---------------------------------------------------------

df = pd.read_csv(INPUT_FILE)

df["timestamp"] = pd.to_datetime(df["timestamp"])

df = (
    df
    .sort_values("timestamp")
    .reset_index(drop=True)
)

df["trade_date"] = df["timestamp"].dt.date
df["trade_time"] = df["timestamp"].dt.time


# ---------------------------------------------------------
# Strategy V1 trading window
# ---------------------------------------------------------

ENTRY_START = time(9, 30)
ENTRY_END = time(14, 45)

df["within_entry_window"] = (
    (df["trade_time"] >= ENTRY_START)
    & (df["trade_time"] <= ENTRY_END)
)


# ---------------------------------------------------------
# Strategy V1 conditions
# ---------------------------------------------------------

# Condition 1:
# Price above VWAP
df["condition_vwap"] = (
    df["close"] > df["vwap"]
)


# Condition 2:
# EMA9 above EMA20
df["condition_ema"] = (
    df["ema9"] > df["ema20"]
)


# Condition 3:
# Current volume greater than
# 1.5 x average of previous 10 candles
df["condition_volume"] = (
    df["volume"]
    > 1.5 * df["avg_volume_prev10"]
)


# Condition 4:
# Current close breaks above
# highest high of previous 5 candles
df["condition_breakout"] = (
    df["close"]
    > df["highest_high_prev5"]
)


# ---------------------------------------------------------
# All indicators must exist
# ---------------------------------------------------------

df["indicators_ready"] = (
    df["vwap"].notna()
    & df["ema9"].notna()
    & df["ema20"].notna()
    & df["atr14"].notna()
    & df["avg_volume_prev10"].notna()
    & df["highest_high_prev5"].notna()
)


# ---------------------------------------------------------
# Raw Strategy V1 signal
# ---------------------------------------------------------

df["long_signal"] = (
    df["within_entry_window"]
    & df["indicators_ready"]
    & df["condition_vwap"]
    & df["condition_ema"]
    & df["condition_volume"]
    & df["condition_breakout"]
)


# ---------------------------------------------------------
# Extract signals
# ---------------------------------------------------------

signals = df[
    df["long_signal"]
].copy()


# ---------------------------------------------------------
# Diagnostics
# ---------------------------------------------------------

eligible = df[
    df["within_entry_window"]
    & df["indicators_ready"]
].copy()

print("=" * 65)
print("SBIN STRATEGY V1 SIGNAL ANALYSIS")
print("=" * 65)

print(
    "Total candles:",
    len(df)
)

print(
    "Candles eligible for evaluation:",
    len(eligible)
)

print()

print("Individual condition counts:")

print(
    "Close > VWAP:",
    int(eligible["condition_vwap"].sum())
)

print(
    "EMA9 > EMA20:",
    int(eligible["condition_ema"].sum())
)

print(
    "Strong volume:",
    int(eligible["condition_volume"].sum())
)

print(
    "5-candle breakout:",
    int(eligible["condition_breakout"].sum())
)

print()

print(
    "Candles satisfying ALL 4 conditions:",
    len(signals)
)


# ---------------------------------------------------------
# Signals by trading day
# ---------------------------------------------------------

signal_days = (
    signals["trade_date"].nunique()
)

print(
    "Trading days containing at least one signal:",
    signal_days
)

print(
    "Total trading days:",
    df["trade_date"].nunique()
)

print()


# ---------------------------------------------------------
# Show signal frequency by date
# ---------------------------------------------------------

if not signals.empty:

    signals_per_day = (
        signals
        .groupby("trade_date")
        .size()
        .reset_index(name="signal_count")
    )

    print("Signals per day:")
    print(
        signals_per_day.to_string(index=False)
    )

    print()

    print("First 15 raw signals:")

    display_columns = [
        "timestamp",
        "close",
        "vwap",
        "ema9",
        "ema20",
        "volume",
        "avg_volume_prev10",
        "highest_high_prev5",
        "atr14",
    ]

    print(
        signals[
            display_columns
        ]
        .head(15)
        .to_string(index=False)
    )

else:

    print("No Strategy V1 signals found.")


# ---------------------------------------------------------
# Save
# ---------------------------------------------------------

save_columns = [
    "timestamp",
    "open",
    "high",
    "low",
    "close",
    "volume",
    "vwap",
    "ema9",
    "ema20",
    "atr14",
    "avg_volume_prev10",
    "highest_high_prev5",
]

signals[
    save_columns
].to_csv(
    OUTPUT_FILE,
    index=False,
)

print()

print(
    "Signal file saved to:",
    OUTPUT_FILE
)

print()

print("SIGNAL ANALYSIS COMPLETE")