import pandas as pd


# ---------------------------------------------------------
# Files
# ---------------------------------------------------------

INPUT_FILE = (
    r"data\SBIN_5min_"
    r"2026-06-22_to_2026-09-18_clean.csv"
)

OUTPUT_FILE = (
    r"data\SBIN_5min_"
    r"2026-06-22_to_2026-09-18_indicators.csv"
)


# ---------------------------------------------------------
# Load clean historical data
# ---------------------------------------------------------

df = pd.read_csv(INPUT_FILE)

df["timestamp"] = pd.to_datetime(df["timestamp"])

df = (
    df
    .sort_values("timestamp")
    .reset_index(drop=True)
)

df["trade_date"] = df["timestamp"].dt.date


# ---------------------------------------------------------
# 1. VWAP
# ---------------------------------------------------------

df["typical_price"] = (
    df["high"]
    + df["low"]
    + df["close"]
) / 3

df["price_x_volume"] = (
    df["typical_price"]
    * df["volume"]
)

df["cum_volume"] = (
    df
    .groupby("trade_date")["volume"]
    .cumsum()
)

df["cum_price_x_volume"] = (
    df
    .groupby("trade_date")["price_x_volume"]
    .cumsum()
)

df["vwap"] = (
    df["cum_price_x_volume"]
    / df["cum_volume"]
)


# ---------------------------------------------------------
# 2. EMA 9
# ---------------------------------------------------------

df["ema9"] = (
    df["close"]
    .ewm(
        span=9,
        adjust=False
    )
    .mean()
)


# ---------------------------------------------------------
# 3. EMA 20
# ---------------------------------------------------------

df["ema20"] = (
    df["close"]
    .ewm(
        span=20,
        adjust=False
    )
    .mean()
)


# ---------------------------------------------------------
# 4. ATR 14
# ---------------------------------------------------------

previous_close = df["close"].shift(1)

high_low = (
    df["high"] - df["low"]
)

high_prev_close = (
    df["high"] - previous_close
).abs()

low_prev_close = (
    df["low"] - previous_close
).abs()

df["true_range"] = pd.concat(
    [
        high_low,
        high_prev_close,
        low_prev_close,
    ],
    axis=1,
).max(axis=1)

df["atr14"] = (
    df["true_range"]
    .ewm(
        alpha=1 / 14,
        adjust=False,
        min_periods=14,
    )
    .mean()
)


# ---------------------------------------------------------
# 5. Previous 10-candle average volume
#
# Current candle is excluded.
# Resets every trading day.
# ---------------------------------------------------------

df["avg_volume_prev10"] = (
    df
    .groupby("trade_date")["volume"]
    .transform(
        lambda s:
        s.shift(1)
        .rolling(
            window=10,
            min_periods=10
        )
        .mean()
    )
)


# ---------------------------------------------------------
# 6. Previous 5-candle highest high
#
# Used as recent resistance.
# Current candle is excluded.
# ---------------------------------------------------------

df["highest_high_prev5"] = (
    df
    .groupby("trade_date")["high"]
    .transform(
        lambda s:
        s.shift(1)
        .rolling(
            window=5,
            min_periods=5
        )
        .max()
    )
)


# ---------------------------------------------------------
# 7. Previous 5-candle lowest low
#
# Used as recent swing low for stop-loss.
# Current candle is excluded.
# ---------------------------------------------------------

df["lowest_low_prev5"] = (
    df
    .groupby("trade_date")["low"]
    .transform(
        lambda s:
        s.shift(1)
        .rolling(
            window=5,
            min_periods=5
        )
        .min()
    )
)


# ---------------------------------------------------------
# Keep only useful columns
# ---------------------------------------------------------

output_columns = [
    "timestamp",
    "open",
    "high",
    "low",
    "close",
    "volume",
    "vwap",
    "ema9",
    "ema20",
    "atr14",
    "avg_volume_prev10",
    "highest_high_prev5",
    "lowest_low_prev5",
]

output_df = df[output_columns].copy()


# ---------------------------------------------------------
# Validation
# ---------------------------------------------------------

print("=" * 65)
print("SBIN STRATEGY V1 INDICATOR BUILD")
print("=" * 65)

print(
    "Total candles:",
    len(output_df)
)

print()
print("Missing values:")

indicator_columns = [
    "vwap",
    "ema9",
    "ema20",
    "atr14",
    "avg_volume_prev10",
    "highest_high_prev5",
    "lowest_low_prev5",
]

print(
    output_df[
        indicator_columns
    ]
    .isna()
    .sum()
)


# ---------------------------------------------------------
# Rows ready for Strategy V1 evaluation
# ---------------------------------------------------------

ready_mask = (
    output_df["vwap"].notna()
    & output_df["ema9"].notna()
    & output_df["ema20"].notna()
    & output_df["atr14"].notna()
    & output_df["avg_volume_prev10"].notna()
    & output_df["highest_high_prev5"].notna()
    & output_df["lowest_low_prev5"].notna()
)

print()

print(
    "Candles ready for strategy evaluation:",
    int(ready_mask.sum())
)


# ---------------------------------------------------------
# Sample rows
# ---------------------------------------------------------

print()
print("Sample rows:")

sample_columns = [
    "timestamp",
    "close",
    "vwap",
    "ema9",
    "ema20",
    "atr14",
    "avg_volume_prev10",
    "highest_high_prev5",
    "lowest_low_prev5",
]

print(
    output_df.loc[
        ready_mask,
        sample_columns,
    ]
    .head(10)
    .to_string(index=False)
)


# ---------------------------------------------------------
# Save
# ---------------------------------------------------------

output_df.to_csv(
    OUTPUT_FILE,
    index=False,
)

print()
print("Indicator file saved to:")
print(OUTPUT_FILE)

print()
print("INDICATOR BUILD COMPLETE")