import math
import pandas as pd


# ---------------------------------------------------------
# Configuration
# ---------------------------------------------------------

INPUT_FILE = (
    r"results\SBIN_strategy_v1_trade_candidates.csv"
)

OUTPUT_FILE = (
    r"results\SBIN_strategy_v1_prepared_trades.csv"
)

INITIAL_CAPITAL = 200000.0
RISK_PERCENT = 0.005       # 0.5%
TARGET_R_MULTIPLE = 2.0


# ---------------------------------------------------------
# Load candidate trades
# ---------------------------------------------------------

df = pd.read_csv(INPUT_FILE)

df["timestamp"] = pd.to_datetime(df["timestamp"])
df["entry_timestamp"] = pd.to_datetime(df["entry_timestamp"])

df = (
    df
    .sort_values("entry_timestamp")
    .reset_index(drop=True)
)


# ---------------------------------------------------------
# Strategy V1:
# Maximum ONE SBIN trade per trading day.
#
# Keep the earliest valid candidate each day.
# ---------------------------------------------------------

trades = (
    df
    .groupby("trade_date", as_index=False)
    .first()
    .sort_values("entry_timestamp")
    .reset_index(drop=True)
)


# ---------------------------------------------------------
# Stop-loss
#
# ATR Stop:
# Entry - 1 x ATR
#
# Swing Stop:
# Lowest low of previous 5 completed candles
#
# Final stop:
# Lower of the two
# ---------------------------------------------------------

trades["atr_stop"] = (
    trades["entry_price"]
    - trades["atr14"]
)

trades["swing_stop"] = (
    trades["lowest_low_prev5"]
)

trades["stop_price"] = trades[
    [
        "atr_stop",
        "swing_stop",
    ]
].min(axis=1)


# ---------------------------------------------------------
# Risk per share
# ---------------------------------------------------------

trades["risk_per_share"] = (
    trades["entry_price"]
    - trades["stop_price"]
)


# ---------------------------------------------------------
# Risk budget
# ---------------------------------------------------------

risk_budget = (
    INITIAL_CAPITAL
    * RISK_PERCENT
)

trades["risk_budget"] = risk_budget


# ---------------------------------------------------------
# Quantity based on risk
# ---------------------------------------------------------

trades["quantity_by_risk"] = (
    trades["risk_budget"]
    / trades["risk_per_share"]
).apply(math.floor)


# ---------------------------------------------------------
# Conservative capital constraint
#
# For our first backtest we will NOT assume leverage.
# ---------------------------------------------------------

trades["quantity_by_cash"] = (
    INITIAL_CAPITAL
    / trades["entry_price"]
).apply(math.floor)


trades["quantity"] = trades[
    [
        "quantity_by_risk",
        "quantity_by_cash",
    ]
].min(axis=1)


# ---------------------------------------------------------
# Actual rupee risk
# ---------------------------------------------------------

trades["planned_risk"] = (
    trades["quantity"]
    * trades["risk_per_share"]
)


# ---------------------------------------------------------
# 2R target
# ---------------------------------------------------------

trades["target_price"] = (
    trades["entry_price"]
    + TARGET_R_MULTIPLE
    * trades["risk_per_share"]
)


# ---------------------------------------------------------
# Basic validation
# ---------------------------------------------------------

invalid = trades[
    (trades["risk_per_share"] <= 0)
    | (trades["quantity"] <= 0)
]

print("=" * 70)
print("SBIN STRATEGY V1 PREPARED TRADES")
print("=" * 70)

print(
    "Valid candidates before one-trade/day rule:",
    len(df)
)

print(
    "Prepared trades after one-trade/day rule:",
    len(trades)
)

print(
    "Trading days:",
    trades["trade_date"].nunique()
)

print(
    "Risk budget per trade: ₹",
    f"{risk_budget:,.2f}",
    sep=""
)

print(
    "Invalid trades:",
    len(invalid)
)

print()

print("First 15 prepared trades:")

display_columns = [
    "trade_date",
    "entry_timestamp",
    "entry_price",
    "atr14",
    "swing_stop",
    "atr_stop",
    "stop_price",
    "risk_per_share",
    "quantity",
    "planned_risk",
    "target_price",
]

print(
    trades[
        display_columns
    ]
    .head(15)
    .to_string(index=False)
)


# ---------------------------------------------------------
# Summary statistics
# ---------------------------------------------------------

print()
print("Risk statistics:")

print(
    "Average risk/share: ₹",
    f"{trades['risk_per_share'].mean():.2f}",
    sep=""
)

print(
    "Average quantity:",
    f"{trades['quantity'].mean():.1f}"
)

print(
    "Average planned rupee risk: ₹",
    f"{trades['planned_risk'].mean():.2f}",
    sep=""
)

print(
    "Maximum planned rupee risk: ₹",
    f"{trades['planned_risk'].max():.2f}",
    sep=""
)


# ---------------------------------------------------------
# Save
# ---------------------------------------------------------

save_columns = [
    "trade_date",
    "timestamp",
    "entry_timestamp",
    "entry_price",
    "atr14",
    "lowest_low_prev5",
    "atr_stop",
    "swing_stop",
    "stop_price",
    "risk_per_share",
    "risk_budget",
    "quantity_by_risk",
    "quantity_by_cash",
    "quantity",
    "planned_risk",
    "target_price",
]

trades[
    save_columns
].to_csv(
    OUTPUT_FILE,
    index=False,
)

print()
print(
    "Prepared trade file saved to:",
    OUTPUT_FILE
)

print()
print("TRADE PREPARATION COMPLETE")