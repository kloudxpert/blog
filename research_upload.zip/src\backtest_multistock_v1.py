import math
import os
from datetime import date, time

import pandas as pd


# =========================================================
# CONFIGURATION
# =========================================================

SYMBOLS = [
    "SBIN",
    "RELIANCE",
    "HDFCBANK",
    "ICICIBANK",
    "INFY",
    "TCS",
    "LT",
    "AXISBANK",
    "BHARTIARTL",
    "ITC",
]

DATA_DIR = r"data\multistock"
RESULTS_DIR = r"results\multistock"

os.makedirs(
    RESULTS_DIR,
    exist_ok=True,
)

DATE_RANGE = (
    "2025-09-22_to_2026-09-18"
)


# ---------------------------------------------------------
# Strategy V1 - UNCHANGED
# ---------------------------------------------------------

INITIAL_CAPITAL = 200000.0

RISK_PERCENT = 0.005

TARGET_R_MULTIPLE = 2.0

GAP_ATR_MULTIPLE = 0.5

ENTRY_START = time(9, 30)
ENTRY_END = time(14, 45)

# Exit by approximately 15:15.
# Using close of 15:10-15:15 candle.
TIME_EXIT_CANDLE = "15:10"

# Exclude special shortened session
EXCLUDED_DATES = {
    date(2025, 10, 21),
}


# =========================================================
# BUILD INDICATORS
# =========================================================

def build_indicators(df):

    df = df.copy()

    df = (
        df
        .sort_values("timestamp")
        .reset_index(drop=True)
    )

    df["trade_date"] = (
        df["timestamp"].dt.date
    )

    df["trade_time"] = (
        df["timestamp"].dt.time
    )


    # -----------------------------------------------------
    # VWAP - daily reset
    # -----------------------------------------------------

    df["typical_price"] = (
        df["high"]
        + df["low"]
        + df["close"]
    ) / 3.0


    df["price_x_volume"] = (
        df["typical_price"]
        * df["volume"]
    )


    df["cum_volume"] = (
        df
        .groupby(
            "trade_date"
        )["volume"]
        .cumsum()
    )


    df["cum_price_x_volume"] = (
        df
        .groupby(
            "trade_date"
        )["price_x_volume"]
        .cumsum()
    )


    df["vwap"] = (
        df["cum_price_x_volume"]
        / df["cum_volume"]
    )


    # -----------------------------------------------------
    # EMA 9
    # -----------------------------------------------------

    df["ema9"] = (
        df["close"]
        .ewm(
            span=9,
            adjust=False,
        )
        .mean()
    )


    # -----------------------------------------------------
    # EMA 20
    # -----------------------------------------------------

    df["ema20"] = (
        df["close"]
        .ewm(
            span=20,
            adjust=False,
        )
        .mean()
    )


    # -----------------------------------------------------
    # ATR 14
    # -----------------------------------------------------

    previous_close = (
        df["close"]
        .shift(1)
    )


    high_low = (
        df["high"]
        - df["low"]
    )


    high_prev_close = (
        df["high"]
        - previous_close
    ).abs()


    low_prev_close = (
        df["low"]
        - previous_close
    ).abs()


    df["true_range"] = (
        pd.concat(
            [
                high_low,
                high_prev_close,
                low_prev_close,
            ],
            axis=1,
        )
        .max(axis=1)
    )


    df["atr14"] = (
        df["true_range"]
        .ewm(
            alpha=1 / 14,
            adjust=False,
            min_periods=14,
        )
        .mean()
    )


    # -----------------------------------------------------
    # Previous 10-candle average volume
    # -----------------------------------------------------

    df["avg_volume_prev10"] = (
        df
        .groupby(
            "trade_date"
        )["volume"]
        .transform(
            lambda s:
            s.shift(1)
            .rolling(
                window=10,
                min_periods=10,
            )
            .mean()
        )
    )


    # -----------------------------------------------------
    # Previous 5-candle highest high
    # -----------------------------------------------------

    df["highest_high_prev5"] = (
        df
        .groupby(
            "trade_date"
        )["high"]
        .transform(
            lambda s:
            s.shift(1)
            .rolling(
                window=5,
                min_periods=5,
            )
            .max()
        )
    )


    # -----------------------------------------------------
    # Previous 5-candle lowest low
    # -----------------------------------------------------

    df["lowest_low_prev5"] = (
        df
        .groupby(
            "trade_date"
        )["low"]
        .transform(
            lambda s:
            s.shift(1)
            .rolling(
                window=5,
                min_periods=5,
            )
            .min()
        )
    )


    return df


# =========================================================
# BUILD TRADE CANDIDATES
# =========================================================

def build_candidates(df):

    df = df.copy()


    # -----------------------------------------------------
    # Normal trading session
    # -----------------------------------------------------

    df["normal_session"] = (
        ~df["trade_date"]
        .isin(
            EXCLUDED_DATES
        )
    )


    # -----------------------------------------------------
    # Entry window
    # -----------------------------------------------------

    df["within_entry_window"] = (
        (
            df["trade_time"]
            >= ENTRY_START
        )
        &
        (
            df["trade_time"]
            <= ENTRY_END
        )
    )


    # -----------------------------------------------------
    # Four Strategy V1 conditions
    # -----------------------------------------------------

    df["condition_vwap"] = (
        df["close"]
        > df["vwap"]
    )


    df["condition_ema"] = (
        df["ema9"]
        > df["ema20"]
    )


    df["condition_volume"] = (
        df["volume"]
        >
        1.5
        * df["avg_volume_prev10"]
    )


    df["condition_breakout"] = (
        df["close"]
        >
        df["highest_high_prev5"]
    )


    # -----------------------------------------------------
    # Indicators available
    # -----------------------------------------------------

    df["indicators_ready"] = (
        df["vwap"].notna()
        & df["ema9"].notna()
        & df["ema20"].notna()
        & df["atr14"].notna()
        & df[
            "avg_volume_prev10"
        ].notna()
        & df[
            "highest_high_prev5"
        ].notna()
        & df[
            "lowest_low_prev5"
        ].notna()
    )


    # -----------------------------------------------------
    # Raw signal
    # -----------------------------------------------------

    df["long_signal"] = (
        df["normal_session"]
        & df["within_entry_window"]
        & df["indicators_ready"]
        & df["condition_vwap"]
        & df["condition_ema"]
        & df["condition_volume"]
        & df["condition_breakout"]
    )


    # -----------------------------------------------------
    # Next candle from same trading day
    # -----------------------------------------------------

    grouped = (
        df.groupby(
            "trade_date"
        )
    )


    df["next_timestamp"] = (
        grouped[
            "timestamp"
        ]
        .shift(-1)
    )


    df["next_open"] = (
        grouped[
            "open"
        ]
        .shift(-1)
    )


    # -----------------------------------------------------
    # Raw signals
    # -----------------------------------------------------

    signals = (
        df[
            df["long_signal"]
        ]
        .copy()
    )


    signals["entry_timestamp"] = (
        signals[
            "next_timestamp"
        ]
    )


    signals["entry_price"] = (
        signals[
            "next_open"
        ]
    )


    signals["entry_time"] = (
        signals[
            "entry_timestamp"
        ].dt.time
    )


    # -----------------------------------------------------
    # Actual entry must also be <= 14:45
    # -----------------------------------------------------

    signals["entry_within_window"] = (
        signals[
            "entry_timestamp"
        ].notna()
        &
        (
            signals[
                "entry_time"
            ]
            <= ENTRY_END
        )
    )


    signals[
        "next_candle_available"
    ] = (
        signals[
            "entry_timestamp"
        ].notna()
        &
        signals[
            "entry_price"
        ].notna()
    )


    # -----------------------------------------------------
    # Gap filter
    # -----------------------------------------------------

    signals["entry_gap"] = (
        signals["entry_price"]
        - signals["close"]
    )


    signals["max_allowed_gap"] = (
        GAP_ATR_MULTIPLE
        * signals["atr14"]
    )


    signals["gap_filter_pass"] = (
        signals["entry_gap"]
        <= signals[
            "max_allowed_gap"
        ]
    )


    candidates = (
        signals[
            signals[
                "next_candle_available"
            ]
            & signals[
                "entry_within_window"
            ]
            & signals[
                "gap_filter_pass"
            ]
        ]
        .copy()
    )


    return (
        signals,
        candidates,
    )


# =========================================================
# PREPARE ONE TRADE PER STOCK PER DAY
# =========================================================

def prepare_trades(candidates):

    candidates = (
        candidates
        .sort_values(
            "entry_timestamp"
        )
        .reset_index(drop=True)
    )


    # -----------------------------------------------------
    # Earliest valid signal only
    # -----------------------------------------------------

    trades = (
        candidates
        .groupby(
            "trade_date",
            as_index=False,
        )
        .first()
        .sort_values(
            "entry_timestamp"
        )
        .reset_index(drop=True)
    )


    # -----------------------------------------------------
    # Stop calculations
    # -----------------------------------------------------

    trades["atr_stop"] = (
        trades["entry_price"]
        - trades["atr14"]
    )


    trades["swing_stop"] = (
        trades[
            "lowest_low_prev5"
        ]
    )


    # Strategy V1:
    # use LOWER of ATR stop and swing stop
    trades["stop_price"] = (
        trades[
            [
                "atr_stop",
                "swing_stop",
            ]
        ]
        .min(axis=1)
    )


    trades["risk_per_share"] = (
        trades["entry_price"]
        - trades["stop_price"]
    )


    # -----------------------------------------------------
    # Validate risk before quantity calculation
    # -----------------------------------------------------

    trades = (
        trades[
            trades[
                "risk_per_share"
            ]
            > 0
        ]
        .copy()
    )


    risk_budget = (
        INITIAL_CAPITAL
        * RISK_PERCENT
    )


    trades["risk_budget"] = (
        risk_budget
    )


    trades[
        "quantity_by_risk"
    ] = (
        trades[
            "risk_budget"
        ]
        / trades[
            "risk_per_share"
        ]
    ).apply(
        math.floor
    )


    trades[
        "quantity_by_cash"
    ] = (
        INITIAL_CAPITAL
        / trades[
            "entry_price"
        ]
    ).apply(
        math.floor
    )


    trades["quantity"] = (
        trades[
            [
                "quantity_by_risk",
                "quantity_by_cash",
            ]
        ]
        .min(axis=1)
    )


    trades = (
        trades[
            trades[
                "quantity"
            ]
            > 0
        ]
        .copy()
    )


    trades["planned_risk"] = (
        trades["quantity"]
        * trades[
            "risk_per_share"
        ]
    )


    trades["target_price"] = (
        trades["entry_price"]
        +
        TARGET_R_MULTIPLE
        * trades[
            "risk_per_share"
        ]
    )


    return trades


# =========================================================
# BACKTEST ONE SYMBOL
# =========================================================

def backtest_symbol(
    symbol,
    prices,
    trades,
):

    results = []


    prices = prices.copy()

    prices["trade_clock"] = (
        prices["timestamp"]
        .dt.strftime("%H:%M")
    )


    for _, trade in trades.iterrows():

        trade_date = (
            trade["trade_date"]
        )


        entry_timestamp = (
            trade[
                "entry_timestamp"
            ]
        )


        entry_price = float(
            trade[
                "entry_price"
            ]
        )


        stop_price = float(
            trade[
                "stop_price"
            ]
        )


        target_price = float(
            trade[
                "target_price"
            ]
        )


        quantity = int(
            trade[
                "quantity"
            ]
        )


        planned_risk = float(
            trade[
                "planned_risk"
            ]
        )


        # -------------------------------------------------
        # Candles from entry through 15:10
        # -------------------------------------------------

        day_prices = (
            prices[
                (
                    prices[
                        "trade_date"
                    ]
                    == trade_date
                )
                &
                (
                    prices[
                        "timestamp"
                    ]
                    >= entry_timestamp
                )
                &
                (
                    prices[
                        "trade_clock"
                    ]
                    <= TIME_EXIT_CANDLE
                )
            ]
            .copy()
        )


        if day_prices.empty:

            raise RuntimeError(
                f"{symbol}: "
                f"no usable candles "
                f"for {trade_date}"
            )


        time_exit_rows = (
            day_prices[
                day_prices[
                    "trade_clock"
                ]
                == TIME_EXIT_CANDLE
            ]
        )


        if time_exit_rows.empty:

            raise RuntimeError(
                f"{symbol}: "
                f"15:10 candle missing "
                f"for {trade_date}"
            )


        exit_timestamp = None
        exit_price = None
        exit_reason = None

        both_hit_same_candle = (
            False
        )


        # -------------------------------------------------
        # Candle-by-candle simulation
        # -------------------------------------------------

        for _, candle in (
            day_prices.iterrows()
        ):

            candle_timestamp = (
                candle["timestamp"]
            )


            candle_high = float(
                candle["high"]
            )


            candle_low = float(
                candle["low"]
            )


            stop_hit = (
                candle_low
                <= stop_price
            )


            target_hit = (
                candle_high
                >= target_price
            )


            # ---------------------------------------------
            # Conservative same-candle rule
            # ---------------------------------------------

            if (
                stop_hit
                and target_hit
            ):

                exit_timestamp = (
                    candle_timestamp
                )

                exit_price = (
                    stop_price
                )

                exit_reason = (
                    "STOP"
                )

                both_hit_same_candle = (
                    True
                )

                break


            # ---------------------------------------------
            # Stop
            # ---------------------------------------------

            if stop_hit:

                exit_timestamp = (
                    candle_timestamp
                )

                exit_price = (
                    stop_price
                )

                exit_reason = (
                    "STOP"
                )

                break


            # ---------------------------------------------
            # Target
            # ---------------------------------------------

            if target_hit:

                exit_timestamp = (
                    candle_timestamp
                )

                exit_price = (
                    target_price
                )

                exit_reason = (
                    "TARGET"
                )

                break


        # -------------------------------------------------
        # Time exit
        # -------------------------------------------------

        if exit_reason is None:

            last_candle = (
                time_exit_rows
                .iloc[-1]
            )


            exit_timestamp = (
                last_candle[
                    "timestamp"
                ]
            )


            exit_price = float(
                last_candle[
                    "close"
                ]
            )


            exit_reason = (
                "TIME_EXIT"
            )


        # -------------------------------------------------
        # P&L
        # -------------------------------------------------

        gross_pnl_per_share = (
            exit_price
            - entry_price
        )


        gross_pnl = (
            gross_pnl_per_share
            * quantity
        )


        if planned_risk > 0:

            r_multiple = (
                gross_pnl
                / planned_risk
            )

        else:

            r_multiple = 0.0


        holding_minutes = (
            (
                exit_timestamp
                - entry_timestamp
            )
            .total_seconds()
            / 60
        )


        results.append(
            {
                "symbol":
                    symbol,

                "trade_date":
                    trade_date,

                "signal_timestamp":
                    trade[
                        "timestamp"
                    ],

                "entry_timestamp":
                    entry_timestamp,

                "entry_price":
                    entry_price,

                "stop_price":
                    stop_price,

                "target_price":
                    target_price,

                "quantity":
                    quantity,

                "planned_risk":
                    planned_risk,

                "exit_timestamp":
                    exit_timestamp,

                "exit_price":
                    exit_price,

                "exit_reason":
                    exit_reason,

                "holding_minutes":
                    holding_minutes,

                "gross_pnl":
                    gross_pnl,

                "r_multiple":
                    r_multiple,

                "both_hit_same_candle":
                    both_hit_same_candle,
            }
        )


    return pd.DataFrame(
        results
    )


# =========================================================
# SUMMARIZE ONE STOCK
# =========================================================

def summarize_symbol(
    symbol,
    raw_signals,
    candidates,
    trades,
    results,
):

    total_trades = len(
        results
    )


    wins = int(
        (
            results[
                "gross_pnl"
            ]
            > 0
        ).sum()
    )


    losses = int(
        (
            results[
                "gross_pnl"
            ]
            < 0
        ).sum()
    )


    breakeven = int(
        (
            results[
                "gross_pnl"
            ]
            == 0
        ).sum()
    )


    win_rate = (
        wins
        / total_trades
        * 100
        if total_trades > 0
        else 0
    )


    gross_profit = (
        results.loc[
            results[
                "gross_pnl"
            ]
            > 0,
            "gross_pnl",
        ].sum()
    )


    gross_loss = (
        -results.loc[
            results[
                "gross_pnl"
            ]
            < 0,
            "gross_pnl",
        ].sum()
    )


    if gross_loss > 0:

        profit_factor = (
            gross_profit
            / gross_loss
        )

    else:

        profit_factor = (
            float("inf")
        )


    total_pnl = (
        results[
            "gross_pnl"
        ].sum()
    )


    average_r = (
        results[
            "r_multiple"
        ].mean()
    )


    # -----------------------------------------------------
    # Drawdown
    # -----------------------------------------------------

    equity = (
        INITIAL_CAPITAL
        + results[
            "gross_pnl"
        ].cumsum()
    )


    equity_peak = (
        equity.cummax()
    )


    drawdown = (
        equity
        - equity_peak
    )


    drawdown_percent = (
        drawdown
        / equity_peak
        * 100
    )


    max_drawdown = (
        drawdown.min()
    )


    max_drawdown_percent = (
        drawdown_percent.min()
    )


    # -----------------------------------------------------
    # Exit counts
    # -----------------------------------------------------

    stop_count = int(
        (
            results[
                "exit_reason"
            ]
            == "STOP"
        ).sum()
    )


    target_count = int(
        (
            results[
                "exit_reason"
            ]
            == "TARGET"
        ).sum()
    )


    time_exit_count = int(
        (
            results[
                "exit_reason"
            ]
            == "TIME_EXIT"
        ).sum()
    )


    same_candle_count = int(
        results[
            "both_hit_same_candle"
        ].sum()
    )


    # -----------------------------------------------------
    # Monthly performance
    # -----------------------------------------------------

    monthly_df = (
        results.copy()
    )


    monthly_df["month"] = (
        monthly_df[
            "entry_timestamp"
        ]
        .dt.strftime(
            "%Y-%m"
        )
    )


    monthly_pnl = (
        monthly_df
        .groupby(
            "month"
        )["gross_pnl"]
        .sum()
    )


    positive_months = int(
        (
            monthly_pnl
            > 0
        ).sum()
    )


    negative_months = int(
        (
            monthly_pnl
            < 0
        ).sum()
    )


    # -----------------------------------------------------
    # Cash versus risk limitation
    # -----------------------------------------------------

    cash_limited = int(
        (
            trades[
                "quantity_by_cash"
            ]
            <
            trades[
                "quantity_by_risk"
            ]
        ).sum()
    )


    return {
        "symbol":
            symbol,

        "raw_signals":
            len(raw_signals),

        "valid_candidates":
            len(candidates),

        "trades":
            total_trades,

        "wins":
            wins,

        "losses":
            losses,

        "breakeven":
            breakeven,

        "win_rate":
            win_rate,

        "stop_exits":
            stop_count,

        "target_exits":
            target_count,

        "time_exits":
            time_exit_count,

        "gross_profit":
            gross_profit,

        "gross_loss":
            gross_loss,

        "gross_pnl":
            total_pnl,

        "profit_factor":
            profit_factor,

        "average_r":
            average_r,

        "max_drawdown":
            max_drawdown,

        "max_drawdown_percent":
            max_drawdown_percent,

        "positive_months":
            positive_months,

        "negative_months":
            negative_months,

        "cash_limited_trades":
            cash_limited,

        "same_candle_cases":
            same_candle_count,
    }


# =========================================================
# MAIN
# =========================================================

summary_rows = []

all_results = []


for symbol in SYMBOLS:

    print()
    print("=" * 78)
    print(
        f"PROCESSING {symbol}"
    )
    print("=" * 78)


    input_file = (
        rf"{DATA_DIR}\{symbol}_5min_"
        rf"{DATE_RANGE}_clean.csv"
    )


    if not os.path.exists(
        input_file
    ):

        raise FileNotFoundError(
            f"Missing file: "
            f"{input_file}"
        )


    # -----------------------------------------------------
    # Load
    # -----------------------------------------------------

    prices = pd.read_csv(
        input_file
    )


    prices["timestamp"] = (
        pd.to_datetime(
            prices[
                "timestamp"
            ]
        )
    )


    # -----------------------------------------------------
    # Indicators
    # -----------------------------------------------------

    indicator_df = (
        build_indicators(
            prices
        )
    )


    # -----------------------------------------------------
    # Signals / candidates
    # -----------------------------------------------------

    (
        raw_signals,
        candidates,
    ) = build_candidates(
        indicator_df
    )


    # -----------------------------------------------------
    # One trade per day + risk sizing
    # -----------------------------------------------------

    prepared_trades = (
        prepare_trades(
            candidates
        )
    )


    # -----------------------------------------------------
    # Backtest
    # -----------------------------------------------------

    results = (
        backtest_symbol(
            symbol,
            indicator_df,
            prepared_trades,
        )
    )


    if results.empty:

        raise RuntimeError(
            f"{symbol}: "
            f"no backtest trades generated."
        )


    # -----------------------------------------------------
    # Save prepared trades
    # -----------------------------------------------------

    prepared_file = (
        rf"{RESULTS_DIR}\{symbol}_"
        rf"strategy_v1_prepared_trades.csv"
    )


    prepared_trades.to_csv(
        prepared_file,
        index=False,
    )


    # -----------------------------------------------------
    # Save backtest results
    # -----------------------------------------------------

    backtest_file = (
        rf"{RESULTS_DIR}\{symbol}_"
        rf"strategy_v1_backtest_gross.csv"
    )


    results.to_csv(
        backtest_file,
        index=False,
    )


    # -----------------------------------------------------
    # Summary
    # -----------------------------------------------------

    summary = summarize_symbol(
        symbol,
        raw_signals,
        candidates,
        prepared_trades,
        results,
    )


    summary_rows.append(
        summary
    )


    all_results.append(
        results
    )


    print(
        "Raw signals:",
        len(raw_signals)
    )

    print(
        "Valid candidates:",
        len(candidates)
    )

    print(
        "Prepared trades:",
        len(prepared_trades)
    )

    print(
        "Gross P&L: ₹",
        f"{summary['gross_pnl']:,.2f}",
        sep=""
    )

    print(
        "Profit factor:",
        f"{summary['profit_factor']:.3f}"
    )

    print(
        "Average R:",
        f"{summary['average_r']:.3f}R"
    )


# =========================================================
# COMBINED RESULTS
# =========================================================

summary_df = pd.DataFrame(
    summary_rows
)


all_results_df = pd.concat(
    all_results,
    ignore_index=True,
)


SUMMARY_FILE = (
    r"results\multistock"
    r"\strategy_v1_multistock_summary.csv"
)


ALL_TRADES_FILE = (
    r"results\multistock"
    r"\strategy_v1_all_trades.csv"
)


summary_df.to_csv(
    SUMMARY_FILE,
    index=False,
)


all_results_df.to_csv(
    ALL_TRADES_FILE,
    index=False,
)


# =========================================================
# DISPLAY SUMMARY
# =========================================================

print()
print("=" * 120)
print(
    "STRATEGY V1 - 10 STOCK ONE-YEAR GROSS BACKTEST"
)
print("=" * 120)


display_columns = [
    "symbol",
    "trades",
    "win_rate",
    "stop_exits",
    "target_exits",
    "time_exits",
    "gross_pnl",
    "profit_factor",
    "average_r",
    "max_drawdown_percent",
    "positive_months",
    "negative_months",
]


display_df = (
    summary_df[
        display_columns
    ]
    .copy()
)


for column in [
    "win_rate",
    "gross_pnl",
    "profit_factor",
    "average_r",
    "max_drawdown_percent",
]:

    display_df[column] = (
        display_df[column]
        .round(3)
    )


print(
    display_df.to_string(
        index=False
    )
)


# =========================================================
# CROSS-STOCK DIAGNOSTICS
#
# Important:
# This is NOT a portfolio backtest.
# Trades from different stocks can overlap.
# =========================================================

positive_expectancy_stocks = int(
    (
        summary_df[
            "average_r"
        ]
        > 0
    ).sum()
)


negative_expectancy_stocks = int(
    (
        summary_df[
            "average_r"
        ]
        < 0
    ).sum()
)


pf_above_one = int(
    (
        summary_df[
            "profit_factor"
        ]
        > 1
    ).sum()
)


total_independent_trades = (
    len(
        all_results_df
    )
)


pooled_average_r = (
    all_results_df[
        "r_multiple"
    ].mean()
)


pooled_gross_profit = (
    all_results_df.loc[
        all_results_df[
            "gross_pnl"
        ]
        > 0,
        "gross_pnl",
    ].sum()
)


pooled_gross_loss = (
    -all_results_df.loc[
        all_results_df[
            "gross_pnl"
        ]
        < 0,
        "gross_pnl",
    ].sum()
)


pooled_profit_factor = (
    pooled_gross_profit
    / pooled_gross_loss
    if pooled_gross_loss > 0
    else float("inf")
)


print()
print(
    "CROSS-STOCK DIAGNOSTICS "
    "(NOT A PORTFOLIO BACKTEST)"
)

print(
    "Stocks with positive average R:",
    positive_expectancy_stocks
)

print(
    "Stocks with negative average R:",
    negative_expectancy_stocks
)

print(
    "Stocks with profit factor > 1:",
    pf_above_one
)

print(
    "Total independent trades:",
    total_independent_trades
)

print(
    "Pooled average R:",
    f"{pooled_average_r:.3f}R"
)

print(
    "Pooled gross profit factor:",
    f"{pooled_profit_factor:.3f}"
)


# =========================================================
# SBIN INTEGRITY CHECK
# =========================================================

sbin_row = (
    summary_df[
        summary_df[
            "symbol"
        ]
        == "SBIN"
    ]
)


if not sbin_row.empty:

    row = (
        sbin_row.iloc[0]
    )

    print()
    print(
        "SBIN INTEGRITY CHECK"
    )

    print(
        "Expected previous trade count: 170"
    )

    print(
        "Current trade count:",
        int(
            row[
                "trades"
            ]
        )
    )

    print(
        "Expected previous gross P&L: approximately -₹1,208"
    )

    print(
        "Current gross P&L: ₹",
        f"{row['gross_pnl']:,.2f}",
        sep=""
    )

    print(
        "Expected previous PF: approximately 0.982"
    )

    print(
        "Current PF:",
        f"{row['profit_factor']:.3f}"
    )


print()
print(
    "Summary saved to:"
)

print(
    SUMMARY_FILE
)


print()
print(
    "All independent trades saved to:"
)

print(
    ALL_TRADES_FILE
)


print()
print(
    "MULTI-STOCK STRATEGY V1 BACKTEST COMPLETE"
)