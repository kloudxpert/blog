from datetime import date, time

import pandas as pd


# ---------------------------------------------------------
# Files
# ---------------------------------------------------------

INPUT_FILE = (
    r"data\SBIN_5min_"
    r"2025-09-22_to_2026-09-18_indicators.csv"
)

OUTPUT_FILE = (
    r"results\SBIN_strategy_v1_1year_signals.csv"
)


# ---------------------------------------------------------
# Special sessions excluded from normal strategy testing
# ---------------------------------------------------------

EXCLUDED_DATES = {
    date(2025, 10, 21),  # Diwali Muhurat Trading
}


# ---------------------------------------------------------
# Load data
# ---------------------------------------------------------

df = pd.read_csv(INPUT_FILE)

df["timestamp"] = pd.to_datetime(
    df["timestamp"]
)

df = (
    df
    .sort_values("timestamp")
    .reset_index(drop=True)
)

df["trade_date"] = (
    df["timestamp"].dt.date
)

df["trade_time"] = (
    df["timestamp"].dt.time
)


# ---------------------------------------------------------
# Exclude special trading sessions
# ---------------------------------------------------------

df["normal_session"] = (
    ~df["trade_date"].isin(
        EXCLUDED_DATES
    )
)


# ---------------------------------------------------------
# Strategy V1 trading window
# ---------------------------------------------------------

ENTRY_START = time(9, 30)
ENTRY_END = time(14, 45)


df["within_entry_window"] = (
    (df["trade_time"] >= ENTRY_START)
    & (df["trade_time"] <= ENTRY_END)
)


# ---------------------------------------------------------
# Strategy V1 conditions
# ---------------------------------------------------------

# Condition 1:
# Price above VWAP
df["condition_vwap"] = (
    df["close"] > df["vwap"]
)


# Condition 2:
# EMA9 above EMA20
df["condition_ema"] = (
    df["ema9"] > df["ema20"]
)


# Condition 3:
# Current volume >
# 1.5 x average previous 10 candles
df["condition_volume"] = (
    df["volume"]
    > 1.5 * df["avg_volume_prev10"]
)


# Condition 4:
# Close breaks above previous
# 5-candle highest high
df["condition_breakout"] = (
    df["close"]
    > df["highest_high_prev5"]
)


# ---------------------------------------------------------
# All indicators must be available
# ---------------------------------------------------------

df["indicators_ready"] = (
    df["vwap"].notna()
    & df["ema9"].notna()
    & df["ema20"].notna()
    & df["atr14"].notna()
    & df[
        "avg_volume_prev10"
    ].notna()
    & df[
        "highest_high_prev5"
    ].notna()
    & df[
        "lowest_low_prev5"
    ].notna()
)


# ---------------------------------------------------------
# Raw Strategy V1 signal
# ---------------------------------------------------------

df["long_signal"] = (
    df["normal_session"]
    & df["within_entry_window"]
    & df["indicators_ready"]
    & df["condition_vwap"]
    & df["condition_ema"]
    & df["condition_volume"]
    & df["condition_breakout"]
)


# ---------------------------------------------------------
# Eligible candles
# ---------------------------------------------------------

eligible = df[
    df["normal_session"]
    & df["within_entry_window"]
    & df["indicators_ready"]
].copy()


# ---------------------------------------------------------
# Signals
# ---------------------------------------------------------

signals = df[
    df["long_signal"]
].copy()


# ---------------------------------------------------------
# Summary
# ---------------------------------------------------------

print("=" * 70)
print(
    "SBIN STRATEGY V1 - ONE-YEAR SIGNAL ANALYSIS"
)
print("=" * 70)


print(
    "Total candles:",
    len(df)
)

print(
    "Normal trading days:",
    df.loc[
        df["normal_session"],
        "trade_date",
    ].nunique()
)

print(
    "Excluded special-session days:",
    len(EXCLUDED_DATES)
)

print(
    "Candles eligible for evaluation:",
    len(eligible)
)


print()
print("Individual condition counts:")


print(
    "Close > VWAP:",
    int(
        eligible[
            "condition_vwap"
        ].sum()
    )
)


print(
    "EMA9 > EMA20:",
    int(
        eligible[
            "condition_ema"
        ].sum()
    )
)


print(
    "Strong volume:",
    int(
        eligible[
            "condition_volume"
        ].sum()
    )
)


print(
    "5-candle breakout:",
    int(
        eligible[
            "condition_breakout"
        ].sum()
    )
)


print()

print(
    "Candles satisfying ALL 4 conditions:",
    len(signals)
)


print(
    "Trading days containing at least one signal:",
    signals[
        "trade_date"
    ].nunique()
)


# ---------------------------------------------------------
# Signals per month
# ---------------------------------------------------------

if not signals.empty:

    signals["month"] = (
        signals["timestamp"]
        .dt.to_period("M")
        .astype(str)
    )


    monthly_summary = (
        signals
        .groupby("month")
        .size()
        .reset_index(
            name="signal_count"
        )
    )


    print()
    print("Signals by month:")

    print(
        monthly_summary.to_string(
            index=False
        )
    )


# ---------------------------------------------------------
# Signals per day summary
# ---------------------------------------------------------

if not signals.empty:

    signals_per_day = (
        signals
        .groupby("trade_date")
        .size()
    )


    print()
    print("Signals/day statistics:")

    print(
        signals_per_day
        .describe()
        .round(2)
    )


# ---------------------------------------------------------
# First signals
# ---------------------------------------------------------

if not signals.empty:

    print()
    print("First 15 raw signals:")


    display_columns = [
        "timestamp",
        "close",
        "vwap",
        "ema9",
        "ema20",
        "volume",
        "avg_volume_prev10",
        "highest_high_prev5",
        "lowest_low_prev5",
        "atr14",
    ]


    print(
        signals[
            display_columns
        ]
        .head(15)
        .to_string(index=False)
    )


# ---------------------------------------------------------
# Save
# ---------------------------------------------------------

save_columns = [
    "timestamp",
    "open",
    "high",
    "low",
    "close",
    "volume",
    "vwap",
    "ema9",
    "ema20",
    "atr14",
    "avg_volume_prev10",
    "highest_high_prev5",
    "lowest_low_prev5",
]


signals[
    save_columns
].to_csv(
    OUTPUT_FILE,
    index=False,
)


print()
print(
    "Signal file saved to:",
    OUTPUT_FILE
)

print()

print(
    "ONE-YEAR SIGNAL ANALYSIS COMPLETE"
)