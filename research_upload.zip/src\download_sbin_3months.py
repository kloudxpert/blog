import os
import time
from datetime import date, datetime, timedelta

import pandas as pd
import pyotp

from dotenv import load_dotenv
from SmartApi import SmartConnect


# ---------------------------------------------------------
# Configuration
# ---------------------------------------------------------

SYMBOL = "SBIN"
SYMBOL_TOKEN = "3045"
EXCHANGE = "NSE"
INTERVAL = "FIVE_MINUTE"

START_DATE = date(2026, 6, 22)
END_DATE = date(2026, 9, 18)

# NSE Closing Auction Session became effective 03-Aug-2026.
CAS_EFFECTIVE_DATE = date(2026, 8, 3)

CHUNK_DAYS = 30
MAX_RETRIES = 3


# ---------------------------------------------------------
# Load credentials
# ---------------------------------------------------------

load_dotenv()

api_key = os.getenv("ANGEL_API_KEY")
client_code = os.getenv("ANGEL_CLIENT_CODE")
mpin = os.getenv("ANGEL_MPIN")
totp_secret = os.getenv("ANGEL_TOTP_SECRET")

required = {
    "ANGEL_API_KEY": api_key,
    "ANGEL_CLIENT_CODE": client_code,
    "ANGEL_MPIN": mpin,
    "ANGEL_TOTP_SECRET": totp_secret,
}

missing = [
    name
    for name, value in required.items()
    if not value
]

if missing:
    raise RuntimeError(
        f"Missing environment variables: {', '.join(missing)}"
    )


# ---------------------------------------------------------
# Login
# ---------------------------------------------------------

print("Logging in to Angel One SmartAPI...")

smart_api = SmartConnect(api_key=api_key)

session = smart_api.generateSession(
    client_code,
    mpin,
    pyotp.TOTP(totp_secret).now(),
)

if not session.get("status"):
    raise RuntimeError(
        f"Login failed: {session.get('message')}"
    )

print("Login successful")


# ---------------------------------------------------------
# Download helper
# ---------------------------------------------------------

def fetch_chunk(chunk_start, chunk_end):

    params = {
        "exchange": EXCHANGE,
        "symboltoken": SYMBOL_TOKEN,
        "interval": INTERVAL,
        "fromdate": f"{chunk_start} 09:15",
        "todate": f"{chunk_end} 15:30",
    }

    for attempt in range(1, MAX_RETRIES + 1):

        try:

            print(
                f"Downloading {chunk_start} to {chunk_end} "
                f"(attempt {attempt})..."
            )

            response = smart_api.getCandleData(params)

            if response.get("status") and response.get("data"):
                return response["data"]

            print(
                "Request failed:",
                response.get("message"),
                response.get("errorcode"),
            )

        except Exception as exc:
            print(
                "Request exception:",
                type(exc).__name__,
                str(exc),
            )

        if attempt < MAX_RETRIES:
            wait_seconds = attempt * 3

            print(
                f"Waiting {wait_seconds} seconds before retry..."
            )

            time.sleep(wait_seconds)

    raise RuntimeError(
        f"Could not download chunk "
        f"{chunk_start} to {chunk_end}"
    )


# ---------------------------------------------------------
# Download in chunks
# ---------------------------------------------------------

all_rows = []

current_date = START_DATE

while current_date <= END_DATE:

    chunk_end = min(
        current_date + timedelta(days=CHUNK_DAYS - 1),
        END_DATE,
    )

    rows = fetch_chunk(
        current_date,
        chunk_end,
    )

    all_rows.extend(rows)

    current_date = chunk_end + timedelta(days=1)

    # Avoid unnecessary rapid requests.
    time.sleep(1.5)


# ---------------------------------------------------------
# Create dataframe
# ---------------------------------------------------------

if not all_rows:
    raise RuntimeError("No historical data downloaded.")

df = pd.DataFrame(
    all_rows,
    columns=[
        "timestamp",
        "open",
        "high",
        "low",
        "close",
        "volume",
    ],
)

df["timestamp"] = pd.to_datetime(df["timestamp"])

df = (
    df
    .drop_duplicates(subset=["timestamp"])
    .sort_values("timestamp")
    .reset_index(drop=True)
)

df["trade_date"] = df["timestamp"].dt.date
df["trade_time"] = df["timestamp"].dt.time


# ---------------------------------------------------------
# Save raw SmartAPI data
# ---------------------------------------------------------

raw_file = (
    r"data\SBIN_5min_"
    r"2026-06-22_to_2026-09-18_raw.csv"
)

df.to_csv(raw_file, index=False)


# ---------------------------------------------------------
# Keep continuous-trading candles only
#
# Before CAS:
#   09:15 through 15:25 = 75 candles
#
# From 03-Aug-2026 for SBIN:
#   09:15 through 15:10 = 72 candles
# ---------------------------------------------------------

market_open = datetime.strptime(
    "09:15",
    "%H:%M",
).time()

old_market_end = datetime.strptime(
    "15:25",
    "%H:%M",
).time()

cas_market_end = datetime.strptime(
    "15:10",
    "%H:%M",
).time()


before_cas = (
    df["trade_date"] < CAS_EFFECTIVE_DATE
)

after_cas = (
    df["trade_date"] >= CAS_EFFECTIVE_DATE
)


keep_before_cas = (
    before_cas
    & (df["trade_time"] >= market_open)
    & (df["trade_time"] <= old_market_end)
)

keep_after_cas = (
    after_cas
    & (df["trade_time"] >= market_open)
    & (df["trade_time"] <= cas_market_end)
)

clean_df = df[
    keep_before_cas | keep_after_cas
].copy()

clean_df = clean_df[
    [
        "timestamp",
        "open",
        "high",
        "low",
        "close",
        "volume",
    ]
]

clean_df.reset_index(
    drop=True,
    inplace=True,
)


clean_file = (
    r"data\SBIN_5min_"
    r"2026-06-22_to_2026-09-18_clean.csv"
)

clean_df.to_csv(
    clean_file,
    index=False,
)


# ---------------------------------------------------------
# Data-quality validation
# ---------------------------------------------------------

quality_rows = []

clean_df["trade_date"] = (
    clean_df["timestamp"].dt.date
)

for trade_date, day_df in clean_df.groupby(
    "trade_date"
):

    if trade_date < CAS_EFFECTIVE_DATE:
        end_time = "15:25"
        expected_count = 75
    else:
        end_time = "15:10"
        expected_count = 72

    expected = pd.date_range(
        start=f"{trade_date} 09:15",
        end=f"{trade_date} {end_time}",
        freq="5min",
        tz="Asia/Kolkata",
    )

    actual = pd.DatetimeIndex(
        day_df["timestamp"]
    )

    missing_timestamps = expected.difference(
        actual
    )

    zero_volume_count = int(
        (day_df["volume"] == 0).sum()
    )

    duplicate_count = int(
        day_df["timestamp"].duplicated().sum()
    )

    actual_count = len(day_df)

    passed = (
        actual_count == expected_count
        and len(missing_timestamps) == 0
        and zero_volume_count == 0
        and duplicate_count == 0
    )

    quality_rows.append(
        {
            "trade_date": trade_date,
            "expected_candles": expected_count,
            "actual_candles": actual_count,
            "missing_candles": len(
                missing_timestamps
            ),
            "zero_volume_candles": zero_volume_count,
            "duplicate_candles": duplicate_count,
            "status": (
                "PASS"
                if passed
                else "REVIEW"
            ),
            "missing_timestamps": "; ".join(
                str(x)
                for x in missing_timestamps
            ),
        }
    )


quality_df = pd.DataFrame(
    quality_rows
)

quality_file = (
    r"results\SBIN_5min_quality_report.csv"
)

quality_df.to_csv(
    quality_file,
    index=False,
)


# ---------------------------------------------------------
# Summary
# ---------------------------------------------------------

passed_days = (
    quality_df["status"] == "PASS"
).sum()

review_days = (
    quality_df["status"] == "REVIEW"
).sum()

print()
print("=" * 60)
print("SBIN HISTORICAL DATA DOWNLOAD COMPLETE")
print("=" * 60)

print(
    "Raw candles downloaded:",
    len(df),
)

print(
    "Continuous-session candles:",
    len(clean_df),
)

print(
    "Trading days found:",
    len(quality_df),
)

print(
    "Days passed validation:",
    passed_days,
)

print(
    "Days requiring review:",
    review_days,
)

print()
print("Raw file:")
print(raw_file)

print()
print("Clean file:")
print(clean_file)

print()
print("Quality report:")
print(quality_file)


if review_days > 0:

    print()
    print("Days requiring review:")

    print(
        quality_df[
            quality_df["status"] == "REVIEW"
        ][
            [
                "trade_date",
                "expected_candles",
                "actual_candles",
                "missing_candles",
                "zero_volume_candles",
            ]
        ].to_string(index=False)
    )

else:

    print()
    print(
        "ALL TRADING DAYS PASSED "
        "DATA QUALITY VALIDATION"
    )


# ---------------------------------------------------------
# Logout
# ---------------------------------------------------------

try:
    smart_api.terminateSession(client_code)
except Exception:
    pass