import pandas as pd


# =========================================================
# FILE
# =========================================================

INPUT_FILE = (
    r"results\multistock"
    r"\strategy_v1_all_trades.csv"
)


# =========================================================
# LOAD
# =========================================================

df = pd.read_csv(INPUT_FILE)

df["entry_timestamp"] = pd.to_datetime(
    df["entry_timestamp"]
)

df["exit_timestamp"] = pd.to_datetime(
    df["exit_timestamp"]
)


# =========================================================
# ENTRY-TIME BUCKET
# =========================================================

minutes = (
    df["entry_timestamp"].dt.hour * 60
    + df["entry_timestamp"].dt.minute
)


def get_time_bucket(value):

    if value < 10 * 60 + 30:
        return "09:30-10:29"

    elif value < 11 * 60 + 30:
        return "10:30-11:29"

    elif value < 12 * 60 + 30:
        return "11:30-12:29"

    elif value < 13 * 60 + 30:
        return "12:30-13:29"

    else:
        return "13:30-14:45"


df["entry_bucket"] = (
    minutes.apply(
        get_time_bucket
    )
)


# =========================================================
# PERFORMANCE BY TIME
# =========================================================

time_summary = (
    df
    .groupby("entry_bucket")
    .agg(
        trades=(
            "gross_pnl",
            "size",
        ),

        wins=(
            "gross_pnl",
            lambda x:
            int((x > 0).sum()),
        ),

        total_pnl=(
            "gross_pnl",
            "sum",
        ),

        average_pnl=(
            "gross_pnl",
            "mean",
        ),

        average_r=(
            "r_multiple",
            "mean",
        ),

        median_r=(
            "r_multiple",
            "median",
        ),
    )
)


time_summary["win_rate"] = (
    time_summary["wins"]
    / time_summary["trades"]
    * 100
)


# =========================================================
# PERFORMANCE BY STOCK + TIME
# =========================================================

stock_time = (
    df
    .groupby(
        [
            "symbol",
            "entry_bucket",
        ]
    )
    .agg(
        trades=(
            "gross_pnl",
            "size",
        ),

        average_r=(
            "r_multiple",
            "mean",
        ),

        total_pnl=(
            "gross_pnl",
            "sum",
        ),
    )
    .reset_index()
)


# =========================================================
# EXIT TYPE
# =========================================================

exit_summary = (
    df
    .groupby("exit_reason")
    .agg(
        trades=(
            "gross_pnl",
            "size",
        ),

        total_pnl=(
            "gross_pnl",
            "sum",
        ),

        average_pnl=(
            "gross_pnl",
            "mean",
        ),

        average_r=(
            "r_multiple",
            "mean",
        ),

        average_holding_minutes=(
            "holding_minutes",
            "mean",
        ),
    )
)


# =========================================================
# MONTHLY CROSS-STOCK RESULT
# =========================================================

df["month"] = (
    df["entry_timestamp"]
    .dt.strftime("%Y-%m")
)


monthly = (
    df
    .groupby("month")
    .agg(
        trades=(
            "gross_pnl",
            "size",
        ),

        wins=(
            "gross_pnl",
            lambda x:
            int((x > 0).sum()),
        ),

        total_pnl=(
            "gross_pnl",
            "sum",
        ),

        average_r=(
            "r_multiple",
            "mean",
        ),
    )
)


monthly["win_rate"] = (
    monthly["wins"]
    / monthly["trades"]
    * 100
)


# =========================================================
# STOCK SUMMARY
# =========================================================

stock_summary = (
    df
    .groupby("symbol")
    .agg(
        trades=(
            "gross_pnl",
            "size",
        ),

        total_pnl=(
            "gross_pnl",
            "sum",
        ),

        average_r=(
            "r_multiple",
            "mean",
        ),

        average_holding_minutes=(
            "holding_minutes",
            "mean",
        ),
    )
)


# =========================================================
# PRINT
# =========================================================

print("=" * 80)
print("STRATEGY V1 - CROSS-STOCK DIAGNOSTIC")
print("=" * 80)

print(
    "Total trades:",
    len(df)
)

print()

print(
    "Overall average R:",
    f"{df['r_multiple'].mean():.3f}R"
)


print()
print("=" * 80)
print("PERFORMANCE BY ENTRY TIME")
print("=" * 80)

print(
    time_summary
    .round(3)
    .to_string()
)


print()
print("=" * 80)
print("PERFORMANCE BY EXIT TYPE")
print("=" * 80)

print(
    exit_summary
    .round(3)
    .to_string()
)


print()
print("=" * 80)
print("MONTHLY CROSS-STOCK PERFORMANCE")
print("=" * 80)

print(
    monthly
    .round(3)
    .to_string()
)


print()
print("=" * 80)
print("PER-STOCK SUMMARY")
print("=" * 80)

print(
    stock_summary
    .round(3)
    .to_string()
)


# =========================================================
# SAVE
# =========================================================

time_summary.to_csv(
    r"results\multistock"
    r"\v1_diagnostic_by_time.csv"
)

stock_time.to_csv(
    r"results\multistock"
    r"\v1_diagnostic_stock_by_time.csv",
    index=False,
)

monthly.to_csv(
    r"results\multistock"
    r"\v1_diagnostic_monthly.csv"
)


print()
print(
    "MULTI-STOCK V1 DIAGNOSTIC COMPLETE"
)