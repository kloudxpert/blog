import pandas as pd


# ---------------------------------------------------------
# Configuration
# ---------------------------------------------------------

PRICE_FILE = (
    r"data\SBIN_5min_"
    r"2025-09-22_to_2026-09-18_clean.csv"
)

TRADE_FILE = (
    r"results\SBIN_strategy_v1_1year_prepared_trades.csv"
)

OUTPUT_FILE = (
    r"results\SBIN_strategy_v1_1year_backtest_gross.csv"
)

INITIAL_CAPITAL = 200000.0

# Strategy V1 requires us to be out around 15:15.
#
# With 5-minute candles, the candle starting at 15:10
# represents trading from approximately 15:10 to 15:15.
TIME_EXIT_CANDLE = "15:10"


# ---------------------------------------------------------
# Load price data
# ---------------------------------------------------------

prices = pd.read_csv(PRICE_FILE)

prices["timestamp"] = pd.to_datetime(
    prices["timestamp"]
)

prices = (
    prices
    .sort_values("timestamp")
    .reset_index(drop=True)
)

prices["trade_date"] = (
    prices["timestamp"].dt.date
)

prices["trade_time"] = (
    prices["timestamp"].dt.strftime("%H:%M")
)


# ---------------------------------------------------------
# Load prepared trades
# ---------------------------------------------------------

trades = pd.read_csv(TRADE_FILE)

trades["timestamp"] = pd.to_datetime(
    trades["timestamp"]
)

trades["entry_timestamp"] = pd.to_datetime(
    trades["entry_timestamp"]
)

trades["trade_date"] = pd.to_datetime(
    trades["trade_date"]
).dt.date

trades = (
    trades
    .sort_values("entry_timestamp")
    .reset_index(drop=True)
)


# ---------------------------------------------------------
# Backtest
# ---------------------------------------------------------

results = []


for _, trade in trades.iterrows():

    trade_date = trade["trade_date"]

    entry_timestamp = trade["entry_timestamp"]

    entry_price = float(
        trade["entry_price"]
    )

    stop_price = float(
        trade["stop_price"]
    )

    target_price = float(
        trade["target_price"]
    )

    quantity = int(
        trade["quantity"]
    )

    planned_risk = float(
        trade["planned_risk"]
    )


    # -----------------------------------------------------
    # Get this day's candles from entry onward,
    # but only through the strategy's 15:10 exit candle.
    # -----------------------------------------------------

    day_prices = prices[
        (prices["trade_date"] == trade_date)
        & (
            prices["timestamp"]
            >= entry_timestamp
        )
        & (
            prices["trade_time"]
            <= TIME_EXIT_CANDLE
        )
    ].copy()


    if day_prices.empty:

        raise RuntimeError(
            f"No usable candles for trade date "
            f"{trade_date}"
        )


    # -----------------------------------------------------
    # Make sure the 15:10 candle exists
    #
    # Since special Muhurat day was already excluded,
    # every Strategy V1 trade should have this candle.
    # -----------------------------------------------------

    time_exit_rows = day_prices[
        day_prices["trade_time"]
        == TIME_EXIT_CANDLE
    ]


    if time_exit_rows.empty:

        raise RuntimeError(
            f"15:10 time-exit candle missing for "
            f"{trade_date}"
        )


    exit_timestamp = None
    exit_price = None
    exit_reason = None

    both_hit_same_candle = False


    # -----------------------------------------------------
    # Walk forward candle-by-candle
    # -----------------------------------------------------

    for _, candle in day_prices.iterrows():

        candle_timestamp = (
            candle["timestamp"]
        )

        candle_high = float(
            candle["high"]
        )

        candle_low = float(
            candle["low"]
        )


        stop_hit = (
            candle_low <= stop_price
        )

        target_hit = (
            candle_high >= target_price
        )


        # -------------------------------------------------
        # If both stop and target appear inside the
        # same 5-minute candle, OHLC cannot tell us
        # which occurred first.
        #
        # Conservative rule:
        # assume STOP occurred first.
        # -------------------------------------------------

        if stop_hit and target_hit:

            exit_timestamp = (
                candle_timestamp
            )

            exit_price = (
                stop_price
            )

            exit_reason = (
                "STOP"
            )

            both_hit_same_candle = True

            break


        # -------------------------------------------------
        # Stop
        # -------------------------------------------------

        if stop_hit:

            exit_timestamp = (
                candle_timestamp
            )

            exit_price = (
                stop_price
            )

            exit_reason = (
                "STOP"
            )

            break


        # -------------------------------------------------
        # Target
        # -------------------------------------------------

        if target_hit:

            exit_timestamp = (
                candle_timestamp
            )

            exit_price = (
                target_price
            )

            exit_reason = (
                "TARGET"
            )

            break


    # -----------------------------------------------------
    # Time exit
    #
    # If neither stop nor target was hit by the end
    # of the 15:10 candle, exit using its close.
    # -----------------------------------------------------

    if exit_reason is None:

        last_candle = (
            time_exit_rows.iloc[-1]
        )

        exit_timestamp = (
            last_candle["timestamp"]
        )

        exit_price = float(
            last_candle["close"]
        )

        exit_reason = (
            "TIME_EXIT"
        )


    # -----------------------------------------------------
    # Gross P&L
    # -----------------------------------------------------

    gross_pnl_per_share = (
        exit_price
        - entry_price
    )

    gross_pnl = (
        gross_pnl_per_share
        * quantity
    )


    # -----------------------------------------------------
    # R multiple
    # -----------------------------------------------------

    if planned_risk > 0:

        r_multiple = (
            gross_pnl
            / planned_risk
        )

    else:

        r_multiple = 0.0


    # -----------------------------------------------------
    # Holding time
    # -----------------------------------------------------

    holding_minutes = (
        (
            exit_timestamp
            - entry_timestamp
        ).total_seconds()
        / 60
    )


    # -----------------------------------------------------
    # Store
    # -----------------------------------------------------

    results.append(
        {
            "trade_date":
                trade_date,

            "signal_timestamp":
                trade["timestamp"],

            "entry_timestamp":
                entry_timestamp,

            "entry_price":
                entry_price,

            "stop_price":
                stop_price,

            "target_price":
                target_price,

            "quantity":
                quantity,

            "planned_risk":
                planned_risk,

            "exit_timestamp":
                exit_timestamp,

            "exit_price":
                exit_price,

            "exit_reason":
                exit_reason,

            "both_hit_same_candle":
                both_hit_same_candle,

            "holding_minutes":
                holding_minutes,

            "gross_pnl_per_share":
                gross_pnl_per_share,

            "gross_pnl":
                gross_pnl,

            "r_multiple":
                r_multiple,
        }
    )


# ---------------------------------------------------------
# Results DataFrame
# ---------------------------------------------------------

results_df = pd.DataFrame(
    results
)


if results_df.empty:

    raise RuntimeError(
        "No backtest results generated."
    )


# ---------------------------------------------------------
# Core statistics
# ---------------------------------------------------------

total_trades = len(
    results_df
)

winning_trades = int(
    (
        results_df["gross_pnl"] > 0
    ).sum()
)

losing_trades = int(
    (
        results_df["gross_pnl"] < 0
    ).sum()
)

breakeven_trades = int(
    (
        results_df["gross_pnl"] == 0
    ).sum()
)


win_rate = (
    winning_trades
    / total_trades
    * 100
)


gross_profit = (
    results_df.loc[
        results_df["gross_pnl"] > 0,
        "gross_pnl",
    ].sum()
)


gross_loss = (
    -results_df.loc[
        results_df["gross_pnl"] < 0,
        "gross_pnl",
    ].sum()
)


if gross_loss > 0:

    profit_factor = (
        gross_profit
        / gross_loss
    )

else:

    profit_factor = float("inf")


total_gross_pnl = (
    results_df[
        "gross_pnl"
    ].sum()
)


average_trade = (
    results_df[
        "gross_pnl"
    ].mean()
)


average_r = (
    results_df[
        "r_multiple"
    ].mean()
)


average_winner = (
    results_df.loc[
        results_df["gross_pnl"] > 0,
        "gross_pnl",
    ].mean()
)


average_loser = (
    results_df.loc[
        results_df["gross_pnl"] < 0,
        "gross_pnl",
    ].mean()
)


# ---------------------------------------------------------
# Equity curve
# ---------------------------------------------------------

results_df["equity"] = (
    INITIAL_CAPITAL
    + results_df[
        "gross_pnl"
    ].cumsum()
)


results_df["equity_peak"] = (
    results_df[
        "equity"
    ].cummax()
)


results_df["drawdown"] = (
    results_df["equity"]
    - results_df["equity_peak"]
)


results_df["drawdown_percent"] = (
    results_df["drawdown"]
    / results_df["equity_peak"]
    * 100
)


max_drawdown = (
    results_df[
        "drawdown"
    ].min()
)


max_drawdown_percent = (
    results_df[
        "drawdown_percent"
    ].min()
)


# ---------------------------------------------------------
# Consecutive losses
# ---------------------------------------------------------

max_consecutive_losses = 0
current_losses = 0


for pnl in results_df["gross_pnl"]:

    if pnl < 0:

        current_losses += 1

        max_consecutive_losses = max(
            max_consecutive_losses,
            current_losses,
        )

    else:

        current_losses = 0


# ---------------------------------------------------------
# Exit counts
# ---------------------------------------------------------

exit_counts = (
    results_df[
        "exit_reason"
    ]
    .value_counts()
)


# ---------------------------------------------------------
# Monthly statistics
# ---------------------------------------------------------

results_df["month"] = (
    results_df[
        "entry_timestamp"
    ]
    .dt.strftime("%Y-%m")
)


monthly = (
    results_df
    .groupby("month")
    .agg(
        trades=(
            "gross_pnl",
            "size",
        ),
        wins=(
            "gross_pnl",
            lambda x:
            int((x > 0).sum()),
        ),
        gross_pnl=(
            "gross_pnl",
            "sum",
        ),
        average_r=(
            "r_multiple",
            "mean",
        ),
    )
)


monthly["win_rate"] = (
    monthly["wins"]
    / monthly["trades"]
    * 100
)


# ---------------------------------------------------------
# Positive / negative months
# ---------------------------------------------------------

positive_months = int(
    (
        monthly["gross_pnl"] > 0
    ).sum()
)

negative_months = int(
    (
        monthly["gross_pnl"] < 0
    ).sum()
)

flat_months = int(
    (
        monthly["gross_pnl"] == 0
    ).sum()
)


# ---------------------------------------------------------
# Print
# ---------------------------------------------------------

print("=" * 72)
print(
    "SBIN STRATEGY V1 - ONE-YEAR GROSS BACKTEST"
)
print("=" * 72)


print(
    "Total trades:",
    total_trades
)

print(
    "Winning trades:",
    winning_trades
)

print(
    "Losing trades:",
    losing_trades
)

print(
    "Breakeven trades:",
    breakeven_trades
)

print(
    "Win rate:",
    f"{win_rate:.2f}%"
)


print()
print("Exit reasons:")

for reason, count in exit_counts.items():

    print(
        f"  {reason}: {count}"
    )


print()

print(
    "Gross profit: ₹",
    f"{gross_profit:,.2f}",
    sep=""
)

print(
    "Gross loss: ₹",
    f"{gross_loss:,.2f}",
    sep=""
)

print(
    "Total gross P&L: ₹",
    f"{total_gross_pnl:,.2f}",
    sep=""
)

print(
    "Average P&L / trade: ₹",
    f"{average_trade:,.2f}",
    sep=""
)

print(
    "Average winner: ₹",
    f"{average_winner:,.2f}",
    sep=""
)

print(
    "Average loser: ₹",
    f"{average_loser:,.2f}",
    sep=""
)

print(
    "Profit factor:",
    f"{profit_factor:.3f}"
)

print(
    "Average R / trade:",
    f"{average_r:.3f}R"
)


print()

print(
    "Maximum drawdown: ₹",
    f"{max_drawdown:,.2f}",
    sep=""
)

print(
    "Maximum drawdown:",
    f"{max_drawdown_percent:.2f}%"
)

print(
    "Maximum consecutive losses:",
    max_consecutive_losses
)

print(
    "Same-candle Stop + Target cases:",
    int(
        results_df[
            "both_hit_same_candle"
        ].sum()
    )
)


print()
print("Monthly performance:")

print(
    monthly.round(3).to_string()
)


print()

print(
    "Positive months:",
    positive_months
)

print(
    "Negative months:",
    negative_months
)

print(
    "Flat months:",
    flat_months
)


# ---------------------------------------------------------
# Save
# ---------------------------------------------------------

results_df.to_csv(
    OUTPUT_FILE,
    index=False,
)


print()

print(
    "Backtest results saved to:"
)

print(
    OUTPUT_FILE
)

print()

print(
    "ONE-YEAR GROSS BACKTEST COMPLETE"
)