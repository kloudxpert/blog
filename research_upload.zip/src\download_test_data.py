import os
import pyotp
import pandas as pd

from dotenv import load_dotenv
from SmartApi import SmartConnect

load_dotenv()

api_key = os.getenv("ANGEL_API_KEY")
client_code = os.getenv("ANGEL_CLIENT_CODE")
mpin = os.getenv("ANGEL_MPIN")
totp_secret = os.getenv("ANGEL_TOTP_SECRET")

smart_api = SmartConnect(api_key=api_key)

current_totp = pyotp.TOTP(totp_secret).now()

session = smart_api.generateSession(
    client_code,
    mpin,
    current_totp
)

if not session.get("status"):
    raise RuntimeError(
        f"Login failed: {session.get('message')}"
    )

# SBI is used only for our first data test.
# Angel One's official SDK examples use symbol token 3045 for SBIN-EQ.
candle_params = {
    "exchange": "NSE",
    "symboltoken": "3045",
    "interval": "FIVE_MINUTE",
    "fromdate": "2026-09-18 09:15",
    "todate": "2026-09-18 15:30",
}

response = smart_api.getCandleData(candle_params)

if not response.get("status"):
    raise RuntimeError(
        f"Historical data request failed: "
        f"{response.get('message')} "
        f"{response.get('errorcode')}"
    )

rows = response.get("data")

if not rows:
    raise RuntimeError("No candle data returned.")

df = pd.DataFrame(
    rows,
    columns=[
        "timestamp",
        "open",
        "high",
        "low",
        "close",
        "volume",
    ],
)

output_file = r"data\SBIN_5min_test.csv"

df.to_csv(output_file, index=False)

print()
print("Historical data download successful")
print("Candles downloaded:", len(df))
print("Saved to:", output_file)
print()
print(df.head())
print()
print(df.tail())