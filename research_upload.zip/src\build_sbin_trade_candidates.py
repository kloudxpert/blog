from datetime import time

import pandas as pd


# ---------------------------------------------------------
# Files
# ---------------------------------------------------------

INPUT_FILE = (
    r"data\SBIN_5min_"
    r"2026-06-22_to_2026-09-18_indicators.csv"
)

OUTPUT_FILE = (
    r"results\SBIN_strategy_v1_trade_candidates.csv"
)


# ---------------------------------------------------------
# Load data
# ---------------------------------------------------------

df = pd.read_csv(INPUT_FILE)

df["timestamp"] = pd.to_datetime(df["timestamp"])

df = (
    df
    .sort_values("timestamp")
    .reset_index(drop=True)
)

df["trade_date"] = df["timestamp"].dt.date
df["trade_time"] = df["timestamp"].dt.time


# ---------------------------------------------------------
# Strategy V1 trading window
# ---------------------------------------------------------

ENTRY_START = time(9, 30)
ENTRY_END = time(14, 45)

df["within_entry_window"] = (
    (df["trade_time"] >= ENTRY_START)
    & (df["trade_time"] <= ENTRY_END)
)


# ---------------------------------------------------------
# Strategy V1 entry conditions
# ---------------------------------------------------------

# 1. Price above VWAP
df["condition_vwap"] = (
    df["close"] > df["vwap"]
)

# 2. EMA9 above EMA20
df["condition_ema"] = (
    df["ema9"] > df["ema20"]
)

# 3. Strong volume
df["condition_volume"] = (
    df["volume"]
    > 1.5 * df["avg_volume_prev10"]
)

# 4. Breakout above previous 5-candle high
df["condition_breakout"] = (
    df["close"]
    > df["highest_high_prev5"]
)


# ---------------------------------------------------------
# Indicators ready
# ---------------------------------------------------------

df["indicators_ready"] = (
    df["vwap"].notna()
    & df["ema9"].notna()
    & df["ema20"].notna()
    & df["atr14"].notna()
    & df["avg_volume_prev10"].notna()
    & df["highest_high_prev5"].notna()
    & df["lowest_low_prev5"].notna()
)


# ---------------------------------------------------------
# Raw Strategy V1 long signal
# ---------------------------------------------------------

df["long_signal"] = (
    df["within_entry_window"]
    & df["indicators_ready"]
    & df["condition_vwap"]
    & df["condition_ema"]
    & df["condition_volume"]
    & df["condition_breakout"]
)


# ---------------------------------------------------------
# Get NEXT candle from same trading day
# ---------------------------------------------------------

grouped = df.groupby("trade_date")

df["next_timestamp"] = (
    grouped["timestamp"]
    .shift(-1)
)

df["next_open"] = (
    grouped["open"]
    .shift(-1)
)


# ---------------------------------------------------------
# Extract raw signals
# ---------------------------------------------------------

signals = df[
    df["long_signal"]
].copy()


# ---------------------------------------------------------
# Entry = next candle open
# ---------------------------------------------------------

signals["entry_timestamp"] = (
    signals["next_timestamp"]
)

signals["entry_price"] = (
    signals["next_open"]
)


# ---------------------------------------------------------
# Actual entry time must also be within allowed window
#
# This fixes the case where:
# Signal at 14:45
# Next candle entry at 14:50
#
# Strategy V1 says no new entries after 14:45.
# ---------------------------------------------------------

signals["entry_time"] = (
    signals["entry_timestamp"].dt.time
)

signals["entry_within_window"] = (
    signals["entry_timestamp"].notna()
    & (signals["entry_time"] <= ENTRY_END)
)


# ---------------------------------------------------------
# Gap filter
#
# Entry Gap =
# Next Candle Open - Signal Candle Close
#
# Skip if:
# Entry Gap > 0.5 x ATR
# ---------------------------------------------------------

signals["entry_gap"] = (
    signals["entry_price"]
    - signals["close"]
)

signals["max_allowed_gap"] = (
    0.5 * signals["atr14"]
)

signals["gap_filter_pass"] = (
    signals["entry_gap"]
    <= signals["max_allowed_gap"]
)


# ---------------------------------------------------------
# Valid next candle
# ---------------------------------------------------------

signals["next_candle_available"] = (
    signals["entry_timestamp"].notna()
    & signals["entry_price"].notna()
)


# ---------------------------------------------------------
# Final trade candidates
# ---------------------------------------------------------

candidates = signals[
    signals["next_candle_available"]
    & signals["gap_filter_pass"]
    & signals["entry_within_window"]
].copy()


# ---------------------------------------------------------
# Diagnostics
# ---------------------------------------------------------

print("=" * 70)
print("SBIN STRATEGY V1 TRADE CANDIDATE ANALYSIS")
print("=" * 70)

print(
    "Raw Strategy V1 signals:",
    len(signals)
)

print(
    "Signals with next candle available:",
    int(
        signals[
            "next_candle_available"
        ].sum()
    )
)

print(
    "Signals passing 0.5 ATR gap filter:",
    int(
        (
            signals["next_candle_available"]
            & signals["gap_filter_pass"]
        ).sum()
    )
)

print(
    "Signals rejected by gap filter:",
    int(
        (
            signals["next_candle_available"]
            & ~signals["gap_filter_pass"]
        ).sum()
    )
)

print(
    "Signals rejected because entry was after 14:45:",
    int(
        (
            signals["next_candle_available"]
            & ~signals["entry_within_window"]
        ).sum()
    )
)

print(
    "Final valid trade candidates:",
    len(candidates)
)

print()

print(
    "Trading days containing at least "
    "one valid candidate:",
    candidates["trade_date"].nunique()
)

print()


# ---------------------------------------------------------
# Show late-entry rejections
# ---------------------------------------------------------

late_entries = signals[
    signals["next_candle_available"]
    & ~signals["entry_within_window"]
].copy()

if not late_entries.empty:

    print("Signals rejected because actual entry was too late:")

    print(
        late_entries[
            [
                "timestamp",
                "close",
                "entry_timestamp",
                "entry_price",
            ]
        ]
        .head(10)
        .to_string(index=False)
    )

    print()


# ---------------------------------------------------------
# Show gap-filter rejections
# ---------------------------------------------------------

rejected_gap = signals[
    signals["next_candle_available"]
    & signals["entry_within_window"]
    & ~signals["gap_filter_pass"]
].copy()

if not rejected_gap.empty:

    print("First rejected gap examples:")

    print(
        rejected_gap[
            [
                "timestamp",
                "close",
                "entry_timestamp",
                "entry_price",
                "atr14",
                "entry_gap",
                "max_allowed_gap",
            ]
        ]
        .head(10)
        .to_string(index=False)
    )

    print()


# ---------------------------------------------------------
# Show valid candidates
# ---------------------------------------------------------

if not candidates.empty:

    print("First 15 valid trade candidates:")

    print(
        candidates[
            [
                "timestamp",
                "close",
                "entry_timestamp",
                "entry_price",
                "atr14",
                "entry_gap",
                "max_allowed_gap",
                "lowest_low_prev5",
            ]
        ]
        .head(15)
        .to_string(index=False)
    )


# ---------------------------------------------------------
# Save
# ---------------------------------------------------------

save_columns = [
    "timestamp",
    "trade_date",
    "close",
    "vwap",
    "ema9",
    "ema20",
    "volume",
    "avg_volume_prev10",
    "highest_high_prev5",
    "lowest_low_prev5",
    "atr14",
    "entry_timestamp",
    "entry_price",
    "entry_gap",
    "max_allowed_gap",
]

candidates[
    save_columns
].to_csv(
    OUTPUT_FILE,
    index=False,
)

print()
print(
    "Trade candidate file saved to:",
    OUTPUT_FILE
)

print()
print("TRADE CANDIDATE ANALYSIS COMPLETE")