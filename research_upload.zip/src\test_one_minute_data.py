import os
import pyotp
import pandas as pd

from dotenv import load_dotenv
from SmartApi import SmartConnect

load_dotenv()

api_key = os.getenv("ANGEL_API_KEY")
client_code = os.getenv("ANGEL_CLIENT_CODE")
mpin = os.getenv("ANGEL_MPIN")
totp_secret = os.getenv("ANGEL_TOTP_SECRET")

smart_api = SmartConnect(api_key=api_key)

session = smart_api.generateSession(
    client_code,
    mpin,
    pyotp.TOTP(totp_secret).now()
)

if not session.get("status"):
    raise RuntimeError(session.get("message"))

params = {
    "exchange": "NSE",
    "symboltoken": "3045",
    "interval": "ONE_MINUTE",
    "fromdate": "2026-09-18 15:10",
    "todate": "2026-09-18 15:29",
}

response = smart_api.getCandleData(params)

if not response.get("status") or not response.get("data"):
    raise RuntimeError(
        f"Request failed: {response.get('message')}"
    )

df = pd.DataFrame(
    response["data"],
    columns=[
        "timestamp",
        "open",
        "high",
        "low",
        "close",
        "volume",
    ],
)

df["timestamp"] = pd.to_datetime(df["timestamp"])

expected = pd.date_range(
    start="2026-09-18 15:10",
    end="2026-09-18 15:29",
    freq="1min",
    tz="Asia/Kolkata",
)

missing = expected.difference(
    pd.DatetimeIndex(df["timestamp"])
)

print("Candles returned:", len(df))
print("Expected:", len(expected))
print("Missing:", len(missing))

if len(missing):
    print("\nMissing timestamps:")
    for ts in missing:
        print(ts)

print("\nOne-minute candles:")
print(df.to_string(index=False))