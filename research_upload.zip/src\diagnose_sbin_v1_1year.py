import pandas as pd


PRICE_FILE = (
    r"data\SBIN_5min_"
    r"2025-09-22_to_2026-09-18_clean.csv"
)

BACKTEST_FILE = (
    r"results\SBIN_strategy_v1_1year_backtest_gross.csv"
)

OUTPUT_FILE = (
    r"results\SBIN_strategy_v1_1year_diagnostics.csv"
)


# ---------------------------------------------------------
# Load data
# ---------------------------------------------------------

prices = pd.read_csv(PRICE_FILE)
trades = pd.read_csv(BACKTEST_FILE)

prices["timestamp"] = pd.to_datetime(
    prices["timestamp"]
)

trades["entry_timestamp"] = pd.to_datetime(
    trades["entry_timestamp"]
)

trades["exit_timestamp"] = pd.to_datetime(
    trades["exit_timestamp"]
)

prices["trade_date"] = (
    prices["timestamp"].dt.date
)

trades["trade_date"] = pd.to_datetime(
    trades["trade_date"]
).dt.date


diagnostics = []


# ---------------------------------------------------------
# Analyse every trade
# ---------------------------------------------------------

for _, trade in trades.iterrows():

    entry_price = float(
        trade["entry_price"]
    )

    stop_price = float(
        trade["stop_price"]
    )

    risk_per_share = (
        entry_price - stop_price
    )

    entry_time = (
        trade["entry_timestamp"]
    )

    exit_time = (
        trade["exit_timestamp"]
    )


    # -----------------------------------------------------
    # Examine candles BEFORE the exit candle.
    #
    # We deliberately exclude the exit candle because
    # 5-minute OHLC does not tell us the exact order of
    # movements inside that candle.
    # -----------------------------------------------------

    path = prices[
        (prices["trade_date"] == trade["trade_date"])
        & (prices["timestamp"] >= entry_time)
        & (prices["timestamp"] < exit_time)
    ].copy()


    if not path.empty:

        maximum_high = float(
            path["high"].max()
        )

        minimum_low = float(
            path["low"].min()
        )

        mfe_per_share = (
            maximum_high
            - entry_price
        )

        mae_per_share = (
            entry_price
            - minimum_low
        )

        mfe_r = (
            mfe_per_share
            / risk_per_share
        )

        mae_r = (
            mae_per_share
            / risk_per_share
        )

    else:

        mfe_r = 0.0
        mae_r = 0.0


    holding_minutes = (
        (
            exit_time
            - entry_time
        ).total_seconds()
        / 60
    )


    # -----------------------------------------------------
    # Entry-time bucket
    # -----------------------------------------------------

    total_minutes = (
        entry_time.hour * 60
        + entry_time.minute
    )


    if total_minutes < 10 * 60 + 30:

        entry_bucket = "09:30-10:29"

    elif total_minutes < 11 * 60 + 30:

        entry_bucket = "10:30-11:29"

    elif total_minutes < 12 * 60 + 30:

        entry_bucket = "11:30-12:29"

    elif total_minutes < 13 * 60 + 30:

        entry_bucket = "12:30-13:29"

    else:

        entry_bucket = "13:30-14:45"


    diagnostics.append(
        {
            "trade_date":
                trade["trade_date"],

            "entry_timestamp":
                entry_time,

            "exit_timestamp":
                exit_time,

            "entry_bucket":
                entry_bucket,

            "exit_reason":
                trade["exit_reason"],

            "holding_minutes":
                holding_minutes,

            "gross_pnl":
                float(
                    trade["gross_pnl"]
                ),

            "r_multiple":
                float(
                    trade["r_multiple"]
                ),

            "mfe_r":
                mfe_r,

            "mae_r":
                mae_r,
        }
    )


df = pd.DataFrame(
    diagnostics
)


# ---------------------------------------------------------
# Overall
# ---------------------------------------------------------

print("=" * 72)
print(
    "SBIN STRATEGY V1 - ONE-YEAR DIAGNOSTIC REPORT"
)
print("=" * 72)

print(
    "Trades:",
    len(df)
)


# ---------------------------------------------------------
# Stop timing
# ---------------------------------------------------------

stops = df[
    df["exit_reason"] == "STOP"
].copy()


print()
print("STOP diagnostics:")

print(
    "Total stopped trades:",
    len(stops)
)


for minutes in [
    5,
    15,
    30,
    60,
]:

    count = int(
        (
            stops["holding_minutes"]
            <= minutes
        ).sum()
    )

    percentage = (
        count
        / len(stops)
        * 100
        if len(stops) > 0
        else 0
    )

    print(
        f"Stopped within {minutes} minutes: "
        f"{count} ({percentage:.1f}%)"
    )


# ---------------------------------------------------------
# MFE before stopped trades failed
# ---------------------------------------------------------

print()
print(
    "Stopped trades that first achieved:"
)


for threshold in [
    0.25,
    0.50,
    0.75,
    1.00,
    1.50,
]:

    count = int(
        (
            stops["mfe_r"]
            >= threshold
        ).sum()
    )

    percentage = (
        count
        / len(stops)
        * 100
        if len(stops) > 0
        else 0
    )

    print(
        f"  +{threshold:.2f}R before stop: "
        f"{count} ({percentage:.1f}%)"
    )


# ---------------------------------------------------------
# Performance by entry time
# ---------------------------------------------------------

print()
print("Performance by entry time:")


time_summary = (
    df
    .groupby("entry_bucket")
    .agg(
        trades=(
            "gross_pnl",
            "size",
        ),

        wins=(
            "gross_pnl",
            lambda x:
            int((x > 0).sum()),
        ),

        total_pnl=(
            "gross_pnl",
            "sum",
        ),

        average_pnl=(
            "gross_pnl",
            "mean",
        ),

        average_r=(
            "r_multiple",
            "mean",
        ),

        median_r=(
            "r_multiple",
            "median",
        ),
    )
)


time_summary["win_rate"] = (
    time_summary["wins"]
    / time_summary["trades"]
    * 100
)


print(
    time_summary
    .round(3)
    .to_string()
)


# ---------------------------------------------------------
# Performance by exit reason
# ---------------------------------------------------------

print()
print("Performance by exit reason:")


exit_summary = (
    df
    .groupby("exit_reason")
    .agg(
        trades=(
            "gross_pnl",
            "size",
        ),

        total_pnl=(
            "gross_pnl",
            "sum",
        ),

        average_pnl=(
            "gross_pnl",
            "mean",
        ),

        average_r=(
            "r_multiple",
            "mean",
        ),

        average_holding_minutes=(
            "holding_minutes",
            "mean",
        ),
    )
)


print(
    exit_summary
    .round(3)
    .to_string()
)


# ---------------------------------------------------------
# Performance by month
# ---------------------------------------------------------

df["month"] = (
    df["entry_timestamp"]
    .dt.strftime("%Y-%m")
)


monthly = (
    df
    .groupby("month")
    .agg(
        trades=(
            "gross_pnl",
            "size",
        ),

        wins=(
            "gross_pnl",
            lambda x:
            int((x > 0).sum()),
        ),

        total_pnl=(
            "gross_pnl",
            "sum",
        ),

        average_r=(
            "r_multiple",
            "mean",
        ),

        average_mfe_r=(
            "mfe_r",
            "mean",
        ),

        average_mae_r=(
            "mae_r",
            "mean",
        ),
    )
)


monthly["win_rate"] = (
    monthly["wins"]
    / monthly["trades"]
    * 100
)


print()
print("Performance by month:")

print(
    monthly
    .round(3)
    .to_string()
)


# ---------------------------------------------------------
# Overall MFE / MAE
# ---------------------------------------------------------

print()
print("Overall excursion statistics:")

print(
    "Average MFE:",
    f"{df['mfe_r'].mean():.3f}R"
)

print(
    "Median MFE:",
    f"{df['mfe_r'].median():.3f}R"
)

print(
    "Average MAE:",
    f"{df['mae_r'].mean():.3f}R"
)

print(
    "Median MAE:",
    f"{df['mae_r'].median():.3f}R"
)


# ---------------------------------------------------------
# Save
# ---------------------------------------------------------

df.to_csv(
    OUTPUT_FILE,
    index=False
)


print()
print(
    "Diagnostic file saved to:"
)

print(
    OUTPUT_FILE
)

print()

print(
    "ONE-YEAR DIAGNOSTIC ANALYSIS COMPLETE"
)