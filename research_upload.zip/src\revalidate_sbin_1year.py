from datetime import date

import pandas as pd


# ---------------------------------------------------------
# Files
# ---------------------------------------------------------

INPUT_FILE = (
    r"data\SBIN_5min_"
    r"2025-09-22_to_2026-09-18_clean.csv"
)

OUTPUT_FILE = (
    r"results\SBIN_5min_"
    r"2025-09-22_to_2026-09-18_quality_report.csv"
)


# ---------------------------------------------------------
# Important market dates
# ---------------------------------------------------------

CAS_EFFECTIVE_DATE = date(2026, 8, 3)

# NSE Diwali Muhurat Trading
MUHURAT_2025 = date(2025, 10, 21)


# ---------------------------------------------------------
# Load data
# ---------------------------------------------------------

df = pd.read_csv(INPUT_FILE)

df["timestamp"] = pd.to_datetime(df["timestamp"])

df["trade_date"] = df["timestamp"].dt.date


# ---------------------------------------------------------
# Validate each trading day
# ---------------------------------------------------------

quality_rows = []


for trade_date, day_df in df.groupby("trade_date"):

    # -----------------------------------------------------
    # Special case:
    # Diwali Muhurat Trading - 21 Oct 2025
    #
    # Normal market:
    # 13:45 to 14:45
    #
    # 5-minute candle timestamps:
    # 13:45 ... 14:40 = 12 candles
    # -----------------------------------------------------

    if trade_date == MUHURAT_2025:

        start_time = "13:45"
        end_time = "14:40"
        expected_count = 12
        session_type = "MUHURAT"


    # -----------------------------------------------------
    # Before Closing Auction Session regime
    # -----------------------------------------------------

    elif trade_date < CAS_EFFECTIVE_DATE:

        start_time = "09:15"
        end_time = "15:25"
        expected_count = 75
        session_type = "REGULAR"


    # -----------------------------------------------------
    # CAS regime for SBIN
    # Continuous market through 15:15
    #
    # Last 5-minute candle starts at 15:10
    # -----------------------------------------------------

    else:

        start_time = "09:15"
        end_time = "15:10"
        expected_count = 72
        session_type = "CAS"


    expected = pd.date_range(
        start=f"{trade_date} {start_time}",
        end=f"{trade_date} {end_time}",
        freq="5min",
        tz="Asia/Kolkata",
    )


    actual = pd.DatetimeIndex(
        day_df["timestamp"]
    )


    missing = expected.difference(actual)

    unexpected = actual.difference(expected)


    zero_volume_count = int(
        (day_df["volume"] == 0).sum()
    )


    duplicate_count = int(
        day_df["timestamp"]
        .duplicated()
        .sum()
    )


    actual_count = len(day_df)


    passed = (
        actual_count == expected_count
        and len(missing) == 0
        and len(unexpected) == 0
        and zero_volume_count == 0
        and duplicate_count == 0
    )


    quality_rows.append(
        {
            "trade_date": trade_date,
            "session_type": session_type,
            "expected_candles": expected_count,
            "actual_candles": actual_count,
            "missing_candles": len(missing),
            "unexpected_candles": len(unexpected),
            "zero_volume_candles": zero_volume_count,
            "duplicate_candles": duplicate_count,
            "status": (
                "PASS"
                if passed
                else "REVIEW"
            ),
            "missing_timestamps": "; ".join(
                str(x)
                for x in missing
            ),
            "unexpected_timestamps": "; ".join(
                str(x)
                for x in unexpected
            ),
        }
    )


quality_df = pd.DataFrame(
    quality_rows
)


quality_df.to_csv(
    OUTPUT_FILE,
    index=False,
)


# ---------------------------------------------------------
# Summary
# ---------------------------------------------------------

passed_days = int(
    (quality_df["status"] == "PASS").sum()
)

review_days = int(
    (quality_df["status"] == "REVIEW").sum()
)


print("=" * 65)
print("SBIN ONE-YEAR DATA REVALIDATION")
print("=" * 65)

print(
    "Trading days found:",
    len(quality_df)
)

print(
    "Days passed validation:",
    passed_days
)

print(
    "Days requiring review:",
    review_days
)

print()


muhurat_row = quality_df[
    quality_df["trade_date"]
    == MUHURAT_2025
]

print("2025 Muhurat session:")
print(
    muhurat_row[
        [
            "trade_date",
            "session_type",
            "expected_candles",
            "actual_candles",
            "status",
        ]
    ].to_string(index=False)
)


if review_days > 0:

    print()
    print("Days still requiring review:")

    print(
        quality_df[
            quality_df["status"] == "REVIEW"
        ][
            [
                "trade_date",
                "session_type",
                "expected_candles",
                "actual_candles",
                "missing_candles",
                "unexpected_candles",
                "zero_volume_candles",
            ]
        ].to_string(index=False)
    )

else:

    print()
    print(
        "ALL TRADING DAYS PASSED "
        "DATA QUALITY VALIDATION"
    )