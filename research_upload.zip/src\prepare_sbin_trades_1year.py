import math
import pandas as pd


# ---------------------------------------------------------
# Configuration
# ---------------------------------------------------------

INPUT_FILE = (
    r"results\SBIN_strategy_v1_1year_trade_candidates.csv"
)

OUTPUT_FILE = (
    r"results\SBIN_strategy_v1_1year_prepared_trades.csv"
)

INITIAL_CAPITAL = 200000.0

# Risk maximum 0.5% of ₹2 lakh
RISK_PERCENT = 0.005

# Target = 2R
TARGET_R_MULTIPLE = 2.0


# ---------------------------------------------------------
# Load candidates
# ---------------------------------------------------------

df = pd.read_csv(INPUT_FILE)

df["timestamp"] = pd.to_datetime(
    df["timestamp"]
)

df["entry_timestamp"] = pd.to_datetime(
    df["entry_timestamp"]
)

df["trade_date"] = pd.to_datetime(
    df["trade_date"]
).dt.date


df = (
    df
    .sort_values("entry_timestamp")
    .reset_index(drop=True)
)


# ---------------------------------------------------------
# Maximum ONE SBIN trade per day
#
# Keep earliest valid candidate.
# ---------------------------------------------------------

trades = (
    df
    .groupby(
        "trade_date",
        as_index=False
    )
    .first()
    .sort_values("entry_timestamp")
    .reset_index(drop=True)
)


# ---------------------------------------------------------
# ATR stop
#
# Entry - 1 x ATR
# ---------------------------------------------------------

trades["atr_stop"] = (
    trades["entry_price"]
    - trades["atr14"]
)


# ---------------------------------------------------------
# Swing stop
#
# Lowest low of previous five completed candles
# ---------------------------------------------------------

trades["swing_stop"] = (
    trades["lowest_low_prev5"]
)


# ---------------------------------------------------------
# Final stop
#
# Strategy V1:
# Lower of ATR stop or swing-low stop
# ---------------------------------------------------------

trades["stop_price"] = (
    trades[
        [
            "atr_stop",
            "swing_stop",
        ]
    ]
    .min(axis=1)
)


# ---------------------------------------------------------
# Risk per share
# ---------------------------------------------------------

trades["risk_per_share"] = (
    trades["entry_price"]
    - trades["stop_price"]
)


# ---------------------------------------------------------
# Risk budget
# ---------------------------------------------------------

risk_budget = (
    INITIAL_CAPITAL
    * RISK_PERCENT
)

trades["risk_budget"] = (
    risk_budget
)


# ---------------------------------------------------------
# Quantity based on risk
# ---------------------------------------------------------

trades["quantity_by_risk"] = (
    trades["risk_budget"]
    / trades["risk_per_share"]
).apply(math.floor)


# ---------------------------------------------------------
# Quantity based on cash
#
# No leverage in V1 backtest.
# ---------------------------------------------------------

trades["quantity_by_cash"] = (
    INITIAL_CAPITAL
    / trades["entry_price"]
).apply(math.floor)


# ---------------------------------------------------------
# Final quantity
# ---------------------------------------------------------

trades["quantity"] = (
    trades[
        [
            "quantity_by_risk",
            "quantity_by_cash",
        ]
    ]
    .min(axis=1)
)


# ---------------------------------------------------------
# Planned rupee risk
# ---------------------------------------------------------

trades["planned_risk"] = (
    trades["quantity"]
    * trades["risk_per_share"]
)


# ---------------------------------------------------------
# 2R target
# ---------------------------------------------------------

trades["target_price"] = (
    trades["entry_price"]
    + (
        TARGET_R_MULTIPLE
        * trades["risk_per_share"]
    )
)


# ---------------------------------------------------------
# Validation
# ---------------------------------------------------------

invalid = trades[
    (trades["risk_per_share"] <= 0)
    | (trades["quantity"] <= 0)
].copy()


print("=" * 72)
print(
    "SBIN STRATEGY V1 - ONE-YEAR PREPARED TRADES"
)
print("=" * 72)


print(
    "Valid candidates before one-trade/day rule:",
    len(df)
)

print(
    "Prepared trades after one-trade/day rule:",
    len(trades)
)

print(
    "Trading days with trades:",
    trades["trade_date"].nunique()
)

print(
    "Risk budget per trade: ₹",
    f"{risk_budget:,.2f}",
    sep=""
)

print(
    "Invalid trades:",
    len(invalid)
)


# ---------------------------------------------------------
# Risk statistics
# ---------------------------------------------------------

print()
print("Risk statistics:")


print(
    "Average risk/share: ₹",
    f"{trades['risk_per_share'].mean():.2f}",
    sep=""
)


print(
    "Median risk/share: ₹",
    f"{trades['risk_per_share'].median():.2f}",
    sep=""
)


print(
    "Average quantity:",
    f"{trades['quantity'].mean():.1f}"
)


print(
    "Average planned rupee risk: ₹",
    f"{trades['planned_risk'].mean():.2f}",
    sep=""
)


print(
    "Maximum planned rupee risk: ₹",
    f"{trades['planned_risk'].max():.2f}",
    sep=""
)


print(
    "Minimum planned rupee risk: ₹",
    f"{trades['planned_risk'].min():.2f}",
    sep=""
)


# ---------------------------------------------------------
# Determine how often cash constraint,
# rather than risk constraint, limited quantity
# ---------------------------------------------------------

cash_limited = (
    trades["quantity_by_cash"]
    < trades["quantity_by_risk"]
)

print()

print(
    "Trades limited by available cash:",
    int(cash_limited.sum())
)

print(
    "Trades limited by risk budget:",
    int((~cash_limited).sum())
)


# ---------------------------------------------------------
# Trades by month
# ---------------------------------------------------------

trades["month"] = (
    trades["entry_timestamp"]
    .dt.strftime("%Y-%m")
)

monthly = (
    trades
    .groupby("month")
    .size()
    .reset_index(name="trade_count")
)


print()
print("Prepared trades by month:")

print(
    monthly.to_string(
        index=False
    )
)


# ---------------------------------------------------------
# First 15 trades
# ---------------------------------------------------------

print()
print("First 15 prepared trades:")


display_columns = [
    "trade_date",
    "entry_timestamp",
    "entry_price",
    "atr14",
    "swing_stop",
    "atr_stop",
    "stop_price",
    "risk_per_share",
    "quantity",
    "planned_risk",
    "target_price",
]


print(
    trades[
        display_columns
    ]
    .head(15)
    .to_string(index=False)
)


# ---------------------------------------------------------
# Save
# ---------------------------------------------------------

save_columns = [
    "trade_date",
    "timestamp",
    "entry_timestamp",
    "entry_price",
    "atr14",
    "lowest_low_prev5",
    "atr_stop",
    "swing_stop",
    "stop_price",
    "risk_per_share",
    "risk_budget",
    "quantity_by_risk",
    "quantity_by_cash",
    "quantity",
    "planned_risk",
    "target_price",
]


trades[
    save_columns
].to_csv(
    OUTPUT_FILE,
    index=False,
)


print()
print(
    "Prepared trade file saved to:",
    OUTPUT_FILE
)

print()

print(
    "ONE-YEAR TRADE PREPARATION COMPLETE"
)