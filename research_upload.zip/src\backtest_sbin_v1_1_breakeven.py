import pandas as pd


# ---------------------------------------------------------
# Configuration
# ---------------------------------------------------------

PRICE_FILE = (
    r"data\SBIN_5min_"
    r"2025-09-22_to_2026-09-18_clean.csv"
)

TRADE_FILE = (
    r"results\SBIN_strategy_v1_1year_prepared_trades.csv"
)

OUTPUT_FILE = (
    r"results\SBIN_strategy_v1_1_breakeven_backtest.csv"
)

INITIAL_CAPITAL = 200000.0

TIME_EXIT_CANDLE = "15:10"

# ---------------------------------------------------------
# ONLY experimental change:
#
# After a COMPLETED candle has reached +0.5R,
# move stop to entry price starting from NEXT candle.
#
# This avoids pretending we know intrabar order.
# ---------------------------------------------------------

BREAKEVEN_TRIGGER_R = 0.50


# ---------------------------------------------------------
# Load price data
# ---------------------------------------------------------

prices = pd.read_csv(PRICE_FILE)

prices["timestamp"] = pd.to_datetime(
    prices["timestamp"]
)

prices = (
    prices
    .sort_values("timestamp")
    .reset_index(drop=True)
)

prices["trade_date"] = (
    prices["timestamp"].dt.date
)

prices["trade_time"] = (
    prices["timestamp"]
    .dt.strftime("%H:%M")
)


# ---------------------------------------------------------
# Load trades
# ---------------------------------------------------------

trades = pd.read_csv(TRADE_FILE)

trades["timestamp"] = pd.to_datetime(
    trades["timestamp"]
)

trades["entry_timestamp"] = pd.to_datetime(
    trades["entry_timestamp"]
)

trades["trade_date"] = pd.to_datetime(
    trades["trade_date"]
).dt.date

trades = (
    trades
    .sort_values("entry_timestamp")
    .reset_index(drop=True)
)


# ---------------------------------------------------------
# Backtest
# ---------------------------------------------------------

results = []


for _, trade in trades.iterrows():

    trade_date = trade["trade_date"]

    entry_timestamp = (
        trade["entry_timestamp"]
    )

    entry_price = float(
        trade["entry_price"]
    )

    original_stop = float(
        trade["stop_price"]
    )

    target_price = float(
        trade["target_price"]
    )

    quantity = int(
        trade["quantity"]
    )

    planned_risk = float(
        trade["planned_risk"]
    )

    risk_per_share = (
        entry_price
        - original_stop
    )

    breakeven_trigger_price = (
        entry_price
        + BREAKEVEN_TRIGGER_R
        * risk_per_share
    )


    # -----------------------------------------------------
    # Candles from entry through 15:10
    # -----------------------------------------------------

    day_prices = prices[
        (prices["trade_date"] == trade_date)
        & (
            prices["timestamp"]
            >= entry_timestamp
        )
        & (
            prices["trade_time"]
            <= TIME_EXIT_CANDLE
        )
    ].copy()


    if day_prices.empty:

        raise RuntimeError(
            f"No candles found for {trade_date}"
        )


    time_exit_rows = day_prices[
        day_prices["trade_time"]
        == TIME_EXIT_CANDLE
    ]


    if time_exit_rows.empty:

        raise RuntimeError(
            f"15:10 candle missing for "
            f"{trade_date}"
        )


    # -----------------------------------------------------
    # Trade state
    # -----------------------------------------------------

    current_stop = (
        original_stop
    )

    breakeven_armed = False

    breakeven_activated = False

    exit_timestamp = None
    exit_price = None
    exit_reason = None

    both_hit_same_candle = False


    # -----------------------------------------------------
    # Walk forward candle-by-candle
    # -----------------------------------------------------

    for _, candle in day_prices.iterrows():

        candle_timestamp = (
            candle["timestamp"]
        )

        candle_high = float(
            candle["high"]
        )

        candle_low = float(
            candle["low"]
        )


        # -------------------------------------------------
        # If breakeven was armed by the PREVIOUS
        # completed candle, activate it now.
        # -------------------------------------------------

        if breakeven_armed:

            current_stop = (
                entry_price
            )

            breakeven_activated = True

            breakeven_armed = False


        stop_hit = (
            candle_low
            <= current_stop
        )

        target_hit = (
            candle_high
            >= target_price
        )


        # -------------------------------------------------
        # Conservative same-candle handling
        # -------------------------------------------------

        if stop_hit and target_hit:

            exit_timestamp = (
                candle_timestamp
            )

            exit_price = (
                current_stop
            )

            if (
                breakeven_activated
                and current_stop
                == entry_price
            ):

                exit_reason = (
                    "BREAKEVEN"
                )

            else:

                exit_reason = (
                    "STOP"
                )

            both_hit_same_candle = True

            break


        # -------------------------------------------------
        # Stop / breakeven hit
        # -------------------------------------------------

        if stop_hit:

            exit_timestamp = (
                candle_timestamp
            )

            exit_price = (
                current_stop
            )

            if (
                breakeven_activated
                and current_stop
                == entry_price
            ):

                exit_reason = (
                    "BREAKEVEN"
                )

            else:

                exit_reason = (
                    "STOP"
                )

            break


        # -------------------------------------------------
        # Target hit
        # -------------------------------------------------

        if target_hit:

            exit_timestamp = (
                candle_timestamp
            )

            exit_price = (
                target_price
            )

            exit_reason = (
                "TARGET"
            )

            break


        # -------------------------------------------------
        # Arm breakeven ONLY AFTER this candle closes.
        #
        # It becomes active from the NEXT candle.
        # -------------------------------------------------

        if (
            not breakeven_activated
            and not breakeven_armed
            and candle_high
            >= breakeven_trigger_price
        ):

            breakeven_armed = True


    # -----------------------------------------------------
    # Time exit
    # -----------------------------------------------------

    if exit_reason is None:

        last_candle = (
            time_exit_rows.iloc[-1]
        )

        exit_timestamp = (
            last_candle["timestamp"]
        )

        exit_price = float(
            last_candle["close"]
        )

        exit_reason = (
            "TIME_EXIT"
        )


    # -----------------------------------------------------
    # P&L
    # -----------------------------------------------------

    gross_pnl_per_share = (
        exit_price
        - entry_price
    )

    gross_pnl = (
        gross_pnl_per_share
        * quantity
    )


    if planned_risk > 0:

        r_multiple = (
            gross_pnl
            / planned_risk
        )

    else:

        r_multiple = 0.0


    holding_minutes = (
        (
            exit_timestamp
            - entry_timestamp
        ).total_seconds()
        / 60
    )


    results.append(
        {
            "trade_date":
                trade_date,

            "entry_timestamp":
                entry_timestamp,

            "entry_price":
                entry_price,

            "original_stop":
                original_stop,

            "target_price":
                target_price,

            "breakeven_trigger_price":
                breakeven_trigger_price,

            "breakeven_activated":
                breakeven_activated,

            "quantity":
                quantity,

            "planned_risk":
                planned_risk,

            "exit_timestamp":
                exit_timestamp,

            "exit_price":
                exit_price,

            "exit_reason":
                exit_reason,

            "holding_minutes":
                holding_minutes,

            "gross_pnl":
                gross_pnl,

            "r_multiple":
                r_multiple,

            "both_hit_same_candle":
                both_hit_same_candle,
        }
    )


# ---------------------------------------------------------
# Results
# ---------------------------------------------------------

df = pd.DataFrame(results)


# ---------------------------------------------------------
# Statistics
# ---------------------------------------------------------

total_trades = len(df)

wins = int(
    (df["gross_pnl"] > 0).sum()
)

losses = int(
    (df["gross_pnl"] < 0).sum()
)

breakeven_trades = int(
    (df["gross_pnl"] == 0).sum()
)


win_rate = (
    wins
    / total_trades
    * 100
)


gross_profit = (
    df.loc[
        df["gross_pnl"] > 0,
        "gross_pnl",
    ].sum()
)

gross_loss = (
    -df.loc[
        df["gross_pnl"] < 0,
        "gross_pnl",
    ].sum()
)


profit_factor = (
    gross_profit / gross_loss
    if gross_loss > 0
    else float("inf")
)


total_pnl = (
    df["gross_pnl"].sum()
)

average_trade = (
    df["gross_pnl"].mean()
)

average_r = (
    df["r_multiple"].mean()
)


# ---------------------------------------------------------
# Equity / drawdown
# ---------------------------------------------------------

df["equity"] = (
    INITIAL_CAPITAL
    + df["gross_pnl"].cumsum()
)

df["equity_peak"] = (
    df["equity"].cummax()
)

df["drawdown"] = (
    df["equity"]
    - df["equity_peak"]
)

df["drawdown_percent"] = (
    df["drawdown"]
    / df["equity_peak"]
    * 100
)


max_drawdown = (
    df["drawdown"].min()
)

max_drawdown_percent = (
    df["drawdown_percent"].min()
)


# ---------------------------------------------------------
# Consecutive losses
# ---------------------------------------------------------

max_consecutive_losses = 0
current_losses = 0


for pnl in df["gross_pnl"]:

    if pnl < 0:

        current_losses += 1

        max_consecutive_losses = max(
            max_consecutive_losses,
            current_losses,
        )

    else:

        current_losses = 0


# ---------------------------------------------------------
# Print summary
# ---------------------------------------------------------

print("=" * 72)
print(
    "SBIN STRATEGY V1.1 - 0.5R BREAKEVEN TEST"
)
print("=" * 72)

print(
    "Total trades:",
    total_trades
)

print(
    "Winning trades:",
    wins
)

print(
    "Losing trades:",
    losses
)

print(
    "Breakeven trades:",
    breakeven_trades
)

print(
    "Win rate:",
    f"{win_rate:.2f}%"
)


print()
print("Exit reasons:")

print(
    df["exit_reason"]
    .value_counts()
    .to_string()
)


print()

print(
    "Breakeven stop activated:",
    int(
        df[
            "breakeven_activated"
        ].sum()
    )
)

print(
    "Trades exited at breakeven:",
    int(
        (
            df["exit_reason"]
            == "BREAKEVEN"
        ).sum()
    )
)


print()

print(
    "Gross profit: ₹",
    f"{gross_profit:,.2f}",
    sep=""
)

print(
    "Gross loss: ₹",
    f"{gross_loss:,.2f}",
    sep=""
)

print(
    "Total gross P&L: ₹",
    f"{total_pnl:,.2f}",
    sep=""
)

print(
    "Average P&L / trade: ₹",
    f"{average_trade:,.2f}",
    sep=""
)

print(
    "Profit factor:",
    f"{profit_factor:.3f}"
)

print(
    "Average R / trade:",
    f"{average_r:.3f}R"
)


print()

print(
    "Maximum drawdown: ₹",
    f"{max_drawdown:,.2f}",
    sep=""
)

print(
    "Maximum drawdown:",
    f"{max_drawdown_percent:.2f}%"
)

print(
    "Maximum consecutive losses:",
    max_consecutive_losses
)

print(
    "Same-candle Stop + Target cases:",
    int(
        df[
            "both_hit_same_candle"
        ].sum()
    )
)


# ---------------------------------------------------------
# Save
# ---------------------------------------------------------

df.to_csv(
    OUTPUT_FILE,
    index=False
)


print()

print(
    "Results saved to:"
)

print(
    OUTPUT_FILE
)

print()

print(
    "V1.1 BREAKEVEN TEST COMPLETE"
)