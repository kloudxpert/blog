from datetime import date

import pandas as pd


# ---------------------------------------------------------
# Configuration
# ---------------------------------------------------------

PRICE_FILE = (
    r"data\SBIN_5min_"
    r"2026-06-22_to_2026-09-18_clean.csv"
)

TRADE_FILE = (
    r"results\SBIN_strategy_v1_prepared_trades.csv"
)

OUTPUT_FILE = (
    r"results\SBIN_strategy_v1_backtest_gross.csv"
)

CAS_EFFECTIVE_DATE = date(2026, 8, 3)


# ---------------------------------------------------------
# Load price data
# ---------------------------------------------------------

prices = pd.read_csv(PRICE_FILE)

prices["timestamp"] = pd.to_datetime(
    prices["timestamp"]
)

prices = (
    prices
    .sort_values("timestamp")
    .reset_index(drop=True)
)

prices["trade_date"] = (
    prices["timestamp"].dt.date
)


# ---------------------------------------------------------
# Load prepared trades
# ---------------------------------------------------------

trades = pd.read_csv(TRADE_FILE)

trades["entry_timestamp"] = pd.to_datetime(
    trades["entry_timestamp"]
)

trades["timestamp"] = pd.to_datetime(
    trades["timestamp"]
)

trades["trade_date"] = pd.to_datetime(
    trades["trade_date"]
).dt.date

trades = (
    trades
    .sort_values("entry_timestamp")
    .reset_index(drop=True)
)


# ---------------------------------------------------------
# Backtest each trade
# ---------------------------------------------------------

results = []


for _, trade in trades.iterrows():

    trade_date = trade["trade_date"]

    entry_timestamp = trade["entry_timestamp"]

    entry_price = float(
        trade["entry_price"]
    )

    stop_price = float(
        trade["stop_price"]
    )

    target_price = float(
        trade["target_price"]
    )

    quantity = int(
        trade["quantity"]
    )

    planned_risk = float(
        trade["planned_risk"]
    )


    # -----------------------------------------------------
    # Get candles for this trading day
    # starting from the actual entry candle
    # -----------------------------------------------------

    day_prices = prices[
        (prices["trade_date"] == trade_date)
        & (
            prices["timestamp"]
            >= entry_timestamp
        )
    ].copy()

    if day_prices.empty:

        print(
            f"WARNING: No price data for "
            f"{trade_date}"
        )

        continue


    # -----------------------------------------------------
    # Exit variables
    # -----------------------------------------------------

    exit_timestamp = None
    exit_price = None
    exit_reason = None

    both_hit_same_candle = False


    # -----------------------------------------------------
    # Process candles sequentially
    # -----------------------------------------------------

    for _, candle in day_prices.iterrows():

        candle_time = candle["timestamp"]

        candle_high = float(
            candle["high"]
        )

        candle_low = float(
            candle["low"]
        )


        stop_hit = (
            candle_low <= stop_price
        )

        target_hit = (
            candle_high >= target_price
        )


        # -------------------------------------------------
        # Conservative same-candle rule
        #
        # If both stop and target are touched and
        # 5-minute OHLC cannot tell us which came first,
        # assume STOP was hit first.
        # -------------------------------------------------

        if stop_hit and target_hit:

            exit_timestamp = candle_time
            exit_price = stop_price
            exit_reason = "STOP"

            both_hit_same_candle = True

            break


        # -------------------------------------------------
        # Stop hit
        # -------------------------------------------------

        if stop_hit:

            exit_timestamp = candle_time
            exit_price = stop_price
            exit_reason = "STOP"

            break


        # -------------------------------------------------
        # Target hit
        # -------------------------------------------------

        if target_hit:

            exit_timestamp = candle_time
            exit_price = target_price
            exit_reason = "TARGET"

            break


    # -----------------------------------------------------
    # Time exit if neither stop nor target was reached
    #
    # Before CAS:
    # last continuous candle starts 15:25
    #
    # From 03-Aug-2026:
    # last continuous candle starts 15:10
    # -----------------------------------------------------

    if exit_reason is None:

        if trade_date < CAS_EFFECTIVE_DATE:

            expected_last_time = "15:25"

        else:

            expected_last_time = "15:10"


        expected_last_time = pd.Timestamp(
            expected_last_time
        ).time()


        eod_candles = day_prices[
            day_prices[
                "timestamp"
            ].dt.time
            <= expected_last_time
        ]


        if eod_candles.empty:

            raise RuntimeError(
                f"No end-of-day candle "
                f"available for {trade_date}"
            )


        last_candle = (
            eod_candles.iloc[-1]
        )

        exit_timestamp = (
            last_candle["timestamp"]
        )

        exit_price = float(
            last_candle["close"]
        )

        exit_reason = "TIME_EXIT"


    # -----------------------------------------------------
    # Gross P&L
    # -----------------------------------------------------

    gross_pnl_per_share = (
        exit_price
        - entry_price
    )

    gross_pnl = (
        gross_pnl_per_share
        * quantity
    )


    # -----------------------------------------------------
    # R multiple
    #
    # P&L divided by planned rupee risk
    # -----------------------------------------------------

    if planned_risk > 0:

        r_multiple = (
            gross_pnl
            / planned_risk
        )

    else:

        r_multiple = 0.0


    # -----------------------------------------------------
    # Holding time
    #
    # Candle timestamp marks beginning
    # of each 5-minute bar.
    # -----------------------------------------------------

    holding_minutes = (
        (
            exit_timestamp
            - entry_timestamp
        ).total_seconds()
        / 60
    )


    # -----------------------------------------------------
    # Save result
    # -----------------------------------------------------

    results.append(
        {
            "trade_date": trade_date,
            "signal_timestamp":
                trade["timestamp"],
            "entry_timestamp":
                entry_timestamp,
            "entry_price":
                entry_price,
            "stop_price":
                stop_price,
            "target_price":
                target_price,
            "quantity":
                quantity,
            "planned_risk":
                planned_risk,
            "exit_timestamp":
                exit_timestamp,
            "exit_price":
                exit_price,
            "exit_reason":
                exit_reason,
            "both_hit_same_candle":
                both_hit_same_candle,
            "holding_minutes":
                holding_minutes,
            "gross_pnl_per_share":
                gross_pnl_per_share,
            "gross_pnl":
                gross_pnl,
            "r_multiple":
                r_multiple,
        }
    )


# ---------------------------------------------------------
# Results dataframe
# ---------------------------------------------------------

results_df = pd.DataFrame(
    results
)


if results_df.empty:

    raise RuntimeError(
        "No backtest results generated."
    )


# ---------------------------------------------------------
# Summary calculations
# ---------------------------------------------------------

total_trades = len(
    results_df
)

winning_trades = int(
    (
        results_df["gross_pnl"] > 0
    ).sum()
)

losing_trades = int(
    (
        results_df["gross_pnl"] < 0
    ).sum()
)

breakeven_trades = int(
    (
        results_df["gross_pnl"] == 0
    ).sum()
)


win_rate = (
    winning_trades
    / total_trades
    * 100
)


gross_profit = (
    results_df.loc[
        results_df["gross_pnl"] > 0,
        "gross_pnl",
    ].sum()
)

gross_loss = (
    -results_df.loc[
        results_df["gross_pnl"] < 0,
        "gross_pnl",
    ].sum()
)


if gross_loss > 0:

    profit_factor = (
        gross_profit
        / gross_loss
    )

else:

    profit_factor = float("inf")


average_win = (
    results_df.loc[
        results_df["gross_pnl"] > 0,
        "gross_pnl",
    ].mean()
)

average_loss = (
    results_df.loc[
        results_df["gross_pnl"] < 0,
        "gross_pnl",
    ].mean()
)


average_trade = (
    results_df[
        "gross_pnl"
    ].mean()
)


total_gross_pnl = (
    results_df[
        "gross_pnl"
    ].sum()
)


average_r = (
    results_df[
        "r_multiple"
    ].mean()
)


# ---------------------------------------------------------
# Exit reason counts
# ---------------------------------------------------------

exit_counts = (
    results_df[
        "exit_reason"
    ]
    .value_counts()
)


# ---------------------------------------------------------
# Equity curve + drawdown
# ---------------------------------------------------------

INITIAL_CAPITAL = 200000.0

results_df["equity"] = (
    INITIAL_CAPITAL
    + results_df[
        "gross_pnl"
    ].cumsum()
)

results_df["equity_peak"] = (
    results_df[
        "equity"
    ].cummax()
)

results_df["drawdown"] = (
    results_df[
        "equity"
    ]
    - results_df[
        "equity_peak"
    ]
)

results_df[
    "drawdown_percent"
] = (

    results_df[
        "drawdown"
    ]

    / results_df[
        "equity_peak"
    ]

    * 100
)


max_drawdown = (
    results_df[
        "drawdown"
    ].min()
)

max_drawdown_percent = (
    results_df[
        "drawdown_percent"
    ].min()
)


# ---------------------------------------------------------
# Consecutive losing trades
# ---------------------------------------------------------

max_consecutive_losses = 0
current_losses = 0


for pnl in results_df["gross_pnl"]:

    if pnl < 0:

        current_losses += 1

        max_consecutive_losses = max(
            max_consecutive_losses,
            current_losses,
        )

    else:

        current_losses = 0


# ---------------------------------------------------------
# Print summary
# ---------------------------------------------------------

print("=" * 70)
print("SBIN STRATEGY V1 - FIRST GROSS BACKTEST")
print("=" * 70)

print(
    "Total trades:",
    total_trades
)

print(
    "Winning trades:",
    winning_trades
)

print(
    "Losing trades:",
    losing_trades
)

print(
    "Breakeven trades:",
    breakeven_trades
)

print(
    "Win rate:",
    f"{win_rate:.2f}%"
)

print()

print("Exit reasons:")

for reason, count in exit_counts.items():

    print(
        f"  {reason}: {count}"
    )


print()

print(
    "Gross profit: ₹",
    f"{gross_profit:,.2f}",
    sep=""
)

print(
    "Gross loss: ₹",
    f"{gross_loss:,.2f}",
    sep=""
)

print(
    "Total gross P&L: ₹",
    f"{total_gross_pnl:,.2f}",
    sep=""
)

print(
    "Average P&L / trade: ₹",
    f"{average_trade:,.2f}",
    sep=""
)

print(
    "Average winner: ₹",
    f"{average_win:,.2f}",
    sep=""
)

print(
    "Average loser: ₹",
    f"{average_loss:,.2f}",
    sep=""
)

print(
    "Profit factor:",
    f"{profit_factor:.3f}"
)

print(
    "Average R / trade:",
    f"{average_r:.3f}R"
)

print()

print(
    "Maximum drawdown: ₹",
    f"{max_drawdown:,.2f}",
    sep=""
)

print(
    "Maximum drawdown:",
    f"{max_drawdown_percent:.2f}%"
)

print(
    "Maximum consecutive losses:",
    max_consecutive_losses
)

print()

print(
    "Same-candle Stop + Target cases:",
    int(
        results_df[
            "both_hit_same_candle"
        ].sum()
    )
)


# ---------------------------------------------------------
# Show individual trades
# ---------------------------------------------------------

print()
print("Individual trade results:")

display_columns = [
    "trade_date",
    "entry_timestamp",
    "entry_price",
    "stop_price",
    "target_price",
    "exit_timestamp",
    "exit_price",
    "exit_reason",
    "quantity",
    "gross_pnl",
    "r_multiple",
]

print(
    results_df[
        display_columns
    ].to_string(
        index=False
    )
)


# ---------------------------------------------------------
# Save
# ---------------------------------------------------------

results_df.to_csv(
    OUTPUT_FILE,
    index=False,
)

print()
print(
    "Backtest results saved to:",
    OUTPUT_FILE
)

print()

print(
    "FIRST GROSS BACKTEST COMPLETE"
)