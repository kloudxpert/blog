import os
import time
from datetime import date, datetime, timedelta

import pandas as pd
import pyotp

from dotenv import load_dotenv
from SmartApi import SmartConnect


# =========================================================
# CONFIGURATION
# =========================================================

SYMBOLS = [
    "SBIN",
    "RELIANCE",
    "HDFCBANK",
    "ICICIBANK",
    "INFY",
    "TCS",
    "LT",
    "AXISBANK",
    "BHARTIARTL",
    "ITC",
]

EXCHANGE = "NSE"
INTERVAL = "FIVE_MINUTE"

START_DATE = date(2025, 9, 22)
END_DATE = date(2026, 9, 18)

# Closing Auction Session effective date
CAS_EFFECTIVE_DATE = date(2026, 8, 3)

# 2025 Diwali Muhurat session
MUHURAT_DATE = date(2025, 10, 21)

# Historical data batch size
CHUNK_DAYS = 30

# Number of attempts for failed API calls
MAX_RETRIES = 5

# Historical candle requests:
# deliberately conservative pacing
REQUEST_DELAY_SECONDS = 1.5

# searchScrip is more restrictive.
# Use 2 seconds between symbol searches.
SYMBOL_SEARCH_DELAY_SECONDS = 2.0


# =========================================================
# OUTPUT DIRECTORIES
# =========================================================

DATA_DIR = r"data\multistock"
RESULTS_DIR = r"results\multistock"

os.makedirs(
    DATA_DIR,
    exist_ok=True,
)

os.makedirs(
    RESULTS_DIR,
    exist_ok=True,
)


SYMBOL_MASTER_FILE = (
    r"results\multistock\symbol_master.csv"
)

QUALITY_FILE = (
    r"results\multistock\quality_report.csv"
)

SUMMARY_FILE = (
    r"results\multistock\download_summary.csv"
)


# =========================================================
# LOAD CREDENTIALS
# =========================================================

load_dotenv()

api_key = os.getenv(
    "ANGEL_API_KEY"
)

client_code = os.getenv(
    "ANGEL_CLIENT_CODE"
)

mpin = os.getenv(
    "ANGEL_MPIN"
)

totp_secret = os.getenv(
    "ANGEL_TOTP_SECRET"
)


required = {
    "ANGEL_API_KEY": api_key,
    "ANGEL_CLIENT_CODE": client_code,
    "ANGEL_MPIN": mpin,
    "ANGEL_TOTP_SECRET": totp_secret,
}


missing = [
    name
    for name, value in required.items()
    if not value
]


if missing:

    raise RuntimeError(
        "Missing environment variables: "
        + ", ".join(missing)
    )


# =========================================================
# LOGIN
# =========================================================

print(
    "Logging in to Angel One SmartAPI..."
)


smart_api = SmartConnect(
    api_key=api_key
)


session = smart_api.generateSession(
    client_code,
    mpin,
    pyotp.TOTP(
        totp_secret
    ).now(),
)


if not session.get("status"):

    raise RuntimeError(
        "SmartAPI login failed: "
        + str(
            session.get("message")
        )
    )


print("Login successful")


# =========================================================
# SYMBOL TOKEN RESOLUTION
# =========================================================

def resolve_symbol_token(symbol):

    expected_trading_symbol = (
        f"{symbol}-EQ"
    )

    print(
        f"Resolving token for {symbol}..."
    )

    last_exception = None


    for attempt in range(
        1,
        MAX_RETRIES + 1,
    ):

        try:

            response = (
                smart_api.searchScrip(
                    EXCHANGE,
                    symbol,
                )
            )


            if not response.get("status"):

                print(
                    f"{symbol}: search attempt "
                    f"{attempt} failed. "
                    f"Message: "
                    f"{response.get('message')}"
                )

            else:

                records = (
                    response.get("data")
                    or []
                )


                exact_matches = [
                    item
                    for item in records
                    if (
                        item.get("exchange")
                        == EXCHANGE
                        and item.get(
                            "tradingsymbol"
                        )
                        == expected_trading_symbol
                    )
                ]


                if len(exact_matches) == 1:

                    item = (
                        exact_matches[0]
                    )


                    return {
                        "symbol":
                            symbol,

                        "tradingsymbol":
                            item[
                                "tradingsymbol"
                            ],

                        "symboltoken":
                            str(
                                item[
                                    "symboltoken"
                                ]
                            ),
                    }


                raise RuntimeError(
                    f"Could not uniquely resolve "
                    f"{expected_trading_symbol}. "
                    f"Exact matches found: "
                    f"{len(exact_matches)}"
                )


        except Exception as exc:

            last_exception = exc

            print(
                f"{symbol}: symbol search "
                f"attempt {attempt} failed:"
            )

            print(
                f"  {type(exc).__name__}: "
                f"{exc}"
            )


        # -------------------------------------------------
        # Retry cooldown
        #
        # This is especially important when Angel One
        # returns an API-rate-limit response.
        # -------------------------------------------------

        if attempt < MAX_RETRIES:

            wait_seconds = (
                3 * attempt
            )

            print(
                f"{symbol}: waiting "
                f"{wait_seconds} seconds "
                f"before retry..."
            )

            time.sleep(
                wait_seconds
            )


    raise RuntimeError(
        f"Unable to resolve "
        f"{expected_trading_symbol} "
        f"after {MAX_RETRIES} attempts. "
        f"Last error: {last_exception}"
    )


# =========================================================
# RESOLVE ALL TOKENS
# =========================================================

symbol_records = []


print()
print("=" * 72)
print("RESOLVING SYMBOL TOKENS")
print("=" * 72)


for symbol in SYMBOLS:

    resolved = (
        resolve_symbol_token(
            symbol
        )
    )

    symbol_records.append(
        resolved
    )


    print(
        f"  {resolved['symbol']} -> "
        f"{resolved['tradingsymbol']} "
        f"(token "
        f"{resolved['symboltoken']})"
    )


    # IMPORTANT:
    # Prevent searchScrip rate-limit errors.
    time.sleep(
        SYMBOL_SEARCH_DELAY_SECONDS
    )


symbol_master = pd.DataFrame(
    symbol_records
)


symbol_master.to_csv(
    SYMBOL_MASTER_FILE,
    index=False,
)


print()
print(
    "All symbol tokens resolved successfully."
)


# =========================================================
# HISTORICAL DOWNLOAD HELPER
# =========================================================

def fetch_chunk(
    symbol,
    symbol_token,
    chunk_start,
    chunk_end,
):

    params = {
        "exchange":
            EXCHANGE,

        "symboltoken":
            symbol_token,

        "interval":
            INTERVAL,

        "fromdate":
            f"{chunk_start} 09:15",

        "todate":
            f"{chunk_end} 15:30",
    }


    last_exception = None


    for attempt in range(
        1,
        MAX_RETRIES + 1,
    ):

        try:

            print(
                f"{symbol}: "
                f"{chunk_start} -> "
                f"{chunk_end} "
                f"(attempt {attempt})"
            )


            response = (
                smart_api.getCandleData(
                    params
                )
            )


            if (
                response.get("status")
                and response.get("data")
            ):

                return (
                    response["data"]
                )


            print(
                f"{symbol}: candle request "
                f"failed. Message: "
                f"{response.get('message')}"
            )


        except Exception as exc:

            last_exception = exc

            print(
                f"{symbol}: candle API "
                f"attempt {attempt} failed:"
            )

            print(
                f"  {type(exc).__name__}: "
                f"{exc}"
            )


        if attempt < MAX_RETRIES:

            wait_seconds = (
                3 * attempt
            )

            print(
                f"{symbol}: waiting "
                f"{wait_seconds} seconds "
                f"before retry..."
            )

            time.sleep(
                wait_seconds
            )


    raise RuntimeError(
        f"Failed to download "
        f"{symbol}: "
        f"{chunk_start} to "
        f"{chunk_end}. "
        f"Last error: "
        f"{last_exception}"
    )


# =========================================================
# DOWNLOAD ONE SYMBOL
# =========================================================

def download_symbol(
    symbol,
    symbol_token,
):

    print()
    print("=" * 72)
    print(
        f"DOWNLOADING {symbol}"
    )
    print("=" * 72)


    all_rows = []

    current_date = (
        START_DATE
    )


    while (
        current_date
        <= END_DATE
    ):

        chunk_end = min(
            current_date
            + timedelta(
                days=CHUNK_DAYS - 1
            ),
            END_DATE,
        )


        rows = fetch_chunk(
            symbol,
            symbol_token,
            current_date,
            chunk_end,
        )


        all_rows.extend(
            rows
        )


        current_date = (
            chunk_end
            + timedelta(days=1)
        )


        # Prevent historical API throttling.
        time.sleep(
            REQUEST_DELAY_SECONDS
        )


    if not all_rows:

        raise RuntimeError(
            f"No historical data "
            f"downloaded for {symbol}"
        )


    # -----------------------------------------------------
    # Create DataFrame
    # -----------------------------------------------------

    df = pd.DataFrame(
        all_rows,
        columns=[
            "timestamp",
            "open",
            "high",
            "low",
            "close",
            "volume",
        ],
    )


    df["timestamp"] = (
        pd.to_datetime(
            df["timestamp"]
        )
    )


    numeric_columns = [
        "open",
        "high",
        "low",
        "close",
        "volume",
    ]


    for column in numeric_columns:

        df[column] = (
            pd.to_numeric(
                df[column],
                errors="coerce",
            )
        )


    if (
        df[numeric_columns]
        .isna()
        .any()
        .any()
    ):

        raise RuntimeError(
            f"{symbol}: "
            f"non-numeric OHLCV "
            f"values detected."
        )


    # -----------------------------------------------------
    # Remove duplicated timestamps
    # -----------------------------------------------------

    df = (
        df
        .drop_duplicates(
            subset=["timestamp"]
        )
        .sort_values(
            "timestamp"
        )
        .reset_index(drop=True)
    )


    df["trade_date"] = (
        df["timestamp"]
        .dt.date
    )


    df["trade_time"] = (
        df["timestamp"]
        .dt.time
    )


    # -----------------------------------------------------
    # Save raw data
    # -----------------------------------------------------

    raw_file = (
        rf"{DATA_DIR}\{symbol}_5min_"
        rf"2025-09-22_to_2026-09-18_raw.csv"
    )


    df[
        [
            "timestamp",
            "open",
            "high",
            "low",
            "close",
            "volume",
        ]
    ].to_csv(
        raw_file,
        index=False,
    )


    # -----------------------------------------------------
    # Session times
    # -----------------------------------------------------

    regular_open = (
        datetime.strptime(
            "09:15",
            "%H:%M",
        ).time()
    )


    pre_cas_last_candle = (
        datetime.strptime(
            "15:25",
            "%H:%M",
        ).time()
    )


    cas_last_candle = (
        datetime.strptime(
            "15:10",
            "%H:%M",
        ).time()
    )


    # -----------------------------------------------------
    # Pre-CAS rows
    # -----------------------------------------------------

    before_cas = (
        df["trade_date"]
        < CAS_EFFECTIVE_DATE
    )


    keep_pre_cas = (
        before_cas
        & (
            df["trade_time"]
            >= regular_open
        )
        & (
            df["trade_time"]
            <= pre_cas_last_candle
        )
    )


    # -----------------------------------------------------
    # CAS rows
    # -----------------------------------------------------

    from_cas = (
        df["trade_date"]
        >= CAS_EFFECTIVE_DATE
    )


    keep_cas = (
        from_cas
        & (
            df["trade_time"]
            >= regular_open
        )
        & (
            df["trade_time"]
            <= cas_last_candle
        )
    )


    # -----------------------------------------------------
    # Clean continuous-session data
    # -----------------------------------------------------

    clean_df = df[
        keep_pre_cas
        | keep_cas
    ].copy()


    clean_df = (
        clean_df[
            [
                "timestamp",
                "open",
                "high",
                "low",
                "close",
                "volume",
            ]
        ]
        .sort_values(
            "timestamp"
        )
        .reset_index(drop=True)
    )


    # -----------------------------------------------------
    # Save clean data
    # -----------------------------------------------------

    clean_file = (
        rf"{DATA_DIR}\{symbol}_5min_"
        rf"2025-09-22_to_2026-09-18_clean.csv"
    )


    clean_df.to_csv(
        clean_file,
        index=False,
    )


    return (
        df,
        clean_df,
        raw_file,
        clean_file,
    )


# =========================================================
# VALIDATE ONE SYMBOL
# =========================================================

def validate_symbol(
    symbol,
    clean_df,
):

    validation_df = (
        clean_df.copy()
    )


    validation_df[
        "trade_date"
    ] = (
        validation_df[
            "timestamp"
        ].dt.date
    )


    quality_rows = []


    for (
        trade_date,
        day_df
    ) in validation_df.groupby(
        "trade_date"
    ):


        # -------------------------------------------------
        # Special Muhurat Trading session
        # -------------------------------------------------

        if (
            trade_date
            == MUHURAT_DATE
        ):

            start_time = (
                "13:45"
            )

            end_time = (
                "14:40"
            )

            expected_count = (
                12
            )

            session_type = (
                "MUHURAT"
            )


        # -------------------------------------------------
        # Normal session before CAS
        # -------------------------------------------------

        elif (
            trade_date
            < CAS_EFFECTIVE_DATE
        ):

            start_time = (
                "09:15"
            )

            end_time = (
                "15:25"
            )

            expected_count = (
                75
            )

            session_type = (
                "REGULAR"
            )


        # -------------------------------------------------
        # CAS continuous session
        # -------------------------------------------------

        else:

            start_time = (
                "09:15"
            )

            end_time = (
                "15:10"
            )

            expected_count = (
                72
            )

            session_type = (
                "CAS"
            )


        expected = (
            pd.date_range(
                start=(
                    f"{trade_date} "
                    f"{start_time}"
                ),
                end=(
                    f"{trade_date} "
                    f"{end_time}"
                ),
                freq="5min",
                tz="Asia/Kolkata",
            )
        )


        actual = (
            pd.DatetimeIndex(
                day_df[
                    "timestamp"
                ]
            )
        )


        missing = (
            expected.difference(
                actual
            )
        )


        unexpected = (
            actual.difference(
                expected
            )
        )


        zero_volume = int(
            (
                day_df["volume"]
                == 0
            ).sum()
        )


        duplicates = int(
            day_df[
                "timestamp"
            ]
            .duplicated()
            .sum()
        )


        actual_count = (
            len(day_df)
        )


        passed = (
            actual_count
            == expected_count
            and len(missing)
            == 0
            and len(unexpected)
            == 0
            and zero_volume
            == 0
            and duplicates
            == 0
        )


        quality_rows.append(
            {
                "symbol":
                    symbol,

                "trade_date":
                    trade_date,

                "session_type":
                    session_type,

                "expected_candles":
                    expected_count,

                "actual_candles":
                    actual_count,

                "missing_candles":
                    len(missing),

                "unexpected_candles":
                    len(unexpected),

                "zero_volume_candles":
                    zero_volume,

                "duplicate_candles":
                    duplicates,

                "status":
                    (
                        "PASS"
                        if passed
                        else "REVIEW"
                    ),

                "missing_timestamps":
                    "; ".join(
                        str(x)
                        for x in missing
                    ),

                "unexpected_timestamps":
                    "; ".join(
                        str(x)
                        for x in unexpected
                    ),
            }
        )


    return pd.DataFrame(
        quality_rows
    )


# =========================================================
# DOWNLOAD + VALIDATE ALL SYMBOLS
# =========================================================

all_quality = []

summary_rows = []


for record in symbol_records:

    symbol = (
        record["symbol"]
    )

    token = (
        record["symboltoken"]
    )


    (
        raw_df,
        clean_df,
        raw_file,
        clean_file,
    ) = download_symbol(
        symbol,
        token,
    )


    quality_df = (
        validate_symbol(
            symbol,
            clean_df,
        )
    )


    all_quality.append(
        quality_df
    )


    passed_days = int(
        (
            quality_df[
                "status"
            ]
            == "PASS"
        ).sum()
    )


    review_days = int(
        (
            quality_df[
                "status"
            ]
            == "REVIEW"
        ).sum()
    )


    summary_rows.append(
        {
            "symbol":
                symbol,

            "token":
                token,

            "raw_candles":
                len(raw_df),

            "clean_candles":
                len(clean_df),

            "trading_days":
                len(quality_df),

            "passed_days":
                passed_days,

            "review_days":
                review_days,

            "raw_file":
                raw_file,

            "clean_file":
                clean_file,
        }
    )


    print()
    print(
        f"{symbol} COMPLETE"
    )

    print(
        "Raw candles:",
        len(raw_df)
    )

    print(
        "Clean candles:",
        len(clean_df)
    )

    print(
        "Trading days:",
        len(quality_df)
    )

    print(
        "Passed:",
        passed_days
    )

    print(
        "Review:",
        review_days
    )


# =========================================================
# COMBINED QUALITY REPORT
# =========================================================

combined_quality = (
    pd.concat(
        all_quality,
        ignore_index=True,
    )
)


combined_quality.to_csv(
    QUALITY_FILE,
    index=False,
)


summary_df = pd.DataFrame(
    summary_rows
)


summary_df.to_csv(
    SUMMARY_FILE,
    index=False,
)


# =========================================================
# FINAL SUMMARY
# =========================================================

print()
print("=" * 80)

print(
    "MULTI-STOCK ONE-YEAR DOWNLOAD COMPLETE"
)

print("=" * 80)

print()


print(
    summary_df[
        [
            "symbol",
            "raw_candles",
            "clean_candles",
            "trading_days",
            "passed_days",
            "review_days",
        ]
    ].to_string(
        index=False
    )
)


total_review_days = int(
    summary_df[
        "review_days"
    ].sum()
)


symbols_with_review = int(
    (
        summary_df[
            "review_days"
        ]
        > 0
    ).sum()
)


print()

print(
    "Total symbols:",
    len(summary_df)
)

print(
    "Symbols with review days:",
    symbols_with_review
)

print(
    "Total review-day records:",
    total_review_days
)


# =========================================================
# SHOW REVIEW ROWS
# =========================================================

if total_review_days > 0:

    print()
    print(
        "ROWS REQUIRING REVIEW:"
    )


    review_rows = (
        combined_quality[
            combined_quality[
                "status"
            ]
            == "REVIEW"
        ]
    )


    print(
        review_rows[
            [
                "symbol",
                "trade_date",
                "session_type",
                "expected_candles",
                "actual_candles",
                "missing_candles",
                "unexpected_candles",
                "zero_volume_candles",
                "duplicate_candles",
            ]
        ].to_string(
            index=False
        )
    )


else:

    print()

    print(
        "ALL SYMBOLS PASSED "
        "DATA QUALITY VALIDATION"
    )


# =========================================================
# FILE LOCATIONS
# =========================================================

print()

print(
    "Symbol master:"
)

print(
    SYMBOL_MASTER_FILE
)


print()

print(
    "Quality report:"
)

print(
    QUALITY_FILE
)


print()

print(
    "Download summary:"
)

print(
    SUMMARY_FILE
)


# =========================================================
# LOGOUT
# =========================================================

try:

    smart_api.terminateSession(
        client_code
    )

except Exception:

    pass