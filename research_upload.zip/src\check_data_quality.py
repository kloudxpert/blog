import os
import pyotp
import pandas as pd

from dotenv import load_dotenv
from SmartApi import SmartConnect

load_dotenv()

api_key = os.getenv("ANGEL_API_KEY")
client_code = os.getenv("ANGEL_CLIENT_CODE")
mpin = os.getenv("ANGEL_MPIN")
totp_secret = os.getenv("ANGEL_TOTP_SECRET")

smart_api = SmartConnect(api_key=api_key)

session = smart_api.generateSession(
    client_code,
    mpin,
    pyotp.TOTP(totp_secret).now()
)

if not session.get("status"):
    raise RuntimeError(
        f"Login failed: {session.get('message')}"
    )

dates = [
    "2026-09-16",
    "2026-09-17",
    "2026-09-18",
]

for trade_date in dates:

    params = {
        "exchange": "NSE",
        "symboltoken": "3045",   # SBIN-EQ
        "interval": "FIVE_MINUTE",
        "fromdate": f"{trade_date} 09:15",
        "todate": f"{trade_date} 15:30",
    }

    response = smart_api.getCandleData(params)

    print()
    print("=" * 50)
    print("Date:", trade_date)

    if not response.get("status") or not response.get("data"):
        print("DATA REQUEST FAILED")
        print(response.get("message"))
        continue

    df = pd.DataFrame(
        response["data"],
        columns=[
            "timestamp",
            "open",
            "high",
            "low",
            "close",
            "volume",
        ],
    )

    df["timestamp"] = pd.to_datetime(df["timestamp"])

    expected = pd.date_range(
        start=f"{trade_date} 09:15",
        end=f"{trade_date} 15:25",
        freq="5min",
        tz="Asia/Kolkata",
    )

    actual = pd.DatetimeIndex(df["timestamp"])
    missing = expected.difference(actual)

    zero_volume = df[df["volume"] == 0]

    print("Candles returned:", len(df))
    print("Expected candles:", len(expected))
    print("Missing candles:", len(missing))
    print("Zero-volume candles:", len(zero_volume))

    if len(missing):
        print("\nMissing timestamps:")
        for ts in missing:
            print(" ", ts)

    if len(zero_volume):
        print("\nZero-volume candles:")
        print(
            zero_volume[
                ["timestamp", "open", "high", "low", "close", "volume"]
            ].to_string(index=False)
        )