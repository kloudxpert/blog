import os
import time
from datetime import date, datetime, timedelta

import pandas as pd
import pyotp

from dotenv import load_dotenv
from SmartApi import SmartConnect


# =========================================================
# FIXED 30-STOCK RESEARCH UNIVERSE
# =========================================================

SYMBOLS = [
    "SBIN",
    "RELIANCE",
    "HDFCBANK",
    "ICICIBANK",
    "INFY",
    "TCS",
    "LT",
    "AXISBANK",
    "BHARTIARTL",
    "ITC",

    "KOTAKBANK",
    "BAJFINANCE",

    "HCLTECH",
    "WIPRO",
    "TECHM",

    "MARUTI",
    "M&M",
    "EICHERMOT",

    "SUNPHARMA",
    "DRREDDY",
    "CIPLA",

    "HINDUNILVR",
    "ASIANPAINT",
    "TITAN",

    "NTPC",
    "POWERGRID",
    "ONGC",
    "COALINDIA",

    "TATASTEEL",
    "ULTRACEMCO",
]


# =========================================================
# DATE STRUCTURE
# =========================================================

DOWNLOAD_START = date(2024, 1, 1)
DOWNLOAD_END = date(2025, 9, 19)

DEVELOPMENT_START = date(2024, 1, 1)
DEVELOPMENT_END = date(2025, 3, 31)

LOCKED_START = date(2025, 4, 1)
LOCKED_END = date(2025, 9, 19)


# =========================================================
# SPECIAL NON-STANDARD SESSIONS
#
# We deliberately exclude these from normal intraday
# strategy research.
# =========================================================

SPECIAL_EXCLUDED_DATES = {
    date(2024, 1, 20),
    date(2024, 3, 2),
    date(2024, 11, 1),
}


# =========================================================
# SMARTAPI CONFIGURATION
# =========================================================

EXCHANGE = "NSE"
INTERVAL = "FIVE_MINUTE"

CHUNK_DAYS = 30

MAX_RETRIES = 5

SYMBOL_SEARCH_DELAY_SECONDS = 2.0
CANDLE_REQUEST_DELAY_SECONDS = 1.5


# =========================================================
# DIRECTORIES
# =========================================================

ROOT = r"data\research30"

RAW_DIR = os.path.join(
    ROOT,
    "raw",
)

CLEAN_DIR = os.path.join(
    ROOT,
    "clean",
)

DEVELOPMENT_DIR = os.path.join(
    ROOT,
    "development",
)

LOCKED_DIR = os.path.join(
    ROOT,
    "LOCKED_VALIDATION_DO_NOT_USE",
)

RESULTS_DIR = (
    r"results\research30"
)


for folder in [
    RAW_DIR,
    CLEAN_DIR,
    DEVELOPMENT_DIR,
    LOCKED_DIR,
    RESULTS_DIR,
]:

    os.makedirs(
        folder,
        exist_ok=True,
    )


# =========================================================
# OUTPUT FILES
# =========================================================

SYMBOL_MASTER_FILE = os.path.join(
    RESULTS_DIR,
    "symbol_master.csv",
)

QUALITY_FILE = os.path.join(
    RESULTS_DIR,
    "quality_report.csv",
)

SUMMARY_FILE = os.path.join(
    RESULTS_DIR,
    "download_summary.csv",
)

SPLIT_MANIFEST_FILE = os.path.join(
    RESULTS_DIR,
    "research_split_manifest.csv",
)


# =========================================================
# LOAD ANGEL ONE CREDENTIALS
# =========================================================

load_dotenv()

api_key = os.getenv(
    "ANGEL_API_KEY"
)

client_code = os.getenv(
    "ANGEL_CLIENT_CODE"
)

mpin = os.getenv(
    "ANGEL_MPIN"
)

totp_secret = os.getenv(
    "ANGEL_TOTP_SECRET"
)


required = {
    "ANGEL_API_KEY": api_key,
    "ANGEL_CLIENT_CODE": client_code,
    "ANGEL_MPIN": mpin,
    "ANGEL_TOTP_SECRET": totp_secret,
}


missing = [
    key
    for key, value
    in required.items()
    if not value
]


if missing:

    raise RuntimeError(
        "Missing environment variables: "
        + ", ".join(missing)
    )


# =========================================================
# LOGIN
# =========================================================

print(
    "Logging in to Angel One SmartAPI..."
)


smart_api = SmartConnect(
    api_key=api_key
)


session = smart_api.generateSession(
    client_code,
    mpin,
    pyotp.TOTP(
        totp_secret
    ).now(),
)


if not session.get("status"):

    raise RuntimeError(
        "SmartAPI login failed: "
        + str(
            session.get("message")
        )
    )


print("Login successful")


# =========================================================
# RESOLVE SYMBOL TOKEN
# =========================================================

def resolve_symbol_token(symbol):

    expected = (
        f"{symbol}-EQ"
    )

    print(
        f"Resolving {expected}..."
    )


    last_error = None


    for attempt in range(
        1,
        MAX_RETRIES + 1,
    ):

        try:

            response = (
                smart_api.searchScrip(
                    EXCHANGE,
                    symbol,
                )
            )


            if not response.get(
                "status"
            ):

                raise RuntimeError(
                    str(
                        response.get(
                            "message"
                        )
                    )
                )


            records = (
                response.get("data")
                or []
            )


            matches = [
                item
                for item in records
                if (
                    item.get("exchange")
                    == EXCHANGE
                    and item.get(
                        "tradingsymbol"
                    )
                    == expected
                )
            ]


            if len(matches) != 1:

                raise RuntimeError(
                    f"{expected}: "
                    f"expected exactly 1 match, "
                    f"found {len(matches)}"
                )


            item = matches[0]


            return {
                "symbol":
                    symbol,

                "tradingsymbol":
                    item[
                        "tradingsymbol"
                    ],

                "symboltoken":
                    str(
                        item[
                            "symboltoken"
                        ]
                    ),
            }


        except Exception as exc:

            last_error = exc

            print(
                f"{symbol}: token search "
                f"attempt {attempt} failed:"
            )

            print(
                f"  {type(exc).__name__}: "
                f"{exc}"
            )


        if attempt < MAX_RETRIES:

            wait_seconds = (
                3 * attempt
            )

            print(
                f"Waiting "
                f"{wait_seconds}s..."
            )

            time.sleep(
                wait_seconds
            )


    raise RuntimeError(
        f"Unable to resolve "
        f"{expected}. "
        f"Last error: {last_error}"
    )


# =========================================================
# FETCH ONE HISTORICAL CHUNK
# =========================================================

def fetch_chunk(
    symbol,
    token,
    start_date,
    end_date,
):

    params = {
        "exchange":
            EXCHANGE,

        "symboltoken":
            token,

        "interval":
            INTERVAL,

        "fromdate":
            f"{start_date} 09:15",

        "todate":
            f"{end_date} 19:30",
    }


    last_error = None


    for attempt in range(
        1,
        MAX_RETRIES + 1,
    ):

        try:

            print(
                f"{symbol}: "
                f"{start_date} -> "
                f"{end_date} "
                f"(attempt {attempt})"
            )


            response = (
                smart_api
                .getCandleData(
                    params
                )
            )


            if (
                response.get("status")
                and response.get("data")
            ):

                return (
                    response["data"]
                )


            raise RuntimeError(
                str(
                    response.get(
                        "message"
                    )
                )
            )


        except Exception as exc:

            last_error = exc

            print(
                f"{symbol}: candle request "
                f"failed:"
            )

            print(
                f"  {type(exc).__name__}: "
                f"{exc}"
            )


        if attempt < MAX_RETRIES:

            wait_seconds = (
                3 * attempt
            )

            print(
                f"Waiting "
                f"{wait_seconds}s..."
            )

            time.sleep(
                wait_seconds
            )


    raise RuntimeError(
        f"{symbol}: failed "
        f"{start_date} -> {end_date}. "
        f"Last error: {last_error}"
    )


# =========================================================
# DOWNLOAD / LOAD ONE SYMBOL
# =========================================================

def download_symbol(
    symbol,
    token,
):

    raw_file = os.path.join(
        RAW_DIR,
        (
            f"{symbol}_5min_"
            f"2024-01-01_to_"
            f"2025-09-19_raw.csv"
        ),
    )


    # -----------------------------------------------------
    # RESUME SUPPORT
    #
    # If this stock already completed successfully during
    # an earlier run, reuse it instead of downloading again.
    # -----------------------------------------------------

    if os.path.exists(
        raw_file
    ):

        print(
            f"{symbol}: existing raw file found. "
            f"Reusing it."
        )

        df = pd.read_csv(
            raw_file
        )

        df["timestamp"] = (
            pd.to_datetime(
                df["timestamp"]
            )
        )


        return (
            df,
            raw_file,
        )


    # -----------------------------------------------------
    # DOWNLOAD
    # -----------------------------------------------------

    rows = []

    current = (
        DOWNLOAD_START
    )


    while current <= DOWNLOAD_END:

        chunk_end = min(
            current
            + timedelta(
                days=CHUNK_DAYS - 1
            ),
            DOWNLOAD_END,
        )


        chunk = fetch_chunk(
            symbol,
            token,
            current,
            chunk_end,
        )


        rows.extend(
            chunk
        )


        current = (
            chunk_end
            + timedelta(days=1)
        )


        time.sleep(
            CANDLE_REQUEST_DELAY_SECONDS
        )


    if not rows:

        raise RuntimeError(
            f"{symbol}: "
            f"no historical candles returned."
        )


    # -----------------------------------------------------
    # BUILD DATAFRAME
    # -----------------------------------------------------

    df = pd.DataFrame(
        rows,
        columns=[
            "timestamp",
            "open",
            "high",
            "low",
            "close",
            "volume",
        ],
    )


    df["timestamp"] = (
        pd.to_datetime(
            df["timestamp"]
        )
    )


    for column in [
        "open",
        "high",
        "low",
        "close",
        "volume",
    ]:

        df[column] = (
            pd.to_numeric(
                df[column],
                errors="coerce",
            )
        )


    if (
        df[
            [
                "open",
                "high",
                "low",
                "close",
                "volume",
            ]
        ]
        .isna()
        .any()
        .any()
    ):

        raise RuntimeError(
            f"{symbol}: "
            f"non-numeric OHLCV detected."
        )


    df = (
        df
        .drop_duplicates(
            subset=["timestamp"]
        )
        .sort_values(
            "timestamp"
        )
        .reset_index(drop=True)
    )


    df.to_csv(
        raw_file,
        index=False,
    )


    return (
        df,
        raw_file,
    )


# =========================================================
# CREATE NORMAL-SESSION RESEARCH DATA
# =========================================================

def build_clean_data(
    symbol,
    raw_df,
):

    df = raw_df.copy()


    df["trade_date"] = (
        df["timestamp"]
        .dt.date
    )


    df["trade_time"] = (
        df["timestamp"]
        .dt.time
    )


    session_start = (
        datetime.strptime(
            "09:15",
            "%H:%M",
        ).time()
    )


    last_candle = (
        datetime.strptime(
            "15:25",
            "%H:%M",
        ).time()
    )


    # -----------------------------------------------------
    # Keep ordinary continuous-session candles.
    # -----------------------------------------------------

    clean = df[
        (
            df["trade_time"]
            >= session_start
        )
        &
        (
            df["trade_time"]
            <= last_candle
        )
        &
        (
            ~df["trade_date"]
            .isin(
                SPECIAL_EXCLUDED_DATES
            )
        )
    ].copy()


    clean = (
        clean[
            [
                "timestamp",
                "open",
                "high",
                "low",
                "close",
                "volume",
            ]
        ]
        .sort_values(
            "timestamp"
        )
        .reset_index(drop=True)
    )


    clean_file = os.path.join(
        CLEAN_DIR,
        (
            f"{symbol}_5min_"
            f"2024-01-01_to_"
            f"2025-09-19_clean.csv"
        ),
    )


    clean.to_csv(
        clean_file,
        index=False,
    )


    return (
        clean,
        clean_file,
    )


# =========================================================
# DATA QUALITY VALIDATION
# =========================================================

def validate_symbol(
    symbol,
    clean_df,
):

    df = clean_df.copy()


    df["trade_date"] = (
        df["timestamp"]
        .dt.date
    )


    quality_rows = []


    for trade_date, day in (
        df.groupby(
            "trade_date"
        )
    ):

        expected = (
            pd.date_range(
                start=(
                    f"{trade_date} "
                    f"09:15"
                ),
                end=(
                    f"{trade_date} "
                    f"15:25"
                ),
                freq="5min",
                tz="Asia/Kolkata",
            )
        )


        actual = (
            pd.DatetimeIndex(
                day[
                    "timestamp"
                ]
            )
        )


        missing = (
            expected.difference(
                actual
            )
        )


        unexpected = (
            actual.difference(
                expected
            )
        )


        zero_volume = int(
            (
                day["volume"]
                <= 0
            ).sum()
        )


        duplicates = int(
            day[
                "timestamp"
            ]
            .duplicated()
            .sum()
        )


        bad_ohlc = int(
            (
                (day["low"] > day["high"])
                |
                (day["open"] < day["low"])
                |
                (day["open"] > day["high"])
                |
                (day["close"] < day["low"])
                |
                (day["close"] > day["high"])
                |
                (day["open"] <= 0)
                |
                (day["high"] <= 0)
                |
                (day["low"] <= 0)
                |
                (day["close"] <= 0)
            ).sum()
        )


        actual_count = (
            len(day)
        )


        passed = (
            actual_count == 75
            and len(missing) == 0
            and len(unexpected) == 0
            and zero_volume == 0
            and duplicates == 0
            and bad_ohlc == 0
        )


        if trade_date <= DEVELOPMENT_END:

            period = (
                "DEVELOPMENT"
            )

        else:

            period = (
                "LOCKED_VALIDATION"
            )


        quality_rows.append(
            {
                "symbol":
                    symbol,

                "trade_date":
                    trade_date,

                "period":
                    period,

                "expected_candles":
                    75,

                "actual_candles":
                    actual_count,

                "missing_candles":
                    len(missing),

                "unexpected_candles":
                    len(unexpected),

                "zero_volume_candles":
                    zero_volume,

                "duplicate_candles":
                    duplicates,

                "bad_ohlc_candles":
                    bad_ohlc,

                "status":
                    (
                        "PASS"
                        if passed
                        else "REVIEW"
                    ),

                "missing_timestamps":
                    "; ".join(
                        str(x)
                        for x in missing
                    ),
            }
        )


    return pd.DataFrame(
        quality_rows
    )


# =========================================================
# SPLIT DEVELOPMENT VS LOCKED VALIDATION
# =========================================================

def save_splits(
    symbol,
    clean_df,
):

    df = clean_df.copy()


    df["trade_date"] = (
        df["timestamp"]
        .dt.date
    )


    development = (
        df[
            (
                df["trade_date"]
                >= DEVELOPMENT_START
            )
            &
            (
                df["trade_date"]
                <= DEVELOPMENT_END
            )
        ]
        .copy()
    )


    locked = (
        df[
            (
                df["trade_date"]
                >= LOCKED_START
            )
            &
            (
                df["trade_date"]
                <= LOCKED_END
            )
        ]
        .copy()
    )


    columns = [
        "timestamp",
        "open",
        "high",
        "low",
        "close",
        "volume",
    ]


    development_file = (
        os.path.join(
            DEVELOPMENT_DIR,
            (
                f"{symbol}_"
                f"development.csv"
            ),
        )
    )


    locked_file = (
        os.path.join(
            LOCKED_DIR,
            (
                f"{symbol}_"
                f"LOCKED.csv"
            ),
        )
    )


    development[
        columns
    ].to_csv(
        development_file,
        index=False,
    )


    locked[
        columns
    ].to_csv(
        locked_file,
        index=False,
    )


    return (
        development,
        locked,
        development_file,
        locked_file,
    )


# =========================================================
# RESOLVE TOKENS
# =========================================================

print()
print("=" * 78)
print("RESOLVING 30-STOCK UNIVERSE")
print("=" * 78)


symbol_records = []


for symbol in SYMBOLS:

    record = (
        resolve_symbol_token(
            symbol
        )
    )


    symbol_records.append(
        record
    )


    print(
        f"{symbol} -> "
        f"{record['tradingsymbol']} "
        f"(token "
        f"{record['symboltoken']})"
    )


    time.sleep(
        SYMBOL_SEARCH_DELAY_SECONDS
    )


symbol_master = (
    pd.DataFrame(
        symbol_records
    )
)


symbol_master.to_csv(
    SYMBOL_MASTER_FILE,
    index=False,
)


# =========================================================
# DOWNLOAD + VALIDATE
# =========================================================

all_quality = []

summary_rows = []

day_sets = {}


for record in symbol_records:

    symbol = (
        record["symbol"]
    )

    token = (
        record["symboltoken"]
    )


    print()
    print("=" * 78)
    print(
        f"PROCESSING {symbol}"
    )
    print("=" * 78)


    raw_df, raw_file = (
        download_symbol(
            symbol,
            token,
        )
    )


    clean_df, clean_file = (
        build_clean_data(
            symbol,
            raw_df,
        )
    )


    quality = (
        validate_symbol(
            symbol,
            clean_df,
        )
    )


    all_quality.append(
        quality
    )


    (
        development,
        locked,
        development_file,
        locked_file,
    ) = save_splits(
        symbol,
        clean_df,
    )


    clean_dates = set(
        clean_df[
            "timestamp"
        ]
        .dt.date
        .unique()
    )


    day_sets[
        symbol
    ] = clean_dates


    review_days = int(
        (
            quality[
                "status"
            ]
            == "REVIEW"
        ).sum()
    )


    summary_rows.append(
        {
            "symbol":
                symbol,

            "raw_candles":
                len(raw_df),

            "clean_candles":
                len(clean_df),

            "trading_days":
                len(clean_dates),

            "development_days":
                development[
                    "timestamp"
                ]
                .dt.date
                .nunique(),

            "locked_days":
                locked[
                    "timestamp"
                ]
                .dt.date
                .nunique(),

            "review_days":
                review_days,
        }
    )


    print(
        "Raw candles:",
        len(raw_df)
    )

    print(
        "Clean candles:",
        len(clean_df)
    )

    print(
        "Development days:",
        development[
            "timestamp"
        ]
        .dt.date
        .nunique()
    )

    print(
        "Locked validation days:",
        locked[
            "timestamp"
        ]
        .dt.date
        .nunique()
    )

    print(
        "Review days:",
        review_days
    )


# =========================================================
# COMBINED QUALITY REPORT
# =========================================================

quality_df = (
    pd.concat(
        all_quality,
        ignore_index=True,
    )
)


quality_df.to_csv(
    QUALITY_FILE,
    index=False,
)


summary_df = (
    pd.DataFrame(
        summary_rows
    )
)


# =========================================================
# CROSS-STOCK TRADING-DAY CONSISTENCY
# =========================================================

reference_symbol = (
    SYMBOLS[0]
)

reference_days = (
    day_sets[
        reference_symbol
    ]
)


missing_vs_reference = {}

extra_vs_reference = {}


for symbol in SYMBOLS:

    missing = (
        reference_days
        - day_sets[symbol]
    )

    extra = (
        day_sets[symbol]
        - reference_days
    )


    missing_vs_reference[
        symbol
    ] = len(missing)

    extra_vs_reference[
        symbol
    ] = len(extra)


summary_df[
    "missing_days_vs_sbin"
] = (
    summary_df[
        "symbol"
    ].map(
        missing_vs_reference
    )
)


summary_df[
    "extra_days_vs_sbin"
] = (
    summary_df[
        "symbol"
    ].map(
        extra_vs_reference
    )
)


summary_df.to_csv(
    SUMMARY_FILE,
    index=False,
)


# =========================================================
# SPLIT MANIFEST
# =========================================================

manifest = pd.DataFrame(
    [
        {
            "dataset":
                "DEVELOPMENT",

            "start_date":
                DEVELOPMENT_START,

            "end_date":
                DEVELOPMENT_END,

            "allowed_use":
                (
                    "Research, feature analysis, "
                    "hypothesis development"
                ),
        },

        {
            "dataset":
                "LOCKED_VALIDATION",

            "start_date":
                LOCKED_START,

            "end_date":
                LOCKED_END,

            "allowed_use":
                (
                    "DO NOT inspect or optimize against "
                    "until strategy rules are frozen"
                ),
        },

        {
            "dataset":
                "ALREADY_EXPLORED",

            "start_date":
                date(2025, 9, 22),

            "end_date":
                date(2026, 9, 18),

            "allowed_use":
                (
                    "Reference only; not valid "
                    "as unseen proof"
                ),
        },
    ]
)


manifest.to_csv(
    SPLIT_MANIFEST_FILE,
    index=False,
)


# =========================================================
# FINAL REPORT
# =========================================================

print()
print("=" * 100)
print(
    "30-STOCK RESEARCH DATASET DOWNLOAD COMPLETE"
)
print("=" * 100)


print(
    summary_df[
        [
            "symbol",
            "clean_candles",
            "trading_days",
            "development_days",
            "locked_days",
            "review_days",
            "missing_days_vs_sbin",
            "extra_days_vs_sbin",
        ]
    ].to_string(
        index=False
    )
)


total_review = int(
    summary_df[
        "review_days"
    ].sum()
)


print()

print(
    "Total stocks:",
    len(summary_df)
)

print(
    "Total review-day records:",
    total_review
)


day_mismatch_stocks = int(
    (
        (
            summary_df[
                "missing_days_vs_sbin"
            ]
            > 0
        )
        |
        (
            summary_df[
                "extra_days_vs_sbin"
            ]
            > 0
        )
    ).sum()
)


print(
    "Stocks with trading-day mismatch:",
    day_mismatch_stocks
)


if total_review > 0:

    print()
    print(
        "QUALITY ROWS REQUIRING REVIEW:"
    )


    print(
        quality_df[
            quality_df[
                "status"
            ]
            == "REVIEW"
        ][
            [
                "symbol",
                "trade_date",
                "period",
                "expected_candles",
                "actual_candles",
                "missing_candles",
                "zero_volume_candles",
                "bad_ohlc_candles",
            ]
        ].to_string(
            index=False
        )
    )


else:

    print()

    print(
        "ALL OBSERVED NORMAL TRADING DAYS "
        "PASSED CANDLE VALIDATION"
    )


print()
print(
    "Development data:"
)

print(
    DEVELOPMENT_DIR
)


print()
print(
    "LOCKED validation data:"
)

print(
    LOCKED_DIR
)


print()
print(
    "IMPORTANT: DO NOT ANALYZE THE LOCKED "
    "VALIDATION DIRECTORY YET."
)


print()
print(
    "Summary:"
)

print(
    SUMMARY_FILE
)


print()
print(
    "Research split manifest:"
)

print(
    SPLIT_MANIFEST_FILE
)


# =========================================================
# LOGOUT
# =========================================================

try:

    smart_api.terminateSession(
        client_code
    )

except Exception:

    pass