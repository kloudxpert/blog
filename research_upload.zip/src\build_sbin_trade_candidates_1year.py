from datetime import date, time

import pandas as pd


# ---------------------------------------------------------
# Files
# ---------------------------------------------------------

INPUT_FILE = (
    r"data\SBIN_5min_"
    r"2025-09-22_to_2026-09-18_indicators.csv"
)

OUTPUT_FILE = (
    r"results\SBIN_strategy_v1_1year_trade_candidates.csv"
)


# ---------------------------------------------------------
# Configuration
# ---------------------------------------------------------

ENTRY_START = time(9, 30)
ENTRY_END = time(14, 45)

EXCLUDED_DATES = {
    date(2025, 10, 21),  # Muhurat Trading
}


# ---------------------------------------------------------
# Load data
# ---------------------------------------------------------

df = pd.read_csv(INPUT_FILE)

df["timestamp"] = pd.to_datetime(
    df["timestamp"]
)

df = (
    df
    .sort_values("timestamp")
    .reset_index(drop=True)
)

df["trade_date"] = (
    df["timestamp"].dt.date
)

df["trade_time"] = (
    df["timestamp"].dt.time
)


# ---------------------------------------------------------
# Normal trading sessions only
# ---------------------------------------------------------

df["normal_session"] = (
    ~df["trade_date"].isin(
        EXCLUDED_DATES
    )
)


# ---------------------------------------------------------
# Signal trading window
# ---------------------------------------------------------

df["within_entry_window"] = (
    (df["trade_time"] >= ENTRY_START)
    & (df["trade_time"] <= ENTRY_END)
)


# ---------------------------------------------------------
# Strategy V1 conditions
# ---------------------------------------------------------

df["condition_vwap"] = (
    df["close"] > df["vwap"]
)

df["condition_ema"] = (
    df["ema9"] > df["ema20"]
)

df["condition_volume"] = (
    df["volume"]
    > 1.5 * df["avg_volume_prev10"]
)

df["condition_breakout"] = (
    df["close"]
    > df["highest_high_prev5"]
)


# ---------------------------------------------------------
# Indicators ready
# ---------------------------------------------------------

df["indicators_ready"] = (
    df["vwap"].notna()
    & df["ema9"].notna()
    & df["ema20"].notna()
    & df["atr14"].notna()
    & df["avg_volume_prev10"].notna()
    & df["highest_high_prev5"].notna()
    & df["lowest_low_prev5"].notna()
)


# ---------------------------------------------------------
# Raw long signal
# ---------------------------------------------------------

df["long_signal"] = (
    df["normal_session"]
    & df["within_entry_window"]
    & df["indicators_ready"]
    & df["condition_vwap"]
    & df["condition_ema"]
    & df["condition_volume"]
    & df["condition_breakout"]
)


# ---------------------------------------------------------
# Next candle from SAME trading day
# ---------------------------------------------------------

grouped = df.groupby("trade_date")

df["next_timestamp"] = (
    grouped["timestamp"]
    .shift(-1)
)

df["next_open"] = (
    grouped["open"]
    .shift(-1)
)


# ---------------------------------------------------------
# Extract raw signals
# ---------------------------------------------------------

signals = df[
    df["long_signal"]
].copy()


# ---------------------------------------------------------
# Actual entry = next candle open
# ---------------------------------------------------------

signals["entry_timestamp"] = (
    signals["next_timestamp"]
)

signals["entry_price"] = (
    signals["next_open"]
)


# ---------------------------------------------------------
# Ensure actual entry also occurs no later than 14:45
# ---------------------------------------------------------

signals["entry_time"] = (
    signals["entry_timestamp"].dt.time
)

signals["entry_within_window"] = (
    signals["entry_timestamp"].notna()
    & (signals["entry_time"] <= ENTRY_END)
)


# ---------------------------------------------------------
# Next candle availability
# ---------------------------------------------------------

signals["next_candle_available"] = (
    signals["entry_timestamp"].notna()
    & signals["entry_price"].notna()
)


# ---------------------------------------------------------
# 0.5 ATR entry-gap filter
# ---------------------------------------------------------

signals["entry_gap"] = (
    signals["entry_price"]
    - signals["close"]
)

signals["max_allowed_gap"] = (
    0.5 * signals["atr14"]
)

signals["gap_filter_pass"] = (
    signals["entry_gap"]
    <= signals["max_allowed_gap"]
)


# ---------------------------------------------------------
# Final valid trade candidates
# ---------------------------------------------------------

candidates = signals[
    signals["next_candle_available"]
    & signals["entry_within_window"]
    & signals["gap_filter_pass"]
].copy()


# ---------------------------------------------------------
# Diagnostics
# ---------------------------------------------------------

raw_signals = len(signals)

next_available = int(
    signals["next_candle_available"].sum()
)

gap_pass = int(
    (
        signals["next_candle_available"]
        & signals["gap_filter_pass"]
    ).sum()
)

gap_rejected = int(
    (
        signals["next_candle_available"]
        & ~signals["gap_filter_pass"]
    ).sum()
)

late_rejected = int(
    (
        signals["next_candle_available"]
        & ~signals["entry_within_window"]
    ).sum()
)


print("=" * 72)
print(
    "SBIN STRATEGY V1 - ONE-YEAR "
    "TRADE CANDIDATE ANALYSIS"
)
print("=" * 72)

print(
    "Raw Strategy V1 signals:",
    raw_signals
)

print(
    "Signals with next candle available:",
    next_available
)

print(
    "Signals passing 0.5 ATR gap filter:",
    gap_pass
)

print(
    "Signals rejected by gap filter:",
    gap_rejected
)

print(
    "Signals rejected because entry was after 14:45:",
    late_rejected
)

print(
    "Final valid trade candidates:",
    len(candidates)
)

print()

print(
    "Trading days containing at least one valid candidate:",
    candidates["trade_date"].nunique()
)


# ---------------------------------------------------------
# Candidate count by month
# ---------------------------------------------------------

if not candidates.empty:

    candidates["month"] = (
        candidates["timestamp"]
        .dt.strftime("%Y-%m")
    )

    monthly = (
        candidates
        .groupby("month")
        .size()
        .reset_index(
            name="candidate_count"
        )
    )

    print()
    print("Valid candidates by month:")

    print(
        monthly.to_string(
            index=False
        )
    )


# ---------------------------------------------------------
# Late entry examples
# ---------------------------------------------------------

late_entries = signals[
    signals["next_candle_available"]
    & ~signals["entry_within_window"]
].copy()


if not late_entries.empty:

    print()
    print(
        "First late-entry rejections:"
    )

    print(
        late_entries[
            [
                "timestamp",
                "close",
                "entry_timestamp",
                "entry_price",
            ]
        ]
        .head(10)
        .to_string(index=False)
    )


# ---------------------------------------------------------
# Gap rejection examples
# ---------------------------------------------------------

gap_rejections = signals[
    signals["next_candle_available"]
    & signals["entry_within_window"]
    & ~signals["gap_filter_pass"]
].copy()


if not gap_rejections.empty:

    print()
    print(
        "First gap-filter rejections:"
    )

    print(
        gap_rejections[
            [
                "timestamp",
                "close",
                "entry_timestamp",
                "entry_price",
                "atr14",
                "entry_gap",
                "max_allowed_gap",
            ]
        ]
        .head(10)
        .to_string(index=False)
    )


# ---------------------------------------------------------
# Save
# ---------------------------------------------------------

save_columns = [
    "timestamp",
    "trade_date",
    "close",
    "vwap",
    "ema9",
    "ema20",
    "volume",
    "avg_volume_prev10",
    "highest_high_prev5",
    "lowest_low_prev5",
    "atr14",
    "entry_timestamp",
    "entry_price",
    "entry_gap",
    "max_allowed_gap",
]


candidates[
    save_columns
].to_csv(
    OUTPUT_FILE,
    index=False,
)


print()
print(
    "Trade candidate file saved to:",
    OUTPUT_FILE
)

print()

print(
    "ONE-YEAR TRADE CANDIDATE ANALYSIS COMPLETE"
)