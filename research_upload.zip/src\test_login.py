import os
import pyotp
from dotenv import load_dotenv
from SmartApi import SmartConnect

load_dotenv()

api_key = os.getenv("ANGEL_API_KEY")
client_code = os.getenv("ANGEL_CLIENT_CODE")
mpin = os.getenv("ANGEL_MPIN")
totp_secret = os.getenv("ANGEL_TOTP_SECRET")

required = {
    "ANGEL_API_KEY": api_key,
    "ANGEL_CLIENT_CODE": client_code,
    "ANGEL_MPIN": mpin,
    "ANGEL_TOTP_SECRET": totp_secret,
}

missing = [name for name, value in required.items() if not value]

if missing:
    raise RuntimeError(f"Missing environment variables: {', '.join(missing)}")

try:
    current_totp = pyotp.TOTP(totp_secret).now()

    smart_api = SmartConnect(api_key=api_key)

    session = smart_api.generateSession(
        client_code,
        mpin,
        current_totp
    )

    if session.get("status"):
        print("Angel One SmartAPI login successful")
    else:
        print("Login failed")
        print("Message:", session.get("message"))
        print("Error code:", session.get("errorcode"))

except Exception as exc:
    print("Login test failed")
    print(type(exc).__name__, str(exc))