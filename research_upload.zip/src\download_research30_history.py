﻿import logging
import os
import time
from datetime import date, datetime, timedelta

import pandas as pd
import pyotp
from dotenv import load_dotenv


# =========================================================
# SECURITY
#
# SmartAPI may print request headers when requests fail.
# Those headers can contain sensitive information.
# Disable SDK logging before importing SmartConnect.
# =========================================================

logging.disable(logging.CRITICAL)

try:
    import logzero

    logzero.loglevel(logging.CRITICAL)
except Exception:
    pass

from SmartApi import SmartConnect


# =========================================================
# FIXED 30-STOCK RESEARCH UNIVERSE
# =========================================================

SYMBOLS = [
    "SBIN",
    "RELIANCE",
    "HDFCBANK",
    "ICICIBANK",
    "INFY",
    "TCS",
    "LT",
    "AXISBANK",
    "BHARTIARTL",
    "ITC",

    "KOTAKBANK",
    "BAJFINANCE",

    "HCLTECH",
    "WIPRO",
    "TECHM",

    "MARUTI",
    "M&M",
    "EICHERMOT",

    "SUNPHARMA",
    "DRREDDY",
    "CIPLA",

    "HINDUNILVR",
    "ASIANPAINT",
    "TITAN",

    "NTPC",
    "POWERGRID",
    "ONGC",
    "COALINDIA",

    "TATASTEEL",
    "ULTRACEMCO",
]


# =========================================================
# FIXED RESEARCH PERIODS
# =========================================================

DOWNLOAD_START = date(2024, 1, 1)
DOWNLOAD_END = date(2025, 9, 19)

DEVELOPMENT_START = date(2024, 1, 1)
DEVELOPMENT_END = date(2025, 3, 31)

LOCKED_START = date(2025, 4, 1)
LOCKED_END = date(2025, 9, 19)


# =========================================================
# SPECIAL / NON-STANDARD NSE SESSIONS
#
# Do not treat these as ordinary full intraday sessions.
# =========================================================

SPECIAL_EXCLUDED_DATES = {
    date(2024, 1, 20),
    date(2024, 3, 2),
    date(2024, 5, 18),
    date(2024, 11, 1),
}


# =========================================================
# SMARTAPI SETTINGS
# =========================================================

EXCHANGE = "NSE"
INTERVAL = "FIVE_MINUTE"

CHUNK_DAYS = 30

MAX_RETRIES = 8

# Token lookup pacing
SYMBOL_SEARCH_DELAY_SECONDS = 3

# Historical-data pacing.
# Intentionally conservative because Angel One has
# been returning rate-limit responses.
CANDLE_REQUEST_DELAY_SECONDS = 10


# =========================================================
# RETRY BACKOFF
# =========================================================

RATE_LIMIT_WAIT = [
    60,
    120,
    180,
    240,
    300,
    300,
    300,
]

NETWORK_WAIT = [
    15,
    30,
    60,
    90,
    120,
    180,
    240,
]

OTHER_WAIT = [
    15,
    30,
    60,
    90,
    120,
    180,
    240,
]


# =========================================================
# DIRECTORIES
# =========================================================

ROOT = r"data\research30"

RAW_DIR = os.path.join(
    ROOT,
    "raw",
)

CHECKPOINT_DIR = os.path.join(
    ROOT,
    "checkpoints",
)

CLEAN_DIR = os.path.join(
    ROOT,
    "clean",
)

DEVELOPMENT_DIR = os.path.join(
    ROOT,
    "development",
)

LOCKED_DIR = os.path.join(
    ROOT,
    "LOCKED_VALIDATION_DO_NOT_USE",
)

RESULTS_DIR = (
    r"results\research30"
)


for folder in [
    RAW_DIR,
    CHECKPOINT_DIR,
    CLEAN_DIR,
    DEVELOPMENT_DIR,
    LOCKED_DIR,
    RESULTS_DIR,
]:

    os.makedirs(
        folder,
        exist_ok=True,
    )


# =========================================================
# OUTPUT FILES
# =========================================================

SYMBOL_MASTER_FILE = os.path.join(
    RESULTS_DIR,
    "symbol_master.csv",
)

QUALITY_FILE = os.path.join(
    RESULTS_DIR,
    "quality_report.csv",
)

SUMMARY_FILE = os.path.join(
    RESULTS_DIR,
    "download_summary.csv",
)

SPLIT_MANIFEST_FILE = os.path.join(
    RESULTS_DIR,
    "research_split_manifest.csv",
)


# =========================================================
# SAFE ERROR CLASSIFICATION
#
# Important:
# We inspect exception text internally but DO NOT print
# the raw exception because SmartAPI can embed headers.
# =========================================================

def classify_exception(exc):

    try:

        message = str(exc).lower()

    except Exception:

        return "API_ERROR"


    if (
        "exceeding access rate" in message
        or "access rate" in message
        or "rate limit" in message
        or "too many requests" in message
    ):

        return "RATE_LIMIT"


    if (
        "failed to resolve" in message
        or "name resolution" in message
        or "getaddrinfo" in message
        or "connection" in message
        or "timeout" in message
        or "timed out" in message
    ):

        return "NETWORK"


    return "API_ERROR"


def wait_before_retry(
    error_type,
    attempt,
):

    index = min(
        attempt - 1,
        6,
    )


    if error_type == "RATE_LIMIT":

        wait_seconds = (
            RATE_LIMIT_WAIT[index]
        )

    elif error_type == "NETWORK":

        wait_seconds = (
            NETWORK_WAIT[index]
        )

    else:

        wait_seconds = (
            OTHER_WAIT[index]
        )


    print(
        f"  {error_type} detected."
    )

    print(
        f"  Waiting {wait_seconds} seconds "
        f"before retry..."
    )


    time.sleep(
        wait_seconds
    )


# =========================================================
# LOAD CREDENTIALS
# =========================================================

load_dotenv()

api_key = os.getenv(
    "ANGEL_API_KEY"
)

client_code = os.getenv(
    "ANGEL_CLIENT_CODE"
)

mpin = os.getenv(
    "ANGEL_MPIN"
)

totp_secret = os.getenv(
    "ANGEL_TOTP_SECRET"
)


required = {
    "ANGEL_API_KEY": api_key,
    "ANGEL_CLIENT_CODE": client_code,
    "ANGEL_MPIN": mpin,
    "ANGEL_TOTP_SECRET": totp_secret,
}


missing = [
    key
    for key, value
    in required.items()
    if not value
]


if missing:

    raise RuntimeError(
        "Missing environment variables: "
        + ", ".join(missing)
    )


# =========================================================
# LOGIN
# =========================================================

print(
    "Logging in to Angel One SmartAPI..."
)


smart_api = SmartConnect(
    api_key=api_key
)


session = smart_api.generateSession(
    client_code,
    mpin,
    pyotp.TOTP(
        totp_secret
    ).now(),
)


if not session.get("status"):

    raise RuntimeError(
        "SmartAPI login failed."
    )


print(
    "Login successful"
)


# =========================================================
# SYMBOL TOKEN RESOLUTION
# =========================================================

def resolve_symbol_token(
    symbol,
):

    expected_symbol = (
        f"{symbol}-EQ"
    )


    for attempt in range(
        1,
        MAX_RETRIES + 1,
    ):

        try:

            response = (
                smart_api.searchScrip(
                    EXCHANGE,
                    symbol,
                )
            )


            if not response.get(
                "status"
            ):

                raise RuntimeError(
                    "Symbol search failed."
                )


            records = (
                response.get("data")
                or []
            )


            matches = [
                item
                for item in records
                if (
                    item.get("exchange")
                    == EXCHANGE
                    and item.get(
                        "tradingsymbol"
                    )
                    == expected_symbol
                )
            ]


            if len(matches) != 1:

                raise RuntimeError(
                    f"{expected_symbol}: "
                    f"expected 1 exact match, "
                    f"found {len(matches)}."
                )


            item = matches[0]


            return {
                "symbol":
                    symbol,

                "tradingsymbol":
                    item[
                        "tradingsymbol"
                    ],

                "symboltoken":
                    str(
                        item[
                            "symboltoken"
                        ]
                    ),
            }


        except Exception as exc:

            error_type = (
                classify_exception(
                    exc
                )
            )


            print(
                f"{symbol}: token lookup "
                f"attempt {attempt}/"
                f"{MAX_RETRIES} failed."
            )


            if attempt >= MAX_RETRIES:

                raise RuntimeError(
                    f"{symbol}: token resolution "
                    f"failed after "
                    f"{MAX_RETRIES} attempts."
                ) from None


            wait_before_retry(
                error_type,
                attempt,
            )


# =========================================================
# LOAD EXISTING SYMBOL MASTER OR RESOLVE MISSING TOKENS
# =========================================================

def load_symbol_master():

    existing = {}


    if os.path.exists(
        SYMBOL_MASTER_FILE
    ):

        try:

            old = pd.read_csv(
                SYMBOL_MASTER_FILE,
                dtype=str,
            )


            required_columns = {
                "symbol",
                "tradingsymbol",
                "symboltoken",
            }


            if required_columns.issubset(
                old.columns
            ):

                for _, row in (
                    old.iterrows()
                ):

                    existing[
                        row["symbol"]
                    ] = {
                        "symbol":
                            row["symbol"],

                        "tradingsymbol":
                            row[
                                "tradingsymbol"
                            ],

                        "symboltoken":
                            row[
                                "symboltoken"
                            ],
                    }


        except Exception:

            existing = {}


    records = []


    print()
    print(
        "=" * 78
    )

    print(
        "RESOLVING / REUSING SYMBOL TOKENS"
    )

    print(
        "=" * 78
    )


    for symbol in SYMBOLS:

        if symbol in existing:

            record = (
                existing[symbol]
            )


            print(
                f"{symbol}: "
                f"reusing saved token "
                f"{record['symboltoken']}"
            )


        else:

            print(
                f"{symbol}: "
                f"resolving token..."
            )


            record = (
                resolve_symbol_token(
                    symbol
                )
            )


            print(
                f"{symbol} -> "
                f"{record['tradingsymbol']} "
                f"(token "
                f"{record['symboltoken']})"
            )


            time.sleep(
                SYMBOL_SEARCH_DELAY_SECONDS
            )


        records.append(
            record
        )


        # Save progress immediately
        pd.DataFrame(
            records
        ).to_csv(
            SYMBOL_MASTER_FILE,
            index=False,
        )


    return records


# =========================================================
# CHECKPOINT PATH
# =========================================================

def checkpoint_path(
    symbol,
    start_date,
    end_date,
):

    folder = os.path.join(
        CHECKPOINT_DIR,
        symbol,
    )


    os.makedirs(
        folder,
        exist_ok=True,
    )


    return os.path.join(
        folder,
        (
            f"{start_date}_to_"
            f"{end_date}.csv"
        ),
    )


# =========================================================
# NORMALIZE API CANDLE DATA
# =========================================================

def build_dataframe(
    symbol,
    rows,
):

    df = pd.DataFrame(
        rows,
        columns=[
            "timestamp",
            "open",
            "high",
            "low",
            "close",
            "volume",
        ],
    )


    df["timestamp"] = (
        pd.to_datetime(
            df["timestamp"]
        )
    )


    for column in [
        "open",
        "high",
        "low",
        "close",
        "volume",
    ]:

        df[column] = (
            pd.to_numeric(
                df[column],
                errors="coerce",
            )
        )


    if (
        df[
            [
                "open",
                "high",
                "low",
                "close",
                "volume",
            ]
        ]
        .isna()
        .any()
        .any()
    ):

        raise RuntimeError(
            f"{symbol}: invalid OHLCV "
            f"data returned."
        )


    return (
        df
        .drop_duplicates(
            subset=["timestamp"]
        )
        .sort_values(
            "timestamp"
        )
        .reset_index(drop=True)
    )


# =========================================================
# DOWNLOAD ONE CHUNK
# =========================================================

def fetch_chunk(
    symbol,
    token,
    start_date,
    end_date,
):

    params = {
        "exchange":
            EXCHANGE,

        "symboltoken":
            token,

        "interval":
            INTERVAL,

        "fromdate":
            f"{start_date} 09:15",

        "todate":
            f"{end_date} 19:30",
    }


    for attempt in range(
        1,
        MAX_RETRIES + 1,
    ):

        try:

            print(
                f"{symbol}: "
                f"{start_date} -> "
                f"{end_date} "
                f"(attempt {attempt})"
            )


            response = (
                smart_api.getCandleData(
                    params
                )
            )


            if (
                response.get("status")
                and response.get("data")
            ):

                return (
                    response["data"]
                )


            raise RuntimeError(
                "Historical API returned "
                "no usable candle data."
            )


        except Exception as exc:

            error_type = (
                classify_exception(
                    exc
                )
            )


            print(
                f"{symbol}: candle request "
                f"attempt {attempt}/"
                f"{MAX_RETRIES} failed."
            )


            # Do NOT print exc here.
            # It may contain sensitive headers.


            if attempt >= MAX_RETRIES:

                raise RuntimeError(
                    f"{symbol}: failed chunk "
                    f"{start_date} -> "
                    f"{end_date} after "
                    f"{MAX_RETRIES} attempts."
                ) from None


            wait_before_retry(
                error_type,
                attempt,
            )


# =========================================================
# DOWNLOAD ONE STOCK
#
# Every successful 30-day chunk is stored immediately.
# =========================================================

def download_symbol(
    symbol,
    token,
):

    raw_file = os.path.join(
        RAW_DIR,
        (
            f"{symbol}_5min_"
            f"2024-01-01_to_"
            f"2025-09-19_raw.csv"
        ),
    )


    # -----------------------------------------------------
    # Entire stock already completed
    # -----------------------------------------------------

    if os.path.exists(
        raw_file
    ):

        print(
            f"{symbol}: completed raw "
            f"file exists. Reusing it."
        )


        df = pd.read_csv(
            raw_file
        )


        df["timestamp"] = (
            pd.to_datetime(
                df["timestamp"]
            )
        )


        return (
            df,
            raw_file,
        )


    # -----------------------------------------------------
    # Otherwise build from saved/downloaded chunks
    # -----------------------------------------------------

    chunk_frames = []

    current = (
        DOWNLOAD_START
    )


    while current <= DOWNLOAD_END:

        chunk_end = min(
            current
            + timedelta(
                days=CHUNK_DAYS - 1
            ),
            DOWNLOAD_END,
        )


        checkpoint = (
            checkpoint_path(
                symbol,
                current,
                chunk_end,
            )
        )


        # -------------------------------------------------
        # Already downloaded chunk
        # -------------------------------------------------

        if os.path.exists(
            checkpoint
        ):

            chunk_df = (
                pd.read_csv(
                    checkpoint
                )
            )


            chunk_df[
                "timestamp"
            ] = pd.to_datetime(
                chunk_df[
                    "timestamp"
                ]
            )


            print(
                f"{symbol}: checkpoint "
                f"found — skipping "
                f"{current} -> "
                f"{chunk_end}"
            )


        # -------------------------------------------------
        # Missing chunk
        # -------------------------------------------------

        else:

            rows = (
                fetch_chunk(
                    symbol,
                    token,
                    current,
                    chunk_end,
                )
            )


            chunk_df = (
                build_dataframe(
                    symbol,
                    rows,
                )
            )


            # Save immediately.
            chunk_df.to_csv(
                checkpoint,
                index=False,
            )


            print(
                f"{symbol}: checkpoint "
                f"saved "
                f"({len(chunk_df)} candles)"
            )


            print(
                f"Waiting "
                f"{CANDLE_REQUEST_DELAY_SECONDS}s "
                f"before next API request..."
            )


            time.sleep(
                CANDLE_REQUEST_DELAY_SECONDS
            )


        chunk_frames.append(
            chunk_df
        )


        current = (
            chunk_end
            + timedelta(days=1)
        )


    # -----------------------------------------------------
    # Merge all checkpoints
    # -----------------------------------------------------

    if not chunk_frames:

        raise RuntimeError(
            f"{symbol}: no historical "
            f"chunks available."
        )


    df = pd.concat(
        chunk_frames,
        ignore_index=True,
    )


    df = (
        df
        .drop_duplicates(
            subset=["timestamp"]
        )
        .sort_values(
            "timestamp"
        )
        .reset_index(drop=True)
    )


    # Only create the completed raw file after
    # EVERY chunk is available.
    df.to_csv(
        raw_file,
        index=False,
    )


    print(
        f"{symbol}: COMPLETE RAW FILE "
        f"CREATED "
        f"({len(df)} candles)"
    )


    return (
        df,
        raw_file,
    )


# =========================================================
# CLEAN NORMAL SESSION DATA
# =========================================================

def build_clean_data(
    symbol,
    raw_df,
):

    df = raw_df.copy()


    df["trade_date"] = (
        df["timestamp"].dt.date
    )


    df["trade_time"] = (
        df["timestamp"].dt.time
    )


    session_start = (
        datetime.strptime(
            "09:15",
            "%H:%M",
        ).time()
    )


    last_candle = (
        datetime.strptime(
            "15:25",
            "%H:%M",
        ).time()
    )


    clean = df[
        (
            df["trade_time"]
            >= session_start
        )
        &
        (
            df["trade_time"]
            <= last_candle
        )
        &
        (
            ~df[
                "trade_date"
            ].isin(
                SPECIAL_EXCLUDED_DATES
            )
        )
    ].copy()


    clean = (
        clean[
            [
                "timestamp",
                "open",
                "high",
                "low",
                "close",
                "volume",
            ]
        ]
        .sort_values(
            "timestamp"
        )
        .reset_index(drop=True)
    )


    clean_file = os.path.join(
        CLEAN_DIR,
        (
            f"{symbol}_5min_"
            f"2024-01-01_to_"
            f"2025-09-19_clean.csv"
        ),
    )


    clean.to_csv(
        clean_file,
        index=False,
    )


    return (
        clean,
        clean_file,
    )


# =========================================================
# QUALITY VALIDATION
# =========================================================

def validate_symbol(
    symbol,
    clean_df,
):

    df = clean_df.copy()


    df["trade_date"] = (
        df["timestamp"].dt.date
    )


    quality_rows = []


    for (
        trade_date,
        day
    ) in df.groupby(
        "trade_date"
    ):


        expected = (
            pd.date_range(
                start=(
                    f"{trade_date} "
                    f"09:15"
                ),
                end=(
                    f"{trade_date} "
                    f"15:25"
                ),
                freq="5min",
                tz="Asia/Kolkata",
            )
        )


        actual = (
            pd.DatetimeIndex(
                day["timestamp"]
            )
        )


        missing = (
            expected.difference(
                actual
            )
        )


        unexpected = (
            actual.difference(
                expected
            )
        )


        zero_volume = int(
            (
                day["volume"]
                <= 0
            ).sum()
        )


        duplicates = int(
            day["timestamp"]
            .duplicated()
            .sum()
        )


        bad_ohlc = int(
            (
                (day["low"] > day["high"])
                |
                (day["open"] < day["low"])
                |
                (day["open"] > day["high"])
                |
                (day["close"] < day["low"])
                |
                (day["close"] > day["high"])
                |
                (day["open"] <= 0)
                |
                (day["high"] <= 0)
                |
                (day["low"] <= 0)
                |
                (day["close"] <= 0)
            ).sum()
        )


        actual_count = (
            len(day)
        )


        passed = (
            actual_count == 75
            and len(missing) == 0
            and len(unexpected) == 0
            and zero_volume == 0
            and duplicates == 0
            and bad_ohlc == 0
        )


        if (
            trade_date
            <= DEVELOPMENT_END
        ):

            period = (
                "DEVELOPMENT"
            )

        else:

            period = (
                "LOCKED_VALIDATION"
            )


        quality_rows.append(
            {
                "symbol":
                    symbol,

                "trade_date":
                    trade_date,

                "period":
                    period,

                "expected_candles":
                    75,

                "actual_candles":
                    actual_count,

                "missing_candles":
                    len(missing),

                "unexpected_candles":
                    len(unexpected),

                "zero_volume_candles":
                    zero_volume,

                "duplicate_candles":
                    duplicates,

                "bad_ohlc_candles":
                    bad_ohlc,

                "status":
                    (
                        "PASS"
                        if passed
                        else "REVIEW"
                    ),
            }
        )


    return pd.DataFrame(
        quality_rows
    )


# =========================================================
# CREATE DEVELOPMENT + LOCKED DATA
# =========================================================

def save_splits(
    symbol,
    clean_df,
):

    df = clean_df.copy()


    df["trade_date"] = (
        df["timestamp"].dt.date
    )


    development = df[
        (
            df["trade_date"]
            >= DEVELOPMENT_START
        )
        &
        (
            df["trade_date"]
            <= DEVELOPMENT_END
        )
    ].copy()


    locked = df[
        (
            df["trade_date"]
            >= LOCKED_START
        )
        &
        (
            df["trade_date"]
            <= LOCKED_END
        )
    ].copy()


    columns = [
        "timestamp",
        "open",
        "high",
        "low",
        "close",
        "volume",
    ]


    development_file = (
        os.path.join(
            DEVELOPMENT_DIR,
            (
                f"{symbol}_"
                f"development.csv"
            ),
        )
    )


    locked_file = (
        os.path.join(
            LOCKED_DIR,
            (
                f"{symbol}_"
                f"LOCKED.csv"
            ),
        )
    )


    development[
        columns
    ].to_csv(
        development_file,
        index=False,
    )


    locked[
        columns
    ].to_csv(
        locked_file,
        index=False,
    )


    return (
        development,
        locked,
    )


# =========================================================
# MAIN
# =========================================================

symbol_records = (
    load_symbol_master()
)


all_quality = []

summary_rows = []

day_sets = {}


for record in symbol_records:

    symbol = (
        record["symbol"]
    )

    token = (
        record["symboltoken"]
    )


    print()
    print(
        "=" * 78
    )

    print(
        f"PROCESSING {symbol}"
    )

    print(
        "=" * 78
    )


    raw_df, raw_file = (
        download_symbol(
            symbol,
            token,
        )
    )


    clean_df, clean_file = (
        build_clean_data(
            symbol,
            raw_df,
        )
    )


    quality = (
        validate_symbol(
            symbol,
            clean_df,
        )
    )


    all_quality.append(
        quality
    )


    development, locked = (
        save_splits(
            symbol,
            clean_df,
        )
    )


    clean_dates = set(
        clean_df[
            "timestamp"
        ]
        .dt.date
        .unique()
    )


    day_sets[
        symbol
    ] = clean_dates


    review_days = int(
        (
            quality["status"]
            == "REVIEW"
        ).sum()
    )


    summary_rows.append(
        {
            "symbol":
                symbol,

            "raw_candles":
                len(raw_df),

            "clean_candles":
                len(clean_df),

            "trading_days":
                len(clean_dates),

            "development_days":
                development[
                    "timestamp"
                ]
                .dt.date
                .nunique(),

            "locked_days":
                locked[
                    "timestamp"
                ]
                .dt.date
                .nunique(),

            "review_days":
                review_days,
        }
    )


    # -----------------------------------------------------
    # Save progress after EVERY stock
    # -----------------------------------------------------

    pd.concat(
        all_quality,
        ignore_index=True,
    ).to_csv(
        QUALITY_FILE,
        index=False,
    )


    pd.DataFrame(
        summary_rows
    ).to_csv(
        SUMMARY_FILE,
        index=False,
    )


    print()

    print(
        f"{symbol} COMPLETE"
    )

    print(
        "Clean candles:",
        len(clean_df)
    )

    print(
        "Development days:",
        development[
            "timestamp"
        ]
        .dt.date
        .nunique()
    )

    print(
        "Locked days:",
        locked[
            "timestamp"
        ]
        .dt.date
        .nunique()
    )

    print(
        "Review days:",
        review_days
    )


# =========================================================
# FINAL CROSS-STOCK CHECK
# =========================================================

quality_df = (
    pd.concat(
        all_quality,
        ignore_index=True,
    )
)


summary_df = (
    pd.DataFrame(
        summary_rows
    )
)


reference_days = (
    day_sets["SBIN"]
)


missing_counts = {}

extra_counts = {}


for symbol in SYMBOLS:

    missing_counts[
        symbol
    ] = len(
        reference_days
        - day_sets[symbol]
    )


    extra_counts[
        symbol
    ] = len(
        day_sets[symbol]
        - reference_days
    )


summary_df[
    "missing_days_vs_sbin"
] = (
    summary_df[
        "symbol"
    ].map(
        missing_counts
    )
)


summary_df[
    "extra_days_vs_sbin"
] = (
    summary_df[
        "symbol"
    ].map(
        extra_counts
    )
)


quality_df.to_csv(
    QUALITY_FILE,
    index=False,
)


summary_df.to_csv(
    SUMMARY_FILE,
    index=False,
)


# =========================================================
# RESEARCH SPLIT MANIFEST
# =========================================================

manifest = pd.DataFrame(
    [
        {
            "dataset":
                "DEVELOPMENT",

            "start_date":
                DEVELOPMENT_START,

            "end_date":
                DEVELOPMENT_END,

            "allowed_use":
                (
                    "Research and strategy "
                    "development"
                ),
        },

        {
            "dataset":
                "LOCKED_VALIDATION",

            "start_date":
                LOCKED_START,

            "end_date":
                LOCKED_END,

            "allowed_use":
                (
                    "DO NOT ANALYZE until "
                    "strategy rules are frozen"
                ),
        },

        {
            "dataset":
                "ALREADY_EXPLORED",

            "start_date":
                date(2025, 9, 22),

            "end_date":
                date(2026, 9, 18),

            "allowed_use":
                (
                    "Reference only; "
                    "not unseen evidence"
                ),
        },
    ]
)


manifest.to_csv(
    SPLIT_MANIFEST_FILE,
    index=False,
)


# =========================================================
# FINAL REPORT
# =========================================================

print()
print(
    "=" * 100
)

print(
    "30-STOCK RESEARCH DATASET DOWNLOAD COMPLETE"
)

print(
    "=" * 100
)


print(
    summary_df[
        [
            "symbol",
            "clean_candles",
            "trading_days",
            "development_days",
            "locked_days",
            "review_days",
            "missing_days_vs_sbin",
            "extra_days_vs_sbin",
        ]
    ].to_string(
        index=False
    )
)


total_review = int(
    summary_df[
        "review_days"
    ].sum()
)


mismatch_stocks = int(
    (
        (
            summary_df[
                "missing_days_vs_sbin"
            ]
            > 0
        )
        |
        (
            summary_df[
                "extra_days_vs_sbin"
            ]
            > 0
        )
    ).sum()
)


print()

print(
    "Total stocks:",
    len(summary_df)
)

print(
    "Total review-day records:",
    total_review
)

print(
    "Stocks with trading-day mismatch:",
    mismatch_stocks
)


if total_review > 0:

    print()
    print(
        "QUALITY ROWS REQUIRING REVIEW:"
    )


    print(
        quality_df[
            quality_df[
                "status"
            ]
            == "REVIEW"
        ][
            [
                "symbol",
                "trade_date",
                "period",
                "expected_candles",
                "actual_candles",
                "missing_candles",
                "zero_volume_candles",
                "bad_ohlc_candles",
            ]
        ].to_string(
            index=False
        )
    )


else:

    print()

    print(
        "ALL OBSERVED NORMAL TRADING DAYS "
        "PASSED CANDLE VALIDATION"
    )


print()
print(
    "Development data:"
)

print(
    DEVELOPMENT_DIR
)


print()
print(
    "LOCKED validation data:"
)

print(
    LOCKED_DIR
)


print()
print(
    "IMPORTANT: DO NOT OPEN OR ANALYZE "
    "THE LOCKED VALIDATION DATA YET."
)


print()
print(
    "Summary:"
)

print(
    SUMMARY_FILE
)


# =========================================================
# LOGOUT
# =========================================================

try:

    smart_api.terminateSession(
        client_code
    )

except Exception:

    pass