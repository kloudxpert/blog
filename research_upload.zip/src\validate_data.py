import pandas as pd

file_path = r"data\SBIN_5min_test.csv"

# Load CSV
df = pd.read_csv(file_path)

# Convert timestamp column to datetime
df["timestamp"] = pd.to_datetime(df["timestamp"])

# --------------------------------------------------
# For CAS-eligible stocks, normal continuous trading
# data is considered only up to the 15:10 candle.
# The 15:10 candle represents 15:10–15:15.
# --------------------------------------------------

cutoff_time = pd.Timestamp("15:10").time()

df = df[
    df["timestamp"].dt.time <= cutoff_time
].copy()

# Expected 5-minute candles:
# 09:15, 09:20, ... 15:10
expected = pd.date_range(
    start="2026-09-18 09:15",
    end="2026-09-18 15:10",
    freq="5min",
    tz="Asia/Kolkata",
)

actual = pd.DatetimeIndex(df["timestamp"])

# Find missing candles
missing = expected.difference(actual)

# Find unexpected timestamps
unexpected = actual.difference(expected)

# Find zero-volume candles
zero_volume = df[df["volume"] == 0]

print("=" * 55)
print("SBIN 5-MINUTE DATA QUALITY CHECK")
print("=" * 55)

print("Total candles:", len(df))
print("Expected candles:", len(expected))
print()

print("Missing timestamps:")
if len(missing) == 0:
    print("None")
else:
    for ts in missing:
        print(ts)

print()

print("Unexpected timestamps:")
if len(unexpected) == 0:
    print("None")
else:
    for ts in unexpected:
        print(ts)

print()

print("Zero-volume candles:")
if zero_volume.empty:
    print("None")
else:
    print(
        zero_volume[
            [
                "timestamp",
                "open",
                "high",
                "low",
                "close",
                "volume",
            ]
        ].to_string(index=False)
    )

print()

# Final validation result
if (
    len(df) == len(expected)
    and len(missing) == 0
    and len(unexpected) == 0
    and zero_volume.empty
):
    print("DATA QUALITY CHECK: PASSED")
else:
    print("DATA QUALITY CHECK: FAILED")